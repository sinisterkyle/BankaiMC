# BankaiMC (Forge 1.20.1)

Every sword or katana has a sleeping spirit. Kill enough hostile mobs with **that specific weapon** and its spirit
randomly reveals its name (Shikai). Keep fighting and it eventually grants its Bankai.

## Build

1. Open this folder in IntelliJ IDEA (File > Open > select the folder, "Open as Gradle project").
2. Set the Gradle JVM to **Java 17** (Settings > Build Tools > Gradle > Gradle JVM).
3. Let it sync (the first time downloads Minecraft + Forge and takes a few minutes).
4. Run the Gradle task `build` (Gradle tab > BankaiMC > Tasks > build > build), or `./gradlew build`.
5. Your jar is at `build/libs/bankaimc-1.0.4.jar`. Put it in the `mods` folder of **both the server and every client**
   (it adds keybinds and a HUD, so clients need it too).

To test locally: Gradle tab > Tasks > forgegradle runs > `runClient`.

## Updating to a new version of the zip

Delete your old `src` folder first, then copy in the new one. Extracting over the top keeps files that were
removed in newer versions (for example the old `ability/Abilities.java`), and those break the build.
Your `run` folder (test world) and `config` can stay.

## How it works

| Stage  | How to get it (defaults, all configurable) |
|--------|--------------------------------------------|
| Sealed | Any sword / katana. Kills are counted on the item itself. |
| Shikai | After 500 kills, each kill has a 0.4% chance. Guaranteed at 1,500. A random spirit is assigned to that weapon forever. |
| Bankai | After 3,000 kills, each kill has a 0.1% chance. Guaranteed at 8,000. |

Only hostile mob kills count by default (no chicken farming). Ability kills count too.

## Controls (rebindable under Controls > BankaiMC)

- **R** - Release: Sealed > Shikai > Bankai > Sealed. **Sneak + R** always seals.
- **V** - Use the current ability. **Sneak + V** - use the second ability.

Bankai lasts 60s, then needs 180s of rest. All Bankai damage is multiplied by `bankaiPowerMultiplier` (default 4x) in the config. Releasing Bankai also blasts nearby enemies for 24.

## The ten spirits

While your blade is released, its spirit's particles spiral around you and glow on the blade (wider and denser in Bankai). Every spirit has the same aura, in its own particles.

Every spirit has a **trait** (works with normal sword hits / while defending), plus two abilities per stage:
**[V]** and **[Sneak + V]**, each with its own cooldown. The small HUD in the bottom-left corner shows both.

### Zangetsu: raw power
- **Trait:** sword hits charge a **reiatsu meter** (shown on the HUD).
- **Shikai**
  - [V] Getsuga Tensho: flying blue crescent.
  - [Sneak+V] Full-Power Getsuga: spends the meter (30+ needed). The more reiatsu, the bigger it is (up to 54 dmg, 5 blocks wide).
- **Bankai: Tensa Zangetsu** (Speed III, Strength II)
  - [V] Black Getsuga (120 dmg). **At 100 reiatsu, [V] becomes MUGETSU:** a wall of darkness 60 blocks long (240 dmg). Then your Bankai shuts off and needs double the rest.
  - [Sneak+V] Shunpo: flash 12 blocks forward, slashing everything you pass through.

### Hyorinmaru: everything it touches freezes
- **Trait:** sword hits stack frost. At 3 stacks (2 in Bankai) the target freezes solid.
- **Shikai**
  - [V] Ice Dragon: a twisting dragon of ice that freezes what it bites.
  - [Sneak+V] Ryusenka: impale the enemy you look at and encase it in ice.
- **Bankai: Daiguren Hyorinmaru**
  - **Ice wings give you real flight for the first 10 seconds** (double-tap jump), then they shatter and Bankai continues on foot. No fall damage for the whole Bankai. The wing time shows on the HUD and is set by `hyorinmaruFlightSeconds`. Flight is checked every tick, so swapping items, sealing, logging out or dying can't keep it.
  - [V] Hyoten Hyakkaso: 5s of falling ice that freezes the battlefield.
  - [Sneak+V] Sennen Hyoro: ten ice pillars rise around your target, then slam shut (160 dmg).

### Senbonzakura: a thousand blades like petals
- **Shikai**
  - [V] Petal Arrow: a stream of petals that follows your aim for 3s.
  - [Sneak+V] Petal Shield: a dome for 4s. Arrows and fireballs are shredded, and 80% of blows are deflected.
- **Bankai: Kageyoshi** (Resistance III)
  - **Trait:** the petals guard you, deflecting 30% of attacks.
  - [V] Kageyoshi: a huge petal vortex, with streams of petals diving into each enemy.
  - [Sneak+V] Senkei, then Gokei: a ring of blade-walls (radius 10) traps everything inside for 7s while you get Strength III. Then every blade collapses inward (160 dmg).

### Kyoka Suigetsu: complete hypnosis
- **Trait:** "you were never there." Attacks sometimes hit an illusion instead, and you reappear behind the attacker (10% Shikai, 30% Bankai).
- **Shikai**
  - [V] Mirror Flower: you vanish, and every mob nearby sees *you* in the other mobs. **They fight each other** for 10s.
  - [Sneak+V] Kurohitsugi (Black Coffin): a black box closes around the enemy you look at, then spears of darkness pierce it.
- **Bankai: Complete Hypnosis**
  - [V] Complete Hypnosis: everything within 20 blocks takes 100 dmg and is frozen in the illusion for 10s, then shatters for 120 more.
  - [Sneak+V] Shatter: break every illusion you're holding **right now**, for 1.5x the shatter damage.

### Katen Kyokotsu: games with deadly rules
- **Trait (Takaoni rule):** your sword hits deal +50% when you stand higher than the target.
- **Shikai**
  - [V] Takaoni: area hit that gets stronger the higher you stand.
  - [Sneak+V] Kageoni: step into the shadow of the enemy you look at, reappear behind it and strike.
- **Bankai: Karamatsu Shinju**
  - **Trait (Shared Wounds):** 75% of the damage you take is also dealt to every enemy within 10 blocks.
  - [V] The Four Acts: Wounds, Shame, Binding Threads, then Itodome (180 dmg).
  - [Sneak+V] Bushogoma: a whirlwind of flowers and shadow travels where you aim, dragging enemies in.

### Ryujin Jakka: the strongest fire
- **Trait:** sword hits set enemies ablaze.
- **Shikai**
  - [V] Ennetsu Jigoku: three fast waves of fire pillars (0.4s total) erupt in rings out to 11 blocks, hitting everything in each ring and launching enemies.
  - [Sneak+V] Jokaku Enjo: a 6-block wall of fire cages the spot you aim at for 6s. Anyone touching the wall is burned and thrown back in.
- **Bankai: Zanka no Tachi** (all the fire is drawn into the blade)
  - **Trait:** sword hits sear for +12 damage, and everything near you catches fire.
  - [V] East: Kyokujitsujin: charge for half a second (keep aiming), then fire a beam of the sun: white-hot core, flame spirals, rings of light rippling along it, scorched ground (180 dmg). A miniature sun swells where it lands, then collapses and detonates (60 dmg in 5 blocks).
  - [Sneak+V] West: Zanjitsu Gokui: 8s of flame armor. You're nearly immune, and attackers and anything close are scorched.

### Minazuki (Unohana): the healer's manta, hiding a blade of blood
*Releasing Shikai: the manta takes shape from the blade and rises. Releasing Bankai: the blade melts and a pool of blood spreads at your feet.*
- **Shikai**
  - **Trait:** sword hits heal you for 15% of the damage.
  - [V] Manta's Embrace: a manta ray glides over you and allies within 10 blocks. Heal 4 hearts, cleanse bad effects, Regeneration II.
  - [Sneak+V] Swallow: the manta dives out of the sky onto the enemy you look at, lifts it, blinds it and digests it for 3s while healing you.
- **Bankai: Minazuki** (the blade becomes liquid blood)
  - **Trait:** 35% lifesteal, and every hit adds a **bleed** stack (stacks up to 10, damage every second). Finishing a bleeding enemy with your sword heals 2 more hearts.
  - [V] Blood Tide: a wave of blood floods 16 blocks forward (48 dmg, 4 bleed stacks), healing you.
  - [Sneak+V] Hemorrhage: every bleeding enemy within 20 blocks bursts at once (stacks x 20 dmg), and you drink 30% of it.

### Benihime (Urahara): the scientist's blade that restructures what it cuts
*Releasing Bankai: a giant spirit (custom Benihime spirit skin) rises out of the ground behind you, stays put, leaning over the spot where you stood with its arms out, then fades away into stitches (about 5 seconds). It's visual only: no blocks placed, can't be hit, never saved.*
- **Trait:** sword hits **analyze** the target. Analyzed enemies take +25% from all your abilities.
- **Shikai**
  - [V] Cry, Benihime: a fast crimson blast that bursts on impact and pins everything nearby in a net of red light for 2s (Shibari).
  - [Sneak+V] Blood Mist Shield: a honeycomb shield of blood mist blocks every attack and projectile from the front for 4s.
- **Bankai: Kannonbiraki Benihime Aratame**
  - **Trait:** once per Bankai, a killing blow is **stitched closed**. You survive at 40% health.
  - [V] Restructure: stitches race across the enemy you look at, then it is sewn into a weaker shape: 80 dmg, Weakness IV, Slowness III, analyzed for 20s. Up to 3 enemies near it are sewn to it, dragged in and weakened too.
  - [Sneak+V] Self-Stitch: sew your own wounds shut. Heal 60% of max health, cleanse, Absorption II.

### Zabimaru (Renji): the snake blade
*Releasing Shikai: the blade splits into segments and snaps back together. Releasing Bankai: a bone serpent coils up around you, led by a 3D white-and-red snake skull that strikes with its jaw unhinged.*
- **Shikai**
  - **Trait:** 25% of sword hits lash a second nearby enemy for 60% damage.
  - [V] Whip Blade: the segmented blade cracks out 14 blocks along your aim, rippling as it goes, and reels in the first enemy it catches.
  - [Sneak+V] Higa Zekko: the segments fly apart into up to 8 enemies, then snap back.
- **Bankai: Hihio Zabimaru**
  - **Trait:** every sword hit is followed by a snake bite (16 dmg).
  - [V] Hikotsu Taiho: a 3D snake skull appears over your shoulder and unhinges its jaw while red reiatsu charges for a second (keep aiming), then fires a 40-block blast (160 dmg).
  - [Sneak+V] Serpent Coil: the bone snake sweeps a full circle around you, throwing everything back (60 dmg).

## Outfits

Wearable armor pieces, all in the **BankaiMC** creative tab and craftable.

| Item | Slot | Recipe | Bonus |
|---|---|---|---|
| Shinigami Robe | Chest | black wool around white wool | part of the set |
| Shinigami Hakama | Legs | black wool + string | part of the set |
| Waraji Sandals | Feet | string over wheat | no fall damage under 6 blocks |
| Captain's Haori | Chest (robe included) | white wool around a Shinigami Robe, gold ingot on top | Resistance I, **Bankai lasts 50% longer** |
| Kenpachi's Haori | Chest (torn, sleeveless) | Captain's Haori + shears + bell (shapeless) | Strength I (III under half health), **sword hits +20%** |
| Urahara's Hat | Head (striped bucket hat with a brim) | green/white wool | **all ability cooldowns -20%** |

**Full set:** robe or either haori + hakama + sandals = Speed I and Jump Boost I.

The haori have their own 3D model (open front showing the robe, coat tail to the knees, squad diamond on the back) and so does the hat (wide brim). Textures are in `assets/bankaimc/textures/models/armor/`.

### Shinso (Gin): the blade that extends faster than the eye can follow
*Releasing it: the blade whips out and sweeps around you, cutting and hurling back everything in reach.*
*Shikai draw: 14-block half circle in front of you, 3 dmg + heavy knockback (15s internal cooldown, so re-sealing can't spam it). Bankai draw: 30-block full circle, 40 dmg + huge knockback, and a fragment in everyone hit.*
- **Shikai**
  - **Trait:** 35% of sword hits extend through the target and pierce the next enemy behind it (80% damage).
  - [V] Shoot to Kill: the blade flashes out 24 blocks along your aim and back, piercing everything in the line and hurling it back (24 dmg).
  - [Sneak+V] Butou Renjin: 9 rapid extending stabs (9 dmg each) and a heavy finishing thrust (20 dmg, big knockback) over 1.4s.
- **Bankai: Kamishini no Yari** (Speed II, Strength I)
  - **Trait:** every hit leaves a **poison fragment** inside the enemy (up to 3, lasts 30s, shown as violet glints).
  - [V] Kamishini no Yari: a 64-block lance, out and back almost instantly, piercing everything in its path (80 dmg), knocking it back and leaving a fragment in each.
  - [Sneak+V] Korose: every enemy within 40 blocks carrying your fragments dissolves from the inside, taking 60 dmg per fragment (up to 180), plus Wither.

## Particles

Every spirit has its own hand-drawn particles (`assets/bankaimc/textures/particle`):
cherry blossom petals (Senbonzakura), ice shards and ice wings (Hyorinmaru), blue reiatsu and black/red reiatsu (Zangetsu),
glinting mirror shards (Kyoka Suigetsu), kimono flowers and shadow ink (Katen Kyokotsu), and glowing embers (Ryujin Jakka).

## Blades

BankaiMC has its own weapons (textures by the BankaiMC author). Every sword, vanilla or modded, can still awaken too. Numbers are exactly what the tooltip shows.

| Weapon | Wooden | Stone | Copper | Iron | Steel | Golden | Diamond | Netherite | Speed | Recipe (M = material, G = grip) |
|---|---|---|---|---|---|---|---|---|---|---|
| Katana | 4 | 5 | 5 | 6 | 6.5 | 4 | 7 | 8 | 1.4 | diagonal: M, M, G |
| Hengdao | 3.5 | 4.5 | 4.5 | 5.5 | 6 | 3.6 | 6.6 | 7.7 | 1.8 | katana + one more M at the tip |
| Machete | 3 | 4 | 4 | 5 | 5.5 | 3 | 6 | 7 | 2.0 | MM over G |
| Longsword | 5 | 6 | 6 | 7 | - | 5 | 8 | 9 | 1.2 | M, M, G straight down |
| Shamshir | 3.5 | 4.5 | 4.5 | 5.5 | 6 | 3.5 | 6.5 | 7.5 | 1.6 | curve: M top right, MM middle, G |
| Guduo | 6 | 7 | 7 | 8 | 8.5 | 6 | 9 | 10 | 0.9 | 2x2 M head over G |
| Sword | - | - | 5 | - | 6.5 | - | - | - | 1.6 | vanilla sword shape with copper/steel |
| Netherite Striker | | | | | | | | 11 | 0.8 | smithing: template + netherite guduo + netherite block |

- **Grip:** string + stick.
- **Steel Ingot:** smelt an iron ingot in a blast furnace.
- **Netherite** weapons: smithing table, netherite upgrade template + diamond weapon + netherite ingot.

Katana and hengdao numbers are the ones you set. The rest (and steel katana/hengdao) are defaults, all in one table in `item/ModBlades.java`.

## Test commands

Usable by ops, **or by anyone in Creative mode** (turn off with `creativeCheats = false`). Type `/bankai` for the list.

| Command | What it does |
|---|---|
| `/bankai test <spirit> [weapon]` | Gives you a weapon with Bankai unlocked and turns test mode on. Default weapon: BankaiMC netherite katana. Example: `/bankai test kyoka_suigetsu bankaimc:diamond_hengdao` |
| `/bankai give <spirit> <sealed\|shikai\|bankai> [weapon]` | Gives a weapon at any stage |
| `/bankai unlock <shikai\|bankai> [spirit]` | Upgrades the weapon in your hand (with the real title, lightning and announcement) |
| `/bankai release <sealed\|shikai\|bankai>` | Forces a release state without pressing R |
| `/bankai testmode [true\|false]` | No ability cooldowns, Bankai never runs out and needs no rest. Survives death |
| `/bankai cooldowns` | Clears cooldowns on the held weapon |
| `/bankai simulate <kills>` | Adds kills one at a time with the real random awakening rolls, to test the progression |
| `/bankai dummies [count]` | Spawns husks in a ring around you (they don't burn in daylight) |
| `/bankai kills <n>`, `info`, `spirits`, `reset` | Set kills, show weapon status, list spirits, wipe the weapon |

Spirit ids: `zangetsu`, `hyorinmaru`, `senbonzakura`, `kyoka_suigetsu`, `katen_kyokotsu`, `ryujin_jakka`, `minazuki`, `benihime`, `zabimaru`, `shinso`.

## Config

`config/bankaimc-common.toml` (created on first launch): kill thresholds and chances, damage and cooldown multipliers,
Bankai duration and rest time, PvP on/off, which items count. To add any other item, put its id in `extraWeapons` or add it to the `bankaimc:zanpakuto` item tag.
