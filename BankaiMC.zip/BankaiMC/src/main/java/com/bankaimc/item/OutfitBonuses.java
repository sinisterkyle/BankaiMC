package com.bankaimc.item;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;

/** Set bonuses for the outfits. Checked every second. */
public final class OutfitBonuses {
    private OutfitBonuses() {}

    private static boolean wearing(Player p, EquipmentSlot slot, Item item) {
        return p.getItemBySlot(slot).is(item);
    }

    public static boolean hasHat(Player p) {
        return wearing(p, EquipmentSlot.HEAD, ModItems.URAHARA_HAT.get());
    }

    public static boolean hasCaptainHaori(Player p) {
        return wearing(p, EquipmentSlot.CHEST, ModItems.CAPTAIN_HAORI.get());
    }

    public static boolean hasKenpachiHaori(Player p) {
        return wearing(p, EquipmentSlot.CHEST, ModItems.KENPACHI_HAORI.get());
    }

    public static boolean hasSandals(Player p) {
        return wearing(p, EquipmentSlot.FEET, ModItems.WARAJI_SANDALS.get());
    }

    public static boolean fullShinigami(Player p) {
        boolean top = wearing(p, EquipmentSlot.CHEST, ModItems.SHINIGAMI_ROBE.get()) || hasCaptainHaori(p) || hasKenpachiHaori(p);
        return top && wearing(p, EquipmentSlot.LEGS, ModItems.SHINIGAMI_HAKAMA.get()) && hasSandals(p);
    }

    public static void tick(ServerPlayer p) {
        if (fullShinigami(p)) {
            give(p, MobEffects.MOVEMENT_SPEED, 0);
            give(p, MobEffects.JUMP, 0);
        }
        if (hasCaptainHaori(p)) give(p, MobEffects.DAMAGE_RESISTANCE, 0);
        if (hasKenpachiHaori(p)) give(p, MobEffects.DAMAGE_BOOST, p.getHealth() < p.getMaxHealth() * 0.5f ? 2 : 0);
    }

    private static void give(ServerPlayer p, MobEffect eff, int amp) {
        MobEffectInstance cur = p.getEffect(eff);
        if (cur != null && cur.getAmplifier() > amp) return; // don't override stronger zanpakuto buffs
        p.addEffect(new MobEffectInstance(eff, 40, amp, true, false, true));
    }
}
