package com.bankaimc.item;

import com.bankaimc.BankaiMC;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.Supplier;

/** Cloth outfits: light, but they carry set bonuses (see OutfitBonuses). */
public enum ModArmorMaterials implements ArmorMaterial {
    //           name          dur  helmet chest legs boots ench tough  kb
    SHINIGAMI("shinigami",      15,  2,     5,    4,   1,    20,  0.0f, 0.0f, () -> Ingredient.of(Items.BLACK_WOOL)),
    CAPTAIN("captain_haori",    25,  2,     7,    5,   2,    25,  1.0f, 0.0f, () -> Ingredient.of(Items.WHITE_WOOL)),
    KENPACHI("kenpachi_haori",  30,  2,     7,    5,   2,    10,  2.0f, 0.1f, () -> Ingredient.of(Items.WHITE_WOOL)),
    URAHARA("urahara_hat",      20,  2,     5,    4,   1,    30,  0.0f, 0.0f, () -> Ingredient.of(Items.GREEN_WOOL));

    private final String name;
    private final int durability;
    private final int helmet, chest, legs, boots;
    private final int enchant;
    private final float toughness, knockback;
    private final Supplier<Ingredient> repair;

    ModArmorMaterials(String name, int durability, int helmet, int chest, int legs, int boots, int enchant,
                      float toughness, float knockback, Supplier<Ingredient> repair) {
        this.name = name;
        this.durability = durability;
        this.helmet = helmet;
        this.chest = chest;
        this.legs = legs;
        this.boots = boots;
        this.enchant = enchant;
        this.toughness = toughness;
        this.knockback = knockback;
        this.repair = repair;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        int base = switch (type) {
            case HELMET -> 11;
            case CHESTPLATE -> 16;
            case LEGGINGS -> 15;
            case BOOTS -> 13;
        };
        return base * durability;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> helmet;
            case CHESTPLATE -> chest;
            case LEGGINGS -> legs;
            case BOOTS -> boots;
        };
    }

    @Override
    public int getEnchantmentValue() { return enchant; }

    @Override
    public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_LEATHER; }

    @Override
    public Ingredient getRepairIngredient() { return repair.get(); }

    /** Vanilla looks for assets/bankaimc/textures/models/armor/<name>_layer_1.png / _layer_2.png */
    @Override
    public String getName() { return BankaiMC.MODID + ":" + name; }

    @Override
    public float getToughness() { return toughness; }

    @Override
    public float getKnockbackResistance() { return knockback; }
}
