package com.bankaimc.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.Supplier;

/** The two tiers vanilla doesn't have. Damage/speed of each blade is set exactly in ModBlades; these set durability etc. */
public enum ModTiers implements Tier {
    //        uses  mining  bonus level ench
    COPPER(   190,  5.0f,   1.5f, 1,    13, () -> Ingredient.of(Items.COPPER_INGOT)),
    STEEL(    600,  6.5f,   2.5f, 2,    12, () -> Ingredient.of(ModBlades.STEEL_INGOT.get()));

    private final int uses, level, enchant;
    private final float speed, bonus;
    private final Supplier<Ingredient> repair;

    ModTiers(int uses, float speed, float bonus, int level, int enchant, Supplier<Ingredient> repair) {
        this.uses = uses;
        this.speed = speed;
        this.bonus = bonus;
        this.level = level;
        this.enchant = enchant;
        this.repair = repair;
    }

    @Override public int getUses() { return uses; }
    @Override public float getSpeed() { return speed; }
    @Override public float getAttackDamageBonus() { return bonus; }
    @Override @SuppressWarnings("deprecation") public int getLevel() { return level; }
    @Override public int getEnchantmentValue() { return enchant; }
    @Override public Ingredient getRepairIngredient() { return repair.get(); }
}
