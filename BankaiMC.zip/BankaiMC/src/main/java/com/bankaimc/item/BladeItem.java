package com.bankaimc.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

/**
 * A sword with exact attack damage and attack speed (as shown in the tooltip, e.g. 4 damage / 1.4 speed),
 * instead of vanilla's whole-number-plus-tier math. Still a SwordItem, so it can hold a zanpakuto spirit.
 */
public class BladeItem extends SwordItem {
    private final float shownDamage;
    private final Multimap<Attribute, AttributeModifier> modifiers;

    public BladeItem(Tier tier, double damage, double speed, Properties props) {
        super(tier, 0, 0.0f, props);
        this.shownDamage = (float) damage;
        ImmutableMultimap.Builder<Attribute, AttributeModifier> b = ImmutableMultimap.builder();
        // the player has 1 base damage and 4 base attack speed; the tooltip shows base + modifier
        b.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Weapon modifier", damage - 1.0, AttributeModifier.Operation.ADDITION));
        b.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Weapon modifier", speed - 4.0, AttributeModifier.Operation.ADDITION));
        this.modifiers = b.build();
    }

    @Override
    @SuppressWarnings("deprecation")
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        return slot == EquipmentSlot.MAINHAND ? modifiers : super.getDefaultAttributeModifiers(slot);
    }

    @Override
    public float getDamage() {
        return shownDamage - 1.0f;
    }
}
