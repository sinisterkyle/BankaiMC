package com.bankaimc.item;

import com.bankaimc.BankaiMC;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, BankaiMC.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BankaiMC.MODID);

    public static final RegistryObject<OutfitItem> SHINIGAMI_ROBE = ITEMS.register("shinigami_robe", () -> new OutfitItem(
            ModArmorMaterials.SHINIGAMI, ArmorItem.Type.CHESTPLATE, OutfitItem.Style.LAYERED, new Item.Properties(),
            "Shihakusho - the black robe of a Soul Reaper.", "Full set (robe/haori + hakama + sandals): Speed I, Jump Boost I"));
    public static final RegistryObject<OutfitItem> SHINIGAMI_HAKAMA = ITEMS.register("shinigami_hakama", () -> new OutfitItem(
            ModArmorMaterials.SHINIGAMI, ArmorItem.Type.LEGGINGS, OutfitItem.Style.LAYERED, new Item.Properties(),
            "Black hakama.", "Full set (robe/haori + hakama + sandals): Speed I, Jump Boost I"));
    public static final RegistryObject<OutfitItem> WARAJI_SANDALS = ITEMS.register("waraji_sandals", () -> new OutfitItem(
            ModArmorMaterials.SHINIGAMI, ArmorItem.Type.BOOTS, OutfitItem.Style.LAYERED, new Item.Properties(),
            "Straw sandals and white tabi.", "Full set (robe/haori + hakama + sandals): Speed I, Jump Boost I", "No fall damage under 6 blocks"));
    public static final RegistryObject<OutfitItem> CAPTAIN_HAORI = ITEMS.register("captain_haori", () -> new OutfitItem(
            ModArmorMaterials.CAPTAIN, ArmorItem.Type.CHESTPLATE, OutfitItem.Style.HAORI, new Item.Properties(),
            "The white haori of a Gotei 13 captain, worn over the shihakusho.", "Worn: Resistance I. Bankai lasts 50% longer."));
    public static final RegistryObject<OutfitItem> KENPACHI_HAORI = ITEMS.register("kenpachi_haori", () -> new OutfitItem(
            ModArmorMaterials.KENPACHI, ArmorItem.Type.CHESTPLATE, OutfitItem.Style.KENPACHI_HAORI, new Item.Properties(),
            "A torn, sleeveless captain's haori. Bells not included.", "Worn: Strength I. Under 50% health: Strength III.",
            "Sword hits deal +20% damage."));
    public static final RegistryObject<OutfitItem> URAHARA_HAT = ITEMS.register("urahara_hat", () -> new OutfitItem(
            ModArmorMaterials.URAHARA, ArmorItem.Type.HELMET, OutfitItem.Style.HAT, new Item.Properties(),
            "A striped bucket hat. Shades the eyes, hides the scheming.", "Worn: all zanpakuto ability cooldowns -20%."));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.bankaimc"))
            .icon(() -> new ItemStack(URAHARA_HAT.get()))
            .displayItems((params, out) -> {
                out.accept(SHINIGAMI_ROBE.get());
                out.accept(SHINIGAMI_HAKAMA.get());
                out.accept(WARAJI_SANDALS.get());
                out.accept(CAPTAIN_HAORI.get());
                out.accept(KENPACHI_HAORI.get());
                out.accept(URAHARA_HAT.get());
                out.accept(ModBlades.SWORD_HANDLE.get());
                out.accept(ModBlades.STEEL_INGOT.get());
                ModBlades.BLADES.values().forEach(b -> out.accept(b.get()));
            })
            .build());

    private ModItems() {}
}
