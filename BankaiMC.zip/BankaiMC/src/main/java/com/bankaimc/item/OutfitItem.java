package com.bankaimc.item;

import com.bankaimc.BankaiMC;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;

/** A wearable outfit piece. Haori and the hat use their own 3D models; robes use the normal armor layers. */
public class OutfitItem extends ArmorItem {

    public enum Style { LAYERED, HAORI, KENPACHI_HAORI, HAT }

    private final Style style;
    private final String[] lore;

    public OutfitItem(ModArmorMaterials material, Type type, Style style, Properties props, String... lore) {
        super(material, type, props);
        this.style = style;
        this.lore = lore;
    }

    public Style style() {
        return style;
    }

    @Override
    public @Nullable String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        return switch (style) {
            case HAORI -> BankaiMC.MODID + ":textures/models/armor/captain_haori.png";
            case KENPACHI_HAORI -> BankaiMC.MODID + ":textures/models/armor/kenpachi_haori.png";
            case HAT -> BankaiMC.MODID + ":textures/models/armor/urahara_hat.png";
            case LAYERED -> null; // vanilla: shinigami_layer_1 / _layer_2
        };
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        for (String line : lore) tip.add(Component.literal(line).withStyle(ChatFormatting.GRAY));
    }

    /**
     * NOTE: Forge calls this from inside the Item constructor, BEFORE this class's fields are set,
     * so {@code style} is still null here. The model looks the style up later, at render time.
     */
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(com.bankaimc.client.OutfitModels.extensions(this::style));
    }
}
