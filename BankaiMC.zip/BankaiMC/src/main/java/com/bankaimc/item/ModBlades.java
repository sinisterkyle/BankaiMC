package com.bankaimc.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * BankaiMC's own weapons (textures by the BankaiMC author). Every number below is what the tooltip shows.
 * To rebalance, just edit the tables.
 */
public final class ModBlades {

    public enum BladeTier {
        WOODEN("wooden", Tiers.WOOD),
        STONE("stone", Tiers.STONE),
        COPPER("copper", ModTiers.COPPER),
        IRON("iron", Tiers.IRON),
        STEEL("steel", ModTiers.STEEL),
        GOLDEN("golden", Tiers.GOLD),
        DIAMOND("diamond", Tiers.DIAMOND),
        NETHERITE("netherite", Tiers.NETHERITE);

        public final String id;
        public final Tier tier;

        BladeTier(String id, Tier tier) {
            this.id = id;
            this.tier = tier;
        }
    }

    /**
     * Damage per tier, in order: wooden, stone, copper, iron, steel, golden, diamond, netherite.
     * NaN = this weapon doesn't come in that tier.
     */
    public enum BladeType {
        //                                wood  stone copper iron  steel golden diam  neth   speed
        KATANA("katana",       new double[]{4.0, 5.0, 5.0,  6.0, 6.5,  4.0,  7.0, 8.0}, 1.4),
        HENGDAO("hengdao",     new double[]{3.5, 4.5, 4.5,  5.5, 6.0,  3.6,  6.6, 7.7}, 1.8),
        MACHETE("machete",     new double[]{3.0, 4.0, 4.0,  5.0, 5.5,  3.0,  6.0, 7.0}, 2.0),
        LONGSWORD("longsword", new double[]{5.0, 6.0, 6.0,  7.0, Double.NaN, 5.0, 8.0, 9.0}, 1.2),
        SHAMSHIR("shamshir",   new double[]{3.5, 4.5, 4.5,  5.5, 6.0,  3.5,  6.5, 7.5}, 1.6),
        GUDUO("guduo",         new double[]{6.0, 7.0, 7.0,  8.0, 8.5,  6.0,  9.0, 10.0}, 0.9),
        SWORD("sword",         new double[]{Double.NaN, Double.NaN, 5.0, Double.NaN, 6.5, Double.NaN, Double.NaN, Double.NaN}, 1.6);

        public final String id;
        public final double[] damage;
        public final double speed;

        BladeType(String id, double[] damage, double speed) {
            this.id = id;
            this.damage = damage;
            this.speed = speed;
        }
    }

    public static final RegistryObject<Item> SWORD_HANDLE = ModItems.ITEMS.register("sword_handle", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> STEEL_INGOT = ModItems.ITEMS.register("steel_ingot", () -> new Item(new Item.Properties()));

    /** "netherite_katana" -> item, in display order (type, then tier). */
    public static final Map<String, RegistryObject<Item>> BLADES = new LinkedHashMap<>();

    static {
        for (BladeType type : BladeType.values()) {
            for (BladeTier tier : BladeTier.values()) {
                double dmg = type.damage[tier.ordinal()];
                if (Double.isNaN(dmg)) continue;
                String name = tier.id + "_" + type.id;
                BLADES.put(name, ModItems.ITEMS.register(name, () -> new BladeItem(tier.tier, dmg, type.speed, props(tier))));
            }
        }
        // the one-off: a netherite war club
        BLADES.put("netherite_striker", ModItems.ITEMS.register("netherite_striker",
                () -> new BladeItem(Tiers.NETHERITE, 11.0, 0.8, props(BladeTier.NETHERITE))));
    }

    private static Item.Properties props(BladeTier tier) {
        Item.Properties p = new Item.Properties();
        if (tier == BladeTier.NETHERITE) p.fireResistant();
        return p;
    }

    /** The blade for this tier and type, or null if that combination doesn't exist. */
    public static Item get(BladeTier tier, BladeType type) {
        RegistryObject<Item> ro = BLADES.get(tier.id + "_" + type.id);
        return ro == null ? null : ro.get();
    }

    public static Item get(String name) {
        RegistryObject<Item> ro = BLADES.get(name);
        return ro == null ? null : ro.get();
    }

    /** Called from the mod constructor so the items above are registered. */
    public static void init() {}

    private ModBlades() {}
}
