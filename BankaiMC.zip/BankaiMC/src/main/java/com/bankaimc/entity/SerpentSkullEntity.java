package com.bankaimc.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Zabimaru's bone serpent skull: a 3D model steered every tick by an ability (position, facing, how wide the jaw is).
 * Visual only. If nothing steers it for a few ticks it removes itself, so it can never be left behind.
 */
public class SerpentSkullEntity extends Entity {
    private static final EntityDataAccessor<Float> JAW = SynchedEntityData.defineId(SerpentSkullEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> SIZE = SynchedEntityData.defineId(SerpentSkullEntity.class, EntityDataSerializers.FLOAT);
    private int lastSteered = 0;

    // client-side smoothing, the same idea mobs use: ease toward each server update over a few ticks
    private int lerpSteps;
    private double lerpX, lerpY, lerpZ;
    private float lerpYRot, lerpXRot;
    private float jawO, jawNow;

    public SerpentSkullEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    public static SerpentSkullEntity spawn(ServerLevel level, Vec3 pos, Vec3 dir, float size) {
        SerpentSkullEntity s = new SerpentSkullEntity(ModEntities.SERPENT_SKULL.get(), level);
        s.entityData.set(SIZE, size);
        s.steer(pos, dir, 0f);
        s.yRotO = s.getYRot();
        s.xRotO = s.getXRot();
        level.addFreshEntity(s);
        return s;
    }

    /** Move the skull, face it along dir, open the jaw (0 = shut, 1 = wide open). Call every tick. */
    public void steer(Vec3 pos, Vec3 dir, float jaw) {
        Vec3 d = dir.normalize();
        setPos(pos.x, pos.y, pos.z);
        setYRot((float) (Mth.atan2(-d.x, d.z) * (180.0 / Math.PI)));
        setXRot((float) (-Math.asin(Mth.clamp(d.y, -1.0, 1.0)) * (180.0 / Math.PI)));
        entityData.set(JAW, Mth.clamp(jaw, 0f, 1f));
        lastSteered = tickCount;
    }

    public float jaw() { return entityData.get(JAW); }

    /** Smoothed jaw opening for rendering. */
    public float jaw(float partialTick) { return Mth.lerp(partialTick, jawO, jawNow); }

    @Override
    public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps, boolean teleport) {
        // don't snap: remember the target and glide to it over 3 ticks (like LivingEntity does)
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYRot = yRot;
        this.lerpXRot = xRot;
        this.lerpSteps = 3;
    }

    public float size() { return entityData.get(SIZE); }

    @Override
    protected void defineSynchedData() {
        entityData.define(JAW, 0f);
        entityData.define(SIZE, 2f);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (lerpSteps > 0) {
                double nx = getX() + (lerpX - getX()) / lerpSteps;
                double ny = getY() + (lerpY - getY()) / lerpSteps;
                double nz = getZ() + (lerpZ - getZ()) / lerpSteps;
                float ny2 = getYRot() + Mth.wrapDegrees(lerpYRot - getYRot()) / lerpSteps;
                float nx2 = getXRot() + (lerpXRot - getXRot()) / lerpSteps;
                lerpSteps--;
                setPos(nx, ny, nz);
                setYRot(ny2);
                setXRot(nx2);
            }
            jawO = jawNow;
            jawNow += (jaw() - jawNow) * 0.5f;
            return;
        }
        if (tickCount - lastSteered > 3 || tickCount > 600) discard();
    }

    @Override
    public boolean isPickable() { return false; }

    @Override
    public boolean isPushable() { return false; }

    @Override
    public boolean shouldRenderAtSqrDistance(double distSqr) { return distSqr < 64 * 64; }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this);
    }
}
