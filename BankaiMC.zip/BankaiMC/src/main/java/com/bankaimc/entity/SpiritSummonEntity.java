package com.bankaimc.entity;

import com.bankaimc.ModParticles;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * A giant spirit (drawn with the owner's own skin) that rises out of the ground behind where its owner stood,
 * stays in place leaning over that spot for a few seconds, then fades away. Purely visual: no collision, can't be hit, never saved.
 */
public class SpiritSummonEntity extends Entity {
    public static final int LIFE = 110;     // ticks (5.5s)
    public static final int RISE = 20;
    public static final int SINK = 22;
    private static final EntityDataAccessor<Integer> OWNER = SynchedEntityData.defineId(SpiritSummonEntity.class, EntityDataSerializers.INT);

    public SpiritSummonEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    public static SpiritSummonEntity spawn(ServerLevel level, Entity owner) {
        SpiritSummonEntity s = new SpiritSummonEntity(ModEntities.SPIRIT_SUMMON.get(), level);
        s.entityData.set(OWNER, owner.getId());
        s.followOwner(owner);
        s.yRotO = s.getYRot();
        level.addFreshEntity(s);
        return s;
    }

    public int ownerId() {
        return entityData.get(OWNER);
    }

    public Entity owner() {
        return level().getEntity(ownerId());
    }

    private void followOwner(Entity o) {
        Vec3 back = Vec3.directionFromRotation(0, o.getYRot()).scale(-2.6);
        setPos(o.getX() + back.x, o.getY(), o.getZ() + back.z);
        setYRot(o.getYRot());
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(OWNER, -1);
    }

    @Override
    public void tick() {
        yRotO = getYRot();
        super.tick();
        if (level().isClientSide) return;
        Entity o = owner();
        if (tickCount > LIFE || o == null || !o.isAlive()) {
            discard();
            return;
        }
        // stays exactly where it was summoned (it no longer follows the owner)
        ServerLevel l = (ServerLevel) level();
        Vec3 look = Vec3.directionFromRotation(0, getYRot());
        if (tickCount > RISE && tickCount < LIFE - SINK && tickCount % 3 == 0) {
            // stitches drifting down from its hands, which hang over you
            Vec3 hands = position().add(look.scale(2.4)).add(0, 3.2, 0);
            l.sendParticles(ModParticles.STITCH.get(), hands.x, hands.y, hands.z, 2, 1.2, 0.3, 1.2, 0.0);
        }
        if (tickCount < RISE && tickCount % 2 == 0) {
            l.sendParticles(ModParticles.CRIMSON_SPARK.get(), getX(), getY() + 0.2, getZ(), 6, 1.4, 0.1, 1.4, 0.05);
        }
        if (tickCount >= LIFE - SINK) {
            // fading out, unravelling into thread
            l.sendParticles(ModParticles.STITCH.get(), getX(), getY() + 2.5, getZ(), 6, 1.5, 1.6, 1.5, 0.05);
            l.sendParticles(ModParticles.CRIMSON_SPARK.get(), getX(), getY() + 2.5, getZ(), 3, 1.5, 1.6, 1.5, 0.05);
        }
    }

    @Override
    public boolean isPickable() { return false; }

    @Override
    public boolean isPushable() { return false; }

    @Override
    public boolean shouldRenderAtSqrDistance(double distSqr) { return distSqr < 64 * 64; }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this);
    }
}
