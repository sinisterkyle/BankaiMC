package com.bankaimc.entity;

import com.bankaimc.BankaiMC;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, BankaiMC.MODID);

    /** A giant, temporary, visual-only spirit that rises behind its owner. Never saved to the world. */
    public static final RegistryObject<EntityType<SpiritSummonEntity>> SPIRIT_SUMMON = ENTITIES.register("spirit_summon",
            () -> EntityType.Builder.<SpiritSummonEntity>of(SpiritSummonEntity::new, MobCategory.MISC)
                    .sized(1.0f, 4.0f)
                    .noSave()
                    .noSummon()
                    .fireImmune()
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build("spirit_summon"));

    /** Zabimaru's bone serpent skull (3D model), steered by abilities. Never saved. */
    public static final RegistryObject<EntityType<SerpentSkullEntity>> SERPENT_SKULL = ENTITIES.register("serpent_skull",
            () -> EntityType.Builder.<SerpentSkullEntity>of(SerpentSkullEntity::new, MobCategory.MISC)
                    .sized(1.0f, 1.0f)
                    .noSave()
                    .noSummon()
                    .fireImmune()
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build("serpent_skull"));

    private ModEntities() {}
}
