package com.bankaimc;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Custom particles: every spirit gets its own look. Sprites live in assets/bankaimc/textures/particle. */
public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, BankaiMC.MODID);

    public static final RegistryObject<SimpleParticleType> SAKURA_PETAL = reg("sakura_petal");
    public static final RegistryObject<SimpleParticleType> ICE_SHARD = reg("ice_shard");
    public static final RegistryObject<SimpleParticleType> REIATSU_BLUE = reg("reiatsu_blue");
    public static final RegistryObject<SimpleParticleType> REIATSU_BLACK = reg("reiatsu_black");
    public static final RegistryObject<SimpleParticleType> MIRROR_SHARD = reg("mirror_shard");
    public static final RegistryObject<SimpleParticleType> SHADOW_WISP = reg("shadow_wisp");
    public static final RegistryObject<SimpleParticleType> KIMONO_FLOWER = reg("kimono_flower");
    public static final RegistryObject<SimpleParticleType> EMBER = reg("ember");
    public static final RegistryObject<SimpleParticleType> BLOOD_DROP = reg("blood_drop");
    public static final RegistryObject<SimpleParticleType> HEAL_MOTE = reg("heal_mote");
    public static final RegistryObject<SimpleParticleType> STITCH = reg("stitch");
    public static final RegistryObject<SimpleParticleType> BONE_SHARD = reg("bone_shard");
    public static final RegistryObject<SimpleParticleType> CRIMSON_SPARK = reg("crimson_spark");
    public static final RegistryObject<SimpleParticleType> BLADE_GLINT = reg("blade_glint");
    public static final RegistryObject<SimpleParticleType> POISON_FRAGMENT = reg("poison_fragment");

    private ModParticles() {}

    private static RegistryObject<SimpleParticleType> reg(String name) {
        // true = still shows on "Decreased" particle settings, so abilities stay readable
        return PARTICLES.register(name, () -> new SimpleParticleType(true));
    }

    /** The signature particle of a spirit. */
    public static SimpleParticleType of(Spirit s, boolean bankai) {
        return switch (s) {
            case ZANGETSU -> bankai ? REIATSU_BLACK.get() : REIATSU_BLUE.get();
            case HYORINMARU -> ICE_SHARD.get();
            case SENBONZAKURA -> SAKURA_PETAL.get();
            case KYOKA_SUIGETSU -> MIRROR_SHARD.get();
            case KATEN_KYOKOTSU -> bankai ? SHADOW_WISP.get() : KIMONO_FLOWER.get();
            case RYUJIN_JAKKA -> EMBER.get();
            case MINAZUKI -> bankai ? BLOOD_DROP.get() : HEAL_MOTE.get();
            case BENIHIME -> bankai ? STITCH.get() : CRIMSON_SPARK.get();
            case ZABIMARU -> BONE_SHARD.get();
            case SHINSO -> bankai ? POISON_FRAGMENT.get() : BLADE_GLINT.get();
        };
    }
}
