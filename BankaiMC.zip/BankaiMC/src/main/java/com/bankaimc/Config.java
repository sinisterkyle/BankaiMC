package com.bankaimc;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.ArrayList;
import java.util.List;

public final class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    // ---- Which items can awaken ----
    public static final ForgeConfigSpec.BooleanValue ALL_SWORDS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> NAME_KEYWORDS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> EXTRA_WEAPONS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> COMPAT_MODS;
    public static final ForgeConfigSpec.BooleanValue CREATIVE_CHEATS;

    // ---- Progression ----
    public static final ForgeConfigSpec.BooleanValue HOSTILE_KILLS_ONLY;
    public static final ForgeConfigSpec.BooleanValue PLAYER_KILLS_COUNT;
    public static final ForgeConfigSpec.IntValue SHIKAI_MIN_KILLS;
    public static final ForgeConfigSpec.IntValue SHIKAI_GUARANTEED_KILLS;
    public static final ForgeConfigSpec.DoubleValue SHIKAI_CHANCE;
    public static final ForgeConfigSpec.IntValue BANKAI_MIN_KILLS;
    public static final ForgeConfigSpec.IntValue BANKAI_GUARANTEED_KILLS;
    public static final ForgeConfigSpec.DoubleValue BANKAI_CHANCE;
    public static final ForgeConfigSpec.BooleanValue ANNOUNCE_AWAKENING;

    // ---- Combat ----
    public static final ForgeConfigSpec.DoubleValue DAMAGE_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue COOLDOWN_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue BANKAI_POWER;
    public static final ForgeConfigSpec.IntValue BANKAI_DURATION_SECONDS;
    public static final ForgeConfigSpec.IntValue BANKAI_COOLDOWN_SECONDS;
    public static final ForgeConfigSpec.IntValue HYORINMARU_FLIGHT_SECONDS;
    public static final ForgeConfigSpec.BooleanValue ABILITIES_HIT_PLAYERS;
    public static final ForgeConfigSpec.BooleanValue ABILITIES_HIT_PASSIVE_MOBS;

    static {
        B.comment("Which weapons can hold a zanpakuto spirit").push("weapons");
        ALL_SWORDS = B.comment("Every sword (vanilla or modded, anything extending SwordItem) can awaken.")
                .define("allSwords", true);
        NAME_KEYWORDS = B.comment("Any item whose registry path contains one of these words can awaken (catches modded katanas and blades).")
                .defineList("nameKeywords", List.of("katana", "sword", "blade", "tachi", "odachi", "wakizashi"), o -> o instanceof String);
        EXTRA_WEAPONS = B.comment("Exact item ids that can awaken, e.g. \"minecraft:netherite_axe\".")
                .defineListAllowEmpty(List.of("extraWeapons"), () -> new ArrayList<String>(), o -> o instanceof String);
        COMPAT_MODS = B.comment("Every melee weapon (anything with attack damage) from these mod ids can awaken. Example: [\"somemod\"]")
                .defineListAllowEmpty(List.of("compatMods"), () -> new ArrayList<String>(), o -> o instanceof String);
        B.pop();

        B.comment("Testing").push("testing");
        CREATIVE_CHEATS = B.comment("Players in Creative mode can use the /bankai test commands even if they are not op.")
                .define("creativeCheats", true);
        B.pop();

        B.comment("How a blade awakens. Kills are stored per weapon (on the item itself).").push("progression");
        HOSTILE_KILLS_ONLY = B.comment("Only hostile mobs count as kills (stops chicken/cow farming).")
                .define("hostileKillsOnly", true);
        PLAYER_KILLS_COUNT = B.comment("Killing players counts as a kill.")
                .define("playerKillsCount", true);
        SHIKAI_MIN_KILLS = B.comment("Kills before the spirit can start whispering its name (Shikai).")
                .defineInRange("shikaiMinKills", 500, 0, 1_000_000);
        SHIKAI_CHANCE = B.comment("Chance per kill (after the minimum) to unlock Shikai. 0.004 = 0.4%")
                .defineInRange("shikaiChancePerKill", 0.004, 0.0, 1.0);
        SHIKAI_GUARANTEED_KILLS = B.comment("Shikai is guaranteed by this many kills, so nobody is unlucky forever.")
                .defineInRange("shikaiGuaranteedKills", 1500, 0, 1_000_000);
        BANKAI_MIN_KILLS = B.comment("Total kills before Bankai can be achieved.")
                .defineInRange("bankaiMinKills", 3000, 0, 1_000_000);
        BANKAI_CHANCE = B.comment("Chance per kill (after the minimum) to unlock Bankai. 0.001 = 0.1%")
                .defineInRange("bankaiChancePerKill", 0.001, 0.0, 1.0);
        BANKAI_GUARANTEED_KILLS = B.comment("Bankai is guaranteed by this many kills.")
                .defineInRange("bankaiGuaranteedKills", 8000, 0, 1_000_000);
        ANNOUNCE_AWAKENING = B.comment("Broadcast awakenings to the whole server.")
                .define("announceAwakening", true);
        B.pop();

        B.push("combat");
        DAMAGE_MULTIPLIER = B.comment("Multiplies all ability damage.")
                .defineInRange("damageMultiplier", 1.0, 0.0, 100.0);
        BANKAI_POWER = B.comment("Extra damage multiplier for everything Bankai does (stacks with damageMultiplier). 4.0 = 4x as strong.")
                .defineInRange("bankaiPowerMultiplier", 4.0, 0.0, 100.0);
        COOLDOWN_MULTIPLIER = B.comment("Multiplies all ability cooldowns.")
                .defineInRange("cooldownMultiplier", 1.0, 0.0, 100.0);
        BANKAI_DURATION_SECONDS = B.comment("How long Bankai stays released.")
                .defineInRange("bankaiDurationSeconds", 60, 5, 3600);
        BANKAI_COOLDOWN_SECONDS = B.comment("Rest time after Bankai ends before it can be released again.")
                .defineInRange("bankaiCooldownSeconds", 180, 0, 36000);
        HYORINMARU_FLIGHT_SECONDS = B.comment("Hyorinmaru Bankai: how long the ice wings let you fly after releasing Bankai (0 = no flight).")
                .defineInRange("hyorinmaruFlightSeconds", 10, 0, 3600);
        ABILITIES_HIT_PLAYERS = B.comment("Abilities can hurt other players (respects team/PvP settings).")
                .define("abilitiesHitPlayers", false);
        ABILITIES_HIT_PASSIVE_MOBS = B.comment("Abilities hurt non-hostile mobs too (villagers, animals, golems). Your own pets are always safe.")
                .define("abilitiesHitPassiveMobs", false);
        B.pop();
    }

    public static final ForgeConfigSpec SPEC = B.build();

    private Config() {}
}
