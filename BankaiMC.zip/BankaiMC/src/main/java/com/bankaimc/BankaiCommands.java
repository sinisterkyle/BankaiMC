package com.bankaimc;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandRuntimeException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.item.ItemArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Husk;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Arrays;

/**
 * /bankai test commands. Usable by ops (level 2), or by anyone in Creative mode when creativeCheats = true.
 * Every command works on the weapon in your main hand unless it gives you a new one.
 */
public final class BankaiCommands {
    private BankaiCommands() {}

    private static final SuggestionProvider<CommandSourceStack> SPIRITS =
            (ctx, b) -> SharedSuggestionProvider.suggest(Arrays.stream(Spirit.values()).map(s -> s.id), b);
    private static final SuggestionProvider<CommandSourceStack> STAGES =
            (ctx, b) -> SharedSuggestionProvider.suggest(new String[]{"sealed", "shikai", "bankai"}, b);

    private static boolean allowed(CommandSourceStack src) {
        if (src.hasPermission(2)) return true;
        return Config.CREATIVE_CHEATS.get() && src.getEntity() instanceof ServerPlayer p && p.isCreative();
    }

    public static void register(CommandDispatcher<CommandSourceStack> d, CommandBuildContext build) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("bankai").requires(BankaiCommands::allowed);

        // /bankai help
        root.executes(BankaiCommands::help).then(Commands.literal("help").executes(BankaiCommands::help));

        // /bankai info
        root.then(Commands.literal("info").executes(c -> {
            ItemStack w = held(c);
            Spirit s = ZanpakutoData.getSpirit(w);
            ok(c, "Kills: " + ZanpakutoData.getKills(w) + " | Unlocked: " + stage(ZanpakutoData.getUnlocked(w))
                    + " | Released: " + stage(ZanpakutoData.getRelease(w)) + " | Spirit: " + (s == null ? "none" : s.shikaiName));
            return 1;
        }));

        // /bankai spirits
        root.then(Commands.literal("spirits").executes(c -> {
            for (Spirit s : Spirit.values()) {
                c.getSource().sendSuccess(() -> Component.literal(s.id).withStyle(st -> st.withColor(s.shikaiColor))
                        .append(Component.literal("  " + s.shikaiAbility + " / Bankai: " + s.bankaiAbility).withStyle(ChatFormatting.GRAY)), false);
            }
            return Spirit.values().length;
        }));

        // /bankai test <spirit> [weapon]  -> fresh weapon, Bankai unlocked, test mode on
        root.then(Commands.literal("test")
                .then(Commands.argument("spirit", StringArgumentType.word()).suggests(SPIRITS)
                        .executes(c -> test(c, defaultWeapon()))
                        .then(Commands.argument("weapon", ItemArgument.item(build))
                                .executes(c -> test(c, ItemArgument.getItem(c, "weapon").createItemStack(1, false))))));

        // /bankai give <spirit> <stage> [weapon]
        root.then(Commands.literal("give")
                .then(Commands.argument("spirit", StringArgumentType.word()).suggests(SPIRITS)
                        .then(Commands.argument("stage", StringArgumentType.word()).suggests(STAGES)
                                .executes(c -> give(c, defaultWeapon()))
                                .then(Commands.argument("weapon", ItemArgument.item(build))
                                        .executes(c -> give(c, ItemArgument.getItem(c, "weapon").createItemStack(1, false)))))));

        // /bankai unlock shikai [spirit] | /bankai unlock bankai [spirit]
        root.then(Commands.literal("unlock")
                .then(Commands.literal("shikai")
                        .executes(c -> unlock(c, null, false))
                        .then(Commands.argument("spirit", StringArgumentType.word()).suggests(SPIRITS)
                                .executes(c -> unlock(c, spirit(c), false))))
                .then(Commands.literal("bankai")
                        .executes(c -> unlock(c, null, true))
                        .then(Commands.argument("spirit", StringArgumentType.word()).suggests(SPIRITS)
                                .executes(c -> unlock(c, spirit(c), true)))));

        // old shortcuts
        root.then(Commands.literal("shikai").executes(c -> unlock(c, null, false))
                .then(Commands.argument("spirit", StringArgumentType.word()).suggests(SPIRITS).executes(c -> unlock(c, spirit(c), false))));
        root.then(Commands.literal("bankai").executes(c -> unlock(c, null, true)));

        // /bankai release <sealed|shikai|bankai>  -> force a release state (skips the R key)
        root.then(Commands.literal("release")
                .then(Commands.argument("stage", StringArgumentType.word()).suggests(STAGES).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    ItemStack w = held(c);
                    int target = parseStage(StringArgumentType.getString(c, "stage"));
                    if (ZanpakutoData.getSpirit(w) == null) throw err("This blade has no spirit yet. Use /bankai unlock shikai first.");
                    if (ZanpakutoData.getUnlocked(w) < target) ZanpakutoData.setUnlocked(w, target);
                    ZanpakutoData.setRelease(w, target);
                    ZanpakutoData.setBankaiCd(w, 0);
                    ZanpakutoData.setReleaseEnd(w, p.level().getGameTime() + Config.BANKAI_DURATION_SECONDS.get() * 20L);
                    if (target != ZanpakutoData.SEALED) com.bankaimc.ability.Kits.get(ZanpakutoData.getSpirit(w)).onRelease(p, w, target == ZanpakutoData.BANKAI);
                    ok(c, "Released: " + stage(target));
                    return 1;
                })));

        // /bankai cooldowns  -> clear ability cooldown and Bankai rest
        root.then(Commands.literal("cooldowns").executes(c -> {
            ItemStack w = held(c);
            ZanpakutoData.setAbilityCd(w, 0);
            ZanpakutoData.setBankaiCd(w, 0);
            ZanpakutoData.setAltCd(w, 0);
            ZanpakutoData.setReiatsu(w, 100);
            ok(c, "Cooldowns cleared (and Zangetsu reiatsu filled).");
            return 1;
        }));

        // /bankai testmode [on|off]
        root.then(Commands.literal("testmode")
                .executes(c -> testMode(c, !Progression.isTestMode(c.getSource().getPlayerOrException())))
                .then(Commands.argument("enabled", BoolArgumentType.bool())
                        .executes(c -> testMode(c, BoolArgumentType.getBool(c, "enabled")))));

        // /bankai kills <n>   (just sets the counter)
        root.then(Commands.literal("kills").then(Commands.argument("amount", IntegerArgumentType.integer(0)).executes(c -> {
            int amt = IntegerArgumentType.getInteger(c, "amount");
            ZanpakutoData.setKills(held(c), amt);
            ok(c, "Kills set to " + amt + ".");
            return 1;
        })));

        // /bankai simulate <n>  -> pretend you got n kills, with the real random awakening rolls
        root.then(Commands.literal("simulate").then(Commands.argument("kills", IntegerArgumentType.integer(1, 100000)).executes(c -> {
            ServerPlayer p = c.getSource().getPlayerOrException();
            ItemStack w = held(c);
            int n = IntegerArgumentType.getInteger(c, "kills");
            int before = ZanpakutoData.getUnlocked(w);
            for (int i = 0; i < n; i++) {
                Progression.onKill(p, w);
            }
            int after = ZanpakutoData.getUnlocked(w);
            ok(c, "Simulated " + n + " kills. Now at " + ZanpakutoData.getKills(w) + " kills, "
                    + (after > before ? "awakened to " + stage(after) + "!" : "still " + stage(after) + "."));
            return 1;
        })));

        // /bankai dummies [count]  -> spawn husks in a ring to try abilities on
        root.then(Commands.literal("dummies")
                .executes(c -> dummies(c, 8))
                .then(Commands.argument("count", IntegerArgumentType.integer(1, 50))
                        .executes(c -> dummies(c, IntegerArgumentType.getInteger(c, "count")))));

        // /bankai reset
        root.then(Commands.literal("reset").executes(c -> {
            ZanpakutoData.reset(held(c));
            ok(c, "Blade reset to a plain weapon.");
            return 1;
        }));

        d.register(root);
    }

    // ---------------------------------------------------------------- actions

    private static int help(CommandContext<CommandSourceStack> c) {
        String[] lines = {
                "/bankai test <spirit> [weapon] - new weapon with Bankai + test mode",
                "/bankai give <spirit> <sealed|shikai|bankai> [weapon]",
                "/bankai unlock <shikai|bankai> [spirit] - upgrade held weapon",
                "/bankai release <sealed|shikai|bankai> - force release state",
                "/bankai testmode [true|false] - no cooldowns, endless Bankai",
                "/bankai cooldowns - clear cooldowns on held weapon",
                "/bankai simulate <kills> - fake kills with real awakening rolls",
                "/bankai kills <n> | info | spirits | dummies [n] | reset"
        };
        c.getSource().sendSuccess(() -> Component.literal("BankaiMC test commands").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        for (String l : lines) c.getSource().sendSuccess(() -> Component.literal(l).withStyle(ChatFormatting.GRAY), false);
        return 1;
    }

    private static int test(CommandContext<CommandSourceStack> c, ItemStack weapon) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        Spirit s = spirit(c);
        checkEligible(weapon);
        ZanpakutoData.setKills(weapon, Config.BANKAI_MIN_KILLS.get());
        ZanpakutoData.setSpirit(weapon, s);
        ZanpakutoData.setUnlocked(weapon, ZanpakutoData.BANKAI);
        hand(p, weapon);
        Progression.setTestMode(p, true);
        ok(c, s.bankaiName + " is ready. Test mode ON (no cooldowns). R = release, V = ability. /bankai dummies for targets.");
        return 1;
    }

    private static int give(CommandContext<CommandSourceStack> c, ItemStack weapon) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        Spirit s = spirit(c);
        int st = parseStage(StringArgumentType.getString(c, "stage"));
        checkEligible(weapon);
        if (st >= ZanpakutoData.SHIKAI) {
            ZanpakutoData.setSpirit(weapon, s);
            ZanpakutoData.setKills(weapon, st == ZanpakutoData.BANKAI ? Config.BANKAI_MIN_KILLS.get() : Config.SHIKAI_MIN_KILLS.get());
        } else {
            ZanpakutoData.setKills(weapon, 0);
        }
        ZanpakutoData.setUnlocked(weapon, st);
        hand(p, weapon);
        ok(c, "Gave a " + stage(st) + " " + (st > 0 ? s.shikaiName : "blade") + ".");
        return 1;
    }

    private static int unlock(CommandContext<CommandSourceStack> c, Spirit chosen, boolean bankai) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ItemStack w = held(c);
        Spirit current = ZanpakutoData.getSpirit(w);
        if (current == null || chosen != null) {
            Spirit s = chosen != null ? chosen : Spirit.values()[p.getRandom().nextInt(Spirit.values().length)];
            ZanpakutoData.setRelease(w, ZanpakutoData.SEALED);
            ZanpakutoData.setUnlocked(w, ZanpakutoData.SEALED);
            Progression.awakenShikai(p, w, s);
        }
        if (bankai) Progression.awakenBankai(p, w);
        return 1;
    }

    private static int testMode(CommandContext<CommandSourceStack> c, boolean on) throws CommandSyntaxException {
        Progression.setTestMode(c.getSource().getPlayerOrException(), on);
        ok(c, "Test mode " + (on ? "ON: no cooldowns, Bankai never runs out." : "OFF."));
        return 1;
    }

    private static int dummies(CommandContext<CommandSourceStack> c, int count) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerLevel level = p.serverLevel();
        for (int i = 0; i < count; i++) {
            double a = Math.PI * 2 * i / count;
            Husk husk = EntityType.HUSK.create(level);
            if (husk == null) continue;
            husk.moveTo(p.getX() + Math.cos(a) * 7, p.getY(), p.getZ() + Math.sin(a) * 7, (float) Math.toDegrees(a) + 90, 0);
            husk.finalizeSpawn(level, level.getCurrentDifficultyAt(husk.blockPosition()), MobSpawnType.COMMAND, null, null);
            husk.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            level.addFreshEntity(husk);
        }
        ok(c, "Spawned " + count + " husks.");
        return count;
    }

    // ---------------------------------------------------------------- helpers

    /** BankaiMC's netherite katana. */
    private static ItemStack defaultWeapon() {
        return new ItemStack(com.bankaimc.item.ModBlades.get(com.bankaimc.item.ModBlades.BladeTier.NETHERITE,
                com.bankaimc.item.ModBlades.BladeType.KATANA));
    }

    private static void hand(ServerPlayer p, ItemStack weapon) {
        ItemStack old = p.getMainHandItem();
        p.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, weapon);
        if (!old.isEmpty() && !p.getInventory().add(old)) p.drop(old, false);
    }

    private static void checkEligible(ItemStack w) {
        if (!ZanpakutoData.isEligible(w)) {
            throw err("That item can't hold a zanpakuto spirit. Add it to extraWeapons in the config.");
        }
    }

    private static ItemStack held(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ItemStack w = c.getSource().getPlayerOrException().getMainHandItem();
        checkEligible(w);
        return w;
    }

    private static Spirit spirit(CommandContext<CommandSourceStack> c) {
        Spirit s = Spirit.byId(StringArgumentType.getString(c, "spirit"));
        if (s == null) throw err("Unknown spirit. Try /bankai spirits");
        return s;
    }

    private static int parseStage(String s) {
        return switch (s.toLowerCase()) {
            case "sealed" -> ZanpakutoData.SEALED;
            case "shikai" -> ZanpakutoData.SHIKAI;
            case "bankai" -> ZanpakutoData.BANKAI;
            default -> throw err("Stage must be sealed, shikai or bankai.");
        };
    }

    private static String stage(int stage) {
        return switch (stage) {
            case ZanpakutoData.SHIKAI -> "Shikai";
            case ZanpakutoData.BANKAI -> "Bankai";
            default -> "Sealed";
        };
    }

    private static void ok(CommandContext<CommandSourceStack> c, String msg) {
        c.getSource().sendSuccess(() -> Component.literal(msg).withStyle(ChatFormatting.GREEN), false);
    }

    private static CommandRuntimeException err(String msg) {
        return new CommandRuntimeException(Component.literal(msg));
    }
}
