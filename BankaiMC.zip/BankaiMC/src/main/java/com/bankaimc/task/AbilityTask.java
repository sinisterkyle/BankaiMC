package com.bankaimc.task;

/** A server-side effect that runs over several ticks. Return true from tick() when finished. */
public interface AbilityTask {
    boolean tick();
}
