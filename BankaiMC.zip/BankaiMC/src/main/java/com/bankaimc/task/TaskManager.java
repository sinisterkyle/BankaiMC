package com.bankaimc.task;

import com.bankaimc.BankaiMC;

import java.util.ArrayList;
import java.util.List;

public final class TaskManager {
    private static final List<AbilityTask> ACTIVE = new ArrayList<>();
    private static final List<AbilityTask> PENDING = new ArrayList<>();

    private TaskManager() {}

    public static void add(AbilityTask task) {
        PENDING.add(task);
    }

    public static void tick() {
        ACTIVE.addAll(PENDING);
        PENDING.clear();
        ACTIVE.removeIf(t -> {
            try {
                return t.tick();
            } catch (Exception e) {
                BankaiMC.LOGGER.error("BankaiMC ability task crashed, removing it", e);
                return true;
            }
        });
    }

    public static void clear() {
        ACTIVE.clear();
        PENDING.clear();
    }
}
