package com.bankaimc.task;

import net.minecraft.server.level.ServerPlayer;

import java.util.function.IntConsumer;

/** Runs an action every tick for a fixed duration. Ends early if the caster logs out or dies. */
public class TimedTask implements AbilityTask {
    private final ServerPlayer owner;
    private final int duration;
    private final IntConsumer action;
    private int age = 0;

    public TimedTask(ServerPlayer owner, int durationTicks, IntConsumer action) {
        this.owner = owner;
        this.duration = durationTicks;
        this.action = action;
    }

    @Override
    public boolean tick() {
        if (owner.isRemoved() || !owner.isAlive()) return true;
        action.accept(age);
        age++;
        return age >= duration;
    }
}
