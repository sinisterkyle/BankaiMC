package com.bankaimc.task;

import com.bankaimc.Targeting;
import com.bankaimc.ability.Fx;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

/** A projectile-like attack that flies where you are looking (Getsuga Tensho, ice dragon...). Visuals are supplied by the caller. */
public class WaveTask implements AbilityTask {

    /** Draws one step of the wave. */
    @FunctionalInterface
    public interface Visual {
        void draw(ServerLevel level, Vec3 pos, Vec3 dir, Vec3 right, double halfWidth, int step);
    }

    private final ServerPlayer owner;
    private final ServerLevel level;
    private final Vec3 dir, right;
    private final double speed, maxDist, halfWidth;
    private final float damage;
    private final Visual visual;
    private final ParticleOptions impact;
    private final Consumer<LivingEntity> onHit;
    private final Set<UUID> hit = new HashSet<>();
    private Vec3 pos;
    private double travelled = 0;
    private int step = 0;

    public WaveTask(ServerPlayer owner, double speed, double maxDist, double halfWidth, float damage,
                    Visual visual, ParticleOptions impact, Consumer<LivingEntity> onHit) {
        this.owner = owner;
        this.level = owner.serverLevel();
        this.dir = owner.getLookAngle().normalize();
        Vec3 r = dir.cross(new Vec3(0, 1, 0));
        this.right = r.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : r.normalize();
        this.pos = owner.getEyePosition().subtract(0, 0.3, 0).add(dir.scale(1.2));
        this.speed = speed;
        this.maxDist = maxDist;
        this.halfWidth = halfWidth;
        this.damage = damage;
        this.visual = visual;
        this.impact = impact;
        this.onHit = onHit;
    }

    @Override
    public boolean tick() {
        if (owner.isRemoved()) return true;
        int steps = Math.max(1, (int) Math.ceil(speed / 0.6));
        double stepLen = speed / steps;
        for (int s = 0; s < steps; s++) {
            pos = pos.add(dir.scale(stepLen));
            travelled += stepLen;
            step++;
            BlockPos bp = BlockPos.containing(pos);
            if (!level.getBlockState(bp).getCollisionShape(level, bp).isEmpty()) {
                Fx.burst(level, impact, pos, 40, 0.35);
                return true;
            }
            visual.draw(level, pos, dir, right, halfWidth, step);
            hitEntities();
            if (travelled >= maxDist) {
                Fx.burst(level, impact, pos, 25, 0.25);
                return true;
            }
        }
        return step > 600;
    }

    private void hitEntities() {
        AABB box = new AABB(pos, pos).inflate(halfWidth, 1.3, halfWidth);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> Targeting.valid(owner, e))) {
            if (hit.add(e.getUUID())) {
                Fx.damage(owner, e, damage);
                Fx.burst(level, impact, e.position().add(0, e.getBbHeight() / 2, 0), 15, 0.2);
                if (onHit != null) onHit.accept(e);
            }
        }
    }
}
