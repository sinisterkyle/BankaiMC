package com.bankaimc.client;

import com.bankaimc.BankaiMC;
import com.bankaimc.entity.SerpentSkullEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** The bone serpent skull: a snake's head in white bone and red, with a lower jaw that unhinges wide. */
public class SerpentSkullRenderer extends EntityRenderer<SerpentSkullEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(BankaiMC.MODID, "serpent_skull"), "main");
    private static final ResourceLocation TEXTURE = new ResourceLocation(BankaiMC.MODID, "textures/entity/serpent_skull.png");

    private final ModelPart root;
    private final ModelPart jaw;

    public SerpentSkullRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.root = ctx.bakeLayer(LAYER).getChild("skull");
        this.jaw = root.getChild("jaw");
    }

    /**
     * Snake skull, in pixels, snout pointing to -Z: a flat wide head tapering to a narrow snout, two long fangs
     * raked back, a thin V-shaped lower jaw that unhinges wide, and a forked tongue.
     * Keep in sync with the texture script (tools/skull.py).
     */
    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition skull = mesh.getRoot().addOrReplaceChild("skull", CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-5.0f, -3.0f, -2.0f, 10, 4, 7)         // wide back of the head
                        .texOffs(0, 11).addBox(-4.0f, -3.0f, -7.0f, 8, 3, 5)         // middle, narrowing
                        .texOffs(0, 19).addBox(-3.0f, -2.5f, -11.0f, 6, 3, 4)        // narrow snout
                        .texOffs(34, 0).addBox(-4.5f, -3.5f, -5.0f, 2, 1, 2)         // scale over the left eye
                        .texOffs(34, 3).addBox(2.5f, -3.5f, -5.0f, 2, 1, 2),         // scale over the right eye
                PartPose.ZERO);
        // fangs hang from the front of the upper jaw, raked back toward the throat
        skull.addOrReplaceChild("fang_l", CubeListBuilder.create().texOffs(42, 0).addBox(-0.5f, 0.0f, -0.5f, 1, 3, 1),
                PartPose.offsetAndRotation(-2.0f, 0.4f, -9.5f, 0.35f, 0.0f, 0.0f));
        skull.addOrReplaceChild("fang_r", CubeListBuilder.create().texOffs(42, 0).addBox(-0.5f, 0.0f, -0.5f, 1, 3, 1),
                PartPose.offsetAndRotation(2.0f, 0.4f, -9.5f, 0.35f, 0.0f, 0.0f));
        // lower jaw: two thin bars meeting at a small chin, hinged at the back of the head
        PartDefinition jaw = skull.addOrReplaceChild("jaw", CubeListBuilder.create()
                        .texOffs(0, 26).addBox(-4.5f, 0.0f, -10.0f, 2, 1, 10)        // left bar
                        .texOffs(24, 26).addBox(2.5f, 0.0f, -10.0f, 2, 1, 10)        // right bar
                        .texOffs(48, 26).addBox(-2.5f, 0.0f, -11.0f, 5, 1, 2),       // chin
                PartPose.offset(0.0f, 0.5f, 2.0f));
        // forked tongue lying along the lower jaw
        jaw.addOrReplaceChild("tongue", CubeListBuilder.create()
                        .texOffs(0, 40).addBox(-0.5f, -0.5f, -12.0f, 1, 0.5f, 7)
                        .texOffs(16, 40).addBox(-1.2f, -0.5f, -13.5f, 0.5f, 0.5f, 1.5f)
                        .texOffs(16, 40).addBox(0.7f, -0.5f, -13.5f, 0.5f, 0.5f, 1.5f),
                PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public ResourceLocation getTextureLocation(SerpentSkullEntity e) {
        return TEXTURE;
    }

    @Override
    public void render(SerpentSkullEntity e, float entityYaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        float yaw = Mth.rotLerp(partialTick, e.yRotO, e.getYRot());
        float pitch = Mth.lerp(partialTick, e.xRotO, e.getXRot());
        float size = e.size();
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(180.0f - yaw));
        pose.scale(size, size, size);
        pose.scale(-1.0f, -1.0f, 1.0f);
        root.xRot = pitch * Mth.DEG_TO_RAD;
        jaw.xRot = e.jaw(partialTick) * 1.2f;     // snakes unhinge wide: up to ~70 degrees
        root.render(pose, buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE)), light, OverlayTexture.NO_OVERLAY);
        pose.popPose();
        super.render(e, entityYaw, partialTick, pose, buffers, light);
    }
}
