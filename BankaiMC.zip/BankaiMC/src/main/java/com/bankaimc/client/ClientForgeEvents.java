package com.bankaimc.client;

import com.bankaimc.BankaiMC;
import com.bankaimc.Spirit;
import com.bankaimc.ZanpakutoData;
import com.bankaimc.network.Network;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;


@Mod.EventBusSubscriber(modid = BankaiMC.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || Minecraft.getInstance().player == null) return;
        while (ClientModEvents.RELEASE.consumeClick()) {
            Network.CHANNEL.sendToServer(new Network.KeyPacket(Network.KeyPacket.RELEASE));
        }
        while (ClientModEvents.ABILITY.consumeClick()) {
            Network.CHANNEL.sendToServer(new Network.KeyPacket(Network.KeyPacket.ABILITY));
        }
    }

    /** Item lore: just the spirit's name, in its color. Nothing until the blade has awakened. */
    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent event) {
        ItemStack stack = event.getItemStack();
        if (!ZanpakutoData.hasData(stack)) return;
        Spirit s = ZanpakutoData.getSpirit(stack);
        if (s == null) return;
        event.getToolTip().add(Component.literal(s.shikaiName).withStyle(st -> st.withColor(s.shikaiColor).withItalic(true)));
    }
}
