package com.bankaimc.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

/** One particle class, tuned per spirit through {@link Preset}. */
public class BankaiParticle extends TextureSheetParticle {

    public enum Preset {
        //            gravity friction minLife lifeVar size  spin  sway  glow   physics shrink grow
        SAKURA(        0.03f,  0.96f,   45,     35,   0.13f, 0.25f, 1.0f, false, true,  false, false),
        ICE(           0.30f,  0.94f,   25,     20,   0.11f, 0.35f, 0.0f, true,  true,  false, false),
        REIATSU(      -0.02f,  0.86f,   10,     10,   0.24f, 0.08f, 0.0f, true,  false, true,  false),
        MIRROR(        0.00f,  0.90f,   20,     20,   0.12f, 0.40f, 0.0f, true,  false, false, false),
        SHADOW(       -0.03f,  0.90f,   20,     20,   0.22f, 0.05f, 0.3f, false, false, false, true),
        FLOWER(        0.02f,  0.95f,   45,     30,   0.11f, 0.15f, 0.8f, false, true,  false, false),
        EMBER(        -0.06f,  0.92f,   15,     20,   0.08f, 0.10f, 0.4f, true,  false, true,  false),
        BLOOD(         0.70f,  0.96f,   20,     20,   0.09f, 0.00f, 0.0f, false, true,  false, false),
        HEAL(         -0.03f,  0.90f,   20,     15,   0.10f, 0.05f, 0.5f, true,  false, true,  false),
        STITCH(        0.00f,  0.80f,   25,     15,   0.11f, 0.00f, 0.0f, true,  false, false, false),
        BONE(          0.10f,  0.90f,   18,     14,   0.14f, 0.20f, 0.0f, false, false, false, false),
        SPARK(         0.00f,  0.85f,    8,     10,   0.09f, 0.30f, 0.0f, true,  false, true,  false);

        final float gravity, friction, size, spin, sway;
        final int minLife, lifeVar;
        final boolean glow, physics, shrink, grow;

        Preset(float gravity, float friction, int minLife, int lifeVar, float size, float spin, float sway,
               boolean glow, boolean physics, boolean shrink, boolean grow) {
            this.gravity = gravity; this.friction = friction; this.minLife = minLife; this.lifeVar = lifeVar;
            this.size = size; this.spin = spin; this.sway = sway; this.glow = glow; this.physics = physics;
            this.shrink = shrink; this.grow = grow;
        }
    }

    private final Preset preset;
    private final float spinSpeed;
    private final float swayPhase;
    private final float startSize;

    protected BankaiParticle(ClientLevel level, double x, double y, double z, double xd, double yd, double zd,
                             Preset preset, SpriteSet sprites) {
        super(level, x, y, z);
        this.preset = preset;
        this.xd = xd;
        this.yd = yd;
        this.zd = zd;
        this.gravity = preset.gravity;
        this.friction = preset.friction;
        this.hasPhysics = preset.physics;
        this.lifetime = preset.minLife + random.nextInt(preset.lifeVar + 1);
        this.startSize = preset.size * (0.7f + random.nextFloat() * 0.6f);
        this.quadSize = startSize;
        this.roll = random.nextFloat() * Mth.TWO_PI;
        this.oRoll = roll;
        this.spinSpeed = (random.nextFloat() - 0.5f) * 2f * preset.spin;
        this.swayPhase = random.nextFloat() * Mth.TWO_PI;
        pickSprite(sprites);
    }

    @Override
    public void tick() {
        oRoll = roll;
        super.tick();
        if (removed) return;
        roll += spinSpeed;
        float life = (float) age / lifetime;
        if (preset.sway > 0) {
            // drifting side to side like a falling petal
            xd += Mth.sin(age * 0.25f + swayPhase) * 0.004f * preset.sway;
            zd += Mth.cos(age * 0.21f + swayPhase) * 0.004f * preset.sway;
            if (onGround) spinSpeedStop();
        }
        if (preset.shrink) quadSize = startSize * (1f - life * 0.8f);
        if (preset.grow) quadSize = startSize * (1f + life * 1.2f);
        alpha = life > 0.7f ? 1f - (life - 0.7f) / 0.3f : 1f;
        if (preset == Preset.MIRROR) alpha *= 0.6f + 0.4f * Mth.abs(Mth.sin(age * 0.6f + swayPhase)); // glinting
    }

    private void spinSpeedStop() {
        roll = oRoll;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public int getLightColor(float partialTick) {
        return preset.glow ? 0xF000F0 : super.getLightColor(partialTick);
    }

    public static ParticleProvider<SimpleParticleType> provider(SpriteSet sprites, Preset preset) {
        return (type, level, x, y, z, xd, yd, zd) -> new BankaiParticle(level, x, y, z, xd, yd, zd, preset, sprites);
    }
}
