package com.bankaimc.client;

import com.bankaimc.BankaiMC;
import com.bankaimc.entity.SpiritSummonEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Draws the spirit summon with Minecraft's own player model and the Benihime spirit skin, giant, glowing, waist-up out of the ground, leaning over where its owner stood.
 */
public class SpiritSummonRenderer extends EntityRenderer<SpiritSummonEntity> {
    private static final float SCALE = 3.5f;
    private static final String[] PARTS = {"head", "hat", "body", "jacket", "right_arm", "left_arm", "right_sleeve", "left_sleeve"};

    private final ModelPart wide;

    public SpiritSummonRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.wide = ctx.bakeLayer(ModelLayers.PLAYER);
    }

    /** The spirit always wears this skin (made by the BankaiMC author). Classic/wide arms. */
    private static final ResourceLocation SKIN = new ResourceLocation(BankaiMC.MODID, "textures/entity/benihime_spirit.png");

    @Override
    public ResourceLocation getTextureLocation(SpiritSummonEntity e) {
        return SKIN;
    }

    @Override
    public void render(SpiritSummonEntity e, float entityYaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        float age = e.tickCount + partialTick;
        ModelPart root = wide;

        // rise out of the ground, hold, then FADE OUT in place (it doesn't sink back down)
        float rise = Mth.clamp(age / SpiritSummonEntity.RISE, 0f, 1f);
        rise = 1f - (1f - rise) * (1f - rise) * (1f - rise);                     // ease out
        float fade = Mth.clamp((SpiritSummonEntity.LIFE - age) / SpiritSummonEntity.SINK, 0f, 1f);
        float up = rise;                                                          // 0 = underground, 1 = fully risen
        float alpha = 0.8f * Math.min(rise * 1.5f, 1f) * fade * fade;             // smooth fade at the end
        if (alpha <= 0.02f) return;

        float sway = Mth.sin(age * 0.06f);

        // pose every part
        for (String n : PARTS) root.getChild(n).resetPose();
        ModelPart head = root.getChild("head"), rArm = root.getChild("right_arm"), lArm = root.getChild("left_arm");
        head.xRot = 0.55f;                                     // looking down at you
        head.yRot = sway * 0.08f;
        rArm.xRot = -1.05f + sway * 0.06f;                     // arms reaching forward, around you
        rArm.zRot = 0.32f;
        lArm.xRot = -1.05f - sway * 0.06f;
        lArm.zRot = -0.32f;
        root.getChild("hat").copyFrom(head);
        root.getChild("right_sleeve").copyFrom(rArm);
        root.getChild("left_sleeve").copyFrom(lArm);
        root.getChild("jacket").copyFrom(root.getChild("body"));

        pose.pushPose();
        float yaw = Mth.rotLerp(partialTick, e.yRotO, e.getYRot());
        pose.mulPose(Axis.YP.rotationDegrees(180.0f - yaw));
        pose.scale(SCALE, SCALE, SCALE);
        pose.scale(-1.0f, -1.0f, 1.0f);                       // model space: y points down, like vanilla
        // waist (bottom of the torso) at ground level once risen; starts fully underground
        pose.translate(0.0f, -0.75f + (1f - up) * 1.6f, 0.0f);
        // lean forward over the owner, pivoting at the waist, with a slow sway
        pose.translate(0.0f, 0.75f, 0.0f);
        pose.mulPose(Axis.XP.rotation(0.42f));
        pose.mulPose(Axis.ZP.rotation(sway * 0.035f));
        pose.translate(0.0f, -0.75f, 0.0f);

        VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucent(getTextureLocation(e)));
        int glow = 0xF000F0; // full bright: it's a spirit
        for (String n : PARTS) {
            root.getChild(n).render(pose, vc, glow, OverlayTexture.NO_OVERLAY, 1.0f, 0.55f, 0.62f, alpha);  // crimson spirit tint
        }
        pose.popPose();
        super.render(e, entityYaw, partialTick, pose, buffers, light);
    }
}
