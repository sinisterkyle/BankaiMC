package com.bankaimc.client;

import com.bankaimc.BankaiMC;
import com.bankaimc.ModParticles;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = BankaiMC.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    public static final String CATEGORY = "key.categories.bankaimc";
    public static final KeyMapping RELEASE = new KeyMapping("key.bankaimc.release", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, CATEGORY);
    public static final KeyMapping ABILITY = new KeyMapping("key.bankaimc.ability", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY);

    private ClientModEvents() {}

    @SubscribeEvent
    public static void onKeys(RegisterKeyMappingsEvent event) {
        event.register(RELEASE);
        event.register(ABILITY);
    }

    @SubscribeEvent
    public static void onParticles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.SAKURA_PETAL.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.SAKURA));
        event.registerSpriteSet(ModParticles.ICE_SHARD.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.ICE));
        event.registerSpriteSet(ModParticles.REIATSU_BLUE.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.REIATSU));
        event.registerSpriteSet(ModParticles.REIATSU_BLACK.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.REIATSU));
        event.registerSpriteSet(ModParticles.MIRROR_SHARD.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.MIRROR));
        event.registerSpriteSet(ModParticles.SHADOW_WISP.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.SHADOW));
        event.registerSpriteSet(ModParticles.KIMONO_FLOWER.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.FLOWER));
        event.registerSpriteSet(ModParticles.EMBER.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.EMBER));
        event.registerSpriteSet(ModParticles.BLOOD_DROP.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.BLOOD));
        event.registerSpriteSet(ModParticles.HEAL_MOTE.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.HEAL));
        event.registerSpriteSet(ModParticles.STITCH.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.STITCH));
        event.registerSpriteSet(ModParticles.BONE_SHARD.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.BONE));
        event.registerSpriteSet(ModParticles.CRIMSON_SPARK.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.SPARK));
        event.registerSpriteSet(ModParticles.BLADE_GLINT.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.SPARK));
        event.registerSpriteSet(ModParticles.POISON_FRAGMENT.get(), s -> BankaiParticle.provider(s, BankaiParticle.Preset.MIRROR));
    }

    @SubscribeEvent
    public static void onLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(OutfitModels.HAORI, () -> OutfitModels.createHaori(true));
        event.registerLayerDefinition(OutfitModels.KENPACHI, () -> OutfitModels.createHaori(false));
        event.registerLayerDefinition(OutfitModels.HAT, OutfitModels::createHat);
        event.registerLayerDefinition(SerpentSkullRenderer.LAYER, SerpentSkullRenderer::createLayer);
    }

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(com.bankaimc.entity.ModEntities.SPIRIT_SUMMON.get(), SpiritSummonRenderer::new);
        event.registerEntityRenderer(com.bankaimc.entity.ModEntities.SERPENT_SKULL.get(), SerpentSkullRenderer::new);
    }

    @SubscribeEvent
    public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
        OutfitModels.clearCache(); // models get re-baked after a resource reload
    }

    @SubscribeEvent
    public static void onOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("zanpakuto_hud", BankaiHud::render);
    }
}
