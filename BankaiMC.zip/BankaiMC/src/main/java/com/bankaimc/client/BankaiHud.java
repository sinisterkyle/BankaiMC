package com.bankaimc.client;

import com.bankaimc.Spirit;
import com.bankaimc.ZanpakutoData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.gui.overlay.ForgeGui;

import com.bankaimc.BankaiMC;

/** Small panel in the top-left showing the held zanpakuto's state. */
public final class BankaiHud {
    private static final ResourceLocation SEALED_ICON = BankaiMC.id("textures/gui/spirit/sealed.png");

    /** Size of the panel. 1.0 = full size. */
    private static final float SCALE = 0.55f;

    private BankaiHud() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        ItemStack w = mc.player.getMainHandItem();
        if (!ZanpakutoData.hasData(w)) return;

        Font font = mc.font;
        Spirit s = ZanpakutoData.getSpirit(w);
        int release = ZanpakutoData.getRelease(w);
        long now = mc.level.getGameTime();
        boolean bankai = release == ZanpakutoData.BANKAI;
        boolean meter = s == Spirit.ZANGETSU && release != ZanpakutoData.SEALED;
        int lines = s == null ? 2 : (release == ZanpakutoData.SEALED ? 3 : 4) + (meter ? 1 : 0);
        int panelW = s == null ? 110 : 193;
        int panelH = Math.max(38, 6 + lines * 11);

        // bottom-left corner, shrunk
        g.pose().pushPose();
        g.pose().translate(3f, height - 3f - panelH * SCALE, 0f);
        g.pose().scale(SCALE, SCALE, 1f);
        try {
            draw(g, font, w, s, release, now, bankai, meter, panelW, panelH);
        } finally {
            g.pose().popPose();
        }
    }

    private static void draw(GuiGraphics g, Font font, ItemStack w, Spirit s, int release, long now,
                             boolean bankai, boolean meter, int panelW, int panelH) {
        int x = 3, y = 3, tx = x + 37;
        g.fill(0, 0, panelW, panelH, 0x88000000);
        g.blit(s == null ? SEALED_ICON : s.icon, x, y, 0f, 0f, 32, 32, 32, 32);

        if (s == null) {
            g.drawString(font, "Sealed Blade", tx, y + 2, 0xAAAAAA);
            g.drawString(font, "Kills: " + ZanpakutoData.getKills(w), tx, y + 13, 0x888888);
            return;
        }
        String name;
        int color;
        switch (release) {
            case ZanpakutoData.BANKAI -> { name = s.bankaiName; color = s.bankaiColor; }
            case ZanpakutoData.SHIKAI -> { name = s.shikaiName; color = s.shikaiColor; }
            default -> { name = s.shikaiName + " (sealed)"; color = 0xAAAAAA; }
        }
        int ly = y + 1;
        g.drawString(font, font.plainSubstrByWidth(name, 150), tx, ly, color);
        ly += 11;
        String sub = "Kills: " + ZanpakutoData.getKills(w);
        if (bankai) sub += "   Bankai " + Math.max(0, ZanpakutoData.getReleaseEnd(w) - now) / 20 + "s";
        if (bankai && s == Spirit.HYORINMARU) {
            long wings = ZanpakutoData.getLong(w, "WingsEnd") - now;
            if (wings > 0) sub += "   Wings " + (wings / 20 + 1) + "s";
        }
        g.drawString(font, sub, tx, ly, 0xBBBBBB);
        ly += 11;
        if (release == ZanpakutoData.SEALED) {
            g.drawString(font, "[R] Release", tx, ly, 0xDDDDDD);
            return;
        }
        drawAbility(g, font, tx, ly, "[V] ", bankai ? s.bankaiAbility : s.shikaiAbility, ZanpakutoData.getAbilityCd(w) - now);
        ly += 11;
        drawAbility(g, font, tx, ly, "[Sneak+V] ", bankai ? s.bankaiAlt : s.shikaiAlt, ZanpakutoData.getAltCd(w) - now);
        ly += 11;
        if (meter) {
            int r = ZanpakutoData.getReiatsu(w);
            int bx = tx, bw = 100;
            g.fill(bx, ly + 1, bx + bw, ly + 7, 0xFF222222);
            g.fill(bx, ly + 1, bx + bw * r / 100, ly + 7, r >= 100 ? 0xFFC0102A : (bankai ? 0xFF555555 : 0xFF5AA9FF));
            String label = r >= 100 ? (bankai ? "MUGETSU" : "FULL") : r + "";
            g.drawString(font, label, bx + bw + 4, ly, r >= 100 ? 0xFF4455 : 0xBBBBBB);
        }
    }

    private static void drawAbility(GuiGraphics g, Font font, int x, int y, String key, String name, long cdTicks) {
        if (cdTicks > 0) {
            g.drawString(font, font.plainSubstrByWidth(key + name + "  " + (cdTicks / 20 + 1) + "s", 150), x, y, 0xFF6666);
        } else {
            g.drawString(font, font.plainSubstrByWidth(key + name, 150), x, y, 0x77FF77);
        }
    }
}
