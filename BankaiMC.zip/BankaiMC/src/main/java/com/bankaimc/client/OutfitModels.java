package com.bankaimc.client;

import com.bankaimc.BankaiMC;
import com.bankaimc.item.OutfitItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import org.jetbrains.annotations.NotNull;

import java.util.function.Supplier;

/** 3D models for the outfits that don't fit the normal armor shape (long haori, a hat with a brim). */
public final class OutfitModels {
    public static final ModelLayerLocation HAORI = new ModelLayerLocation(new ResourceLocation(BankaiMC.MODID, "haori"), "main");
    public static final ModelLayerLocation KENPACHI = new ModelLayerLocation(new ResourceLocation(BankaiMC.MODID, "kenpachi_haori"), "main");
    public static final ModelLayerLocation HAT = new ModelLayerLocation(new ResourceLocation(BankaiMC.MODID, "urahara_hat"), "main");

    private static HumanoidModel<LivingEntity> haori, kenpachi, hat;

    private OutfitModels() {}

    /** Replace a vanilla part with an empty one (same pivot), so nothing can ever be drawn from it. */
    private static void empty(PartDefinition root, String name, PartPose pose) {
        root.addOrReplaceChild(name, CubeListBuilder.create(), pose);
    }

    /** Haori: robe body + arms with wide sleeves, and a coat tail hanging to the knees. Texture 64x64. */
    public static LayerDefinition createHaori(boolean sleeves) {
        MeshDefinition mesh = HumanoidModel.createMesh(new CubeDeformation(0.0f), 0.0f);
        PartDefinition root = mesh.getRoot();
        CubeDeformation coat = new CubeDeformation(0.55f);
        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(16, 16).addBox(-4.0f, 0.0f, -2.0f, 8, 12, 4, coat), PartPose.ZERO);
        // the tail of the coat, hanging over the thighs
        body.addOrReplaceChild("tail",
                CubeListBuilder.create().texOffs(0, 32).addBox(-4.0f, 12.0f, -2.0f, 8, 7, 4, new CubeDeformation(0.75f)), PartPose.ZERO);
        empty(root, "head", PartPose.ZERO);
        empty(root, "hat", PartPose.ZERO);
        empty(root, "right_leg", PartPose.offset(-1.9f, 12.0f, 0.0f));
        empty(root, "left_leg", PartPose.offset(1.9f, 12.0f, 0.0f));
        if (!sleeves) {
            empty(root, "right_arm", PartPose.offset(-5.0f, 2.0f, 0.0f));
            empty(root, "left_arm", PartPose.offset(5.0f, 2.0f, 0.0f));
        } else {
            root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(40, 16)
                    .addBox(-3.0f, -2.0f, -2.0f, 4, 12, 4, new CubeDeformation(0.6f)), PartPose.offset(-5.0f, 2.0f, 0.0f));
            root.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(40, 16).mirror()
                    .addBox(-1.0f, -2.0f, -2.0f, 4, 12, 4, new CubeDeformation(0.6f)), PartPose.offset(5.0f, 2.0f, 0.0f));
        }
        return LayerDefinition.create(mesh, 64, 64);
    }

    /**
     * Bucket hat: a crown sitting low on the head and a wide brim. Texture 64x64.
     * All UVs live in the BOTTOM half of the texture (y >= 32). The top half is left fully transparent on purpose:
     * some mods also draw a helmet's texture onto the vanilla head shape (which reads the top half), and with
     * nothing there that extra copy is invisible instead of smearing green over your face.
     */
    public static LayerDefinition createHat() {
        MeshDefinition mesh = HumanoidModel.createMesh(new CubeDeformation(0.0f), 0.0f);
        PartDefinition root = mesh.getRoot();
        PartDefinition head = root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 32).addBox(-4.5f, -9.5f, -4.5f, 9, 5, 9, new CubeDeformation(0.05f)), PartPose.ZERO);
        head.addOrReplaceChild("brim",
                CubeListBuilder.create().texOffs(0, 46).addBox(-7.0f, -5.0f, -7.0f, 14, 1, 14), PartPose.ZERO);
        // everything except the hat itself is emptied, so no stray pixels can come from the skin-overlay
        // or body parts even if another mod turns them back on
        empty(root, "hat", PartPose.ZERO);
        empty(root, "body", PartPose.ZERO);
        empty(root, "right_arm", PartPose.offset(-5.0f, 2.0f, 0.0f));
        empty(root, "left_arm", PartPose.offset(5.0f, 2.0f, 0.0f));
        empty(root, "right_leg", PartPose.offset(-1.9f, 12.0f, 0.0f));
        empty(root, "left_leg", PartPose.offset(1.9f, 12.0f, 0.0f));
        return LayerDefinition.create(mesh, 64, 64);
    }

    private static HumanoidModel<LivingEntity> bake(ModelLayerLocation loc) {
        ModelPart part = Minecraft.getInstance().getEntityModels().bakeLayer(loc);
        return new HumanoidModel<>(part);
    }

    private static HumanoidModel<LivingEntity> model(OutfitItem.Style style) {
        return switch (style) {
            case HAORI -> haori != null ? haori : (haori = bake(HAORI));
            case KENPACHI_HAORI -> kenpachi != null ? kenpachi : (kenpachi = bake(KENPACHI));
            default -> hat != null ? hat : (hat = bake(HAT));
        };
    }

    /** Forget baked models when resources reload. */
    public static void clearCache() {
        haori = null;
        kenpachi = null;
        hat = null;
    }

    private static boolean warned = false;

    public static IClientItemExtensions extensions(Supplier<OutfitItem.Style> styleGetter) {
        return new IClientItemExtensions() {
            @Override
            @SuppressWarnings({"unchecked", "rawtypes"})
            public @NotNull HumanoidModel<?> getHumanoidArmorModel(LivingEntity entity, ItemStack stack, EquipmentSlot slot, HumanoidModel<?> original) {
                OutfitItem.Style style = styleGetter.get();
                if (style == null || style == OutfitItem.Style.LAYERED) return original; // robes/hakama/sandals: normal armor
                try {
                    HumanoidModel<LivingEntity> m = model(style);
                    ((HumanoidModel) original).copyPropertiesTo(m);   // copy the pose (walking, sneaking, swinging)
                    m.setAllVisible(false);
                    switch (style) {
                        case HAT -> m.head.visible = true;
                        case HAORI -> {
                            m.body.visible = true;
                            m.rightArm.visible = true;
                            m.leftArm.visible = true;
                        }
                        case KENPACHI_HAORI -> m.body.visible = true;   // sleeveless
                        default -> {}
                    }
                    return m;
                } catch (Exception e) {
                    // never crash the game over a cosmetic model: fall back to the plain armor shape
                    if (!warned) {
                        warned = true;
                        BankaiMC.LOGGER.error("BankaiMC: outfit model failed, using plain armor shape instead", e);
                    }
                    return original;
                }
            }
        };
    }
}
