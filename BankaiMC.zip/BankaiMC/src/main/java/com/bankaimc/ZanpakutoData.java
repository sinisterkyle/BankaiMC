package com.bankaimc;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraftforge.registries.ForgeRegistries;

/** All progression lives in the weapon's own NBT, so every blade has its own spirit and kill count. */
public final class ZanpakutoData {
    public static final String ROOT = "BankaiMC";
    public static final int SEALED = 0, SHIKAI = 1, BANKAI = 2;

    private static final String KILLS = "Kills", UNLOCKED = "Unlocked", SPIRIT = "Spirit", RELEASE = "Release",
            RELEASE_END = "ReleaseEnd", ABILITY_CD = "AbilityCd", BANKAI_CD = "BankaiCd",
            ALT_CD = "AltCd", REIATSU = "Reiatsu";

    private ZanpakutoData() {}

    public static boolean isEligible(ItemStack stack) {
        if (stack.isEmpty()) return false;
        if (stack.is(BankaiMC.ZANPAKUTO_TAG)) return true;
        Item item = stack.getItem();
        if (Config.ALL_SWORDS.get() && item instanceof SwordItem) return true;
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(item);
        if (key == null) return false;
        if (Config.EXTRA_WEAPONS.get().contains(key.toString())) return true;
        if (Config.COMPAT_MODS.get().contains(key.getNamespace())
                && stack.getAttributeModifiers(EquipmentSlot.MAINHAND).containsKey(Attributes.ATTACK_DAMAGE)) {
            return true;
        }
        String path = key.getPath();
        for (String kw : Config.NAME_KEYWORDS.get()) {
            if (!kw.isEmpty() && path.contains(kw)) return true;
        }
        return false;
    }

    private static CompoundTag write(ItemStack s) { return s.getOrCreateTagElement(ROOT); }

    private static CompoundTag read(ItemStack s) {
        CompoundTag t = s.getTagElement(ROOT);
        return t == null ? new CompoundTag() : t;
    }

    public static boolean hasData(ItemStack s) { return s.getTagElement(ROOT) != null; }

    public static int getKills(ItemStack s) { return read(s).getInt(KILLS); }
    public static void setKills(ItemStack s, int v) { write(s).putInt(KILLS, Math.max(0, v)); }
    public static int addKill(ItemStack s) { int k = getKills(s) + 1; setKills(s, k); return k; }

    public static int getUnlocked(ItemStack s) { return read(s).getInt(UNLOCKED); }
    public static void setUnlocked(ItemStack s, int v) { write(s).putInt(UNLOCKED, v); }

    public static Spirit getSpirit(ItemStack s) {
        CompoundTag t = read(s);
        return t.contains(SPIRIT) ? Spirit.byId(t.getString(SPIRIT)) : null;
    }
    public static void setSpirit(ItemStack s, Spirit spirit) { write(s).putString(SPIRIT, spirit.id); }

    public static int getRelease(ItemStack s) { return read(s).getInt(RELEASE); }
    public static void setRelease(ItemStack s, int v) { write(s).putInt(RELEASE, v); }

    public static long getReleaseEnd(ItemStack s) { return read(s).getLong(RELEASE_END); }
    public static void setReleaseEnd(ItemStack s, long v) { write(s).putLong(RELEASE_END, v); }

    public static long getAbilityCd(ItemStack s) { return read(s).getLong(ABILITY_CD); }
    public static void setAbilityCd(ItemStack s, long v) { write(s).putLong(ABILITY_CD, v); }

    public static long getBankaiCd(ItemStack s) { return read(s).getLong(BANKAI_CD); }
    public static void setBankaiCd(ItemStack s, long v) { write(s).putLong(BANKAI_CD, v); }

    public static long getAltCd(ItemStack s) { return read(s).getLong(ALT_CD); }
    public static void setAltCd(ItemStack s, long v) { write(s).putLong(ALT_CD, v); }

    /** Zangetsu's reiatsu meter, 0-100. */
    public static int getReiatsu(ItemStack s) { return read(s).getInt(REIATSU); }
    public static void setReiatsu(ItemStack s, int v) { write(s).putInt(REIATSU, Math.max(0, Math.min(100, v))); }

    /** Generic per-weapon numbers/flags used by individual spirits (e.g. wing timer, stitch used). */
    public static long getLong(ItemStack s, String key) { return read(s).getLong(key); }
    public static void setLong(ItemStack s, String key, long v) { write(s).putLong(key, v); }
    public static boolean getFlag(ItemStack s, String key) { return read(s).getBoolean(key); }
    public static void setFlag(ItemStack s, String key, boolean v) { write(s).putBoolean(key, v); }

    public static void reset(ItemStack s) { s.removeTagKey(ROOT); }
}
