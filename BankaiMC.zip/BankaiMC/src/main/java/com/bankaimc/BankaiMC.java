package com.bankaimc;

import com.bankaimc.network.Network;
import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(BankaiMC.MODID)
public class BankaiMC {
    public static final String MODID = "bankaimc";
    public static final Logger LOGGER = LogUtils.getLogger();

    /** Add any item to data/bankaimc/tags/items/zanpakuto.json (or via a datapack) to make it eligible. */
    public static final TagKey<Item> ZANPAKUTO_TAG = ItemTags.create(new ResourceLocation(MODID, "zanpakuto"));

    public BankaiMC() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(this::commonSetup);
        ModParticles.PARTICLES.register(modBus);
        com.bankaimc.entity.ModEntities.ENTITIES.register(modBus);
        com.bankaimc.item.ModBlades.init();
        com.bankaimc.item.ModItems.ITEMS.register(modBus);
        com.bankaimc.item.ModItems.TABS.register(modBus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC, "bankaimc-common.toml");
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(Network::register);
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MODID, path);
    }
}
