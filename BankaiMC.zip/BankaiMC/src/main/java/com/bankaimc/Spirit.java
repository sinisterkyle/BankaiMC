package com.bankaimc;

import net.minecraft.resources.ResourceLocation;
import org.joml.Vector3f;

/** Every zanpakuto spirit a blade can awaken into. Each has its own Shikai and Bankai. */
public enum Spirit {
    ZANGETSU("zangetsu", "Zangetsu", "Tensa Zangetsu", 0x5AA9FF, 0xC0102A,
            "Cut them down, Zangetsu!", "Bankai! Tensa Zangetsu!",
            "Getsuga Tensho", "Black Getsuga Tensho", "Full-Power Getsuga", "Shunpo"),
    HYORINMARU("hyorinmaru", "Hyorinmaru", "Daiguren Hyorinmaru", 0x8FE3FF, 0xBFF4FF,
            "Reign over the frozen heavens, Hyorinmaru!", "Bankai! Daiguren Hyorinmaru!",
            "Ice Dragon", "Hyoten Hyakkaso", "Ryusenka", "Sennen Hyoro"),
    SENBONZAKURA("senbonzakura", "Senbonzakura", "Senbonzakura Kageyoshi", 0xFF8FBF, 0xFF4F9A,
            "Scatter, Senbonzakura.", "Bankai. Senbonzakura Kageyoshi.",
            "Petal Arrow", "Kageyoshi", "Petal Shield", "Senkei / Gokei"),
    KYOKA_SUIGETSU("kyoka_suigetsu", "Kyoka Suigetsu", "Kyoka Suigetsu: Complete Hypnosis", 0xB57BFF, 0x7A2BFF,
            "Shatter, Kyoka Suigetsu.", "Bankai. Kyoka Suigetsu... Complete Hypnosis.",
            "Mirror Flower", "Complete Hypnosis", "Kurohitsugi", "Shatter"),
    KATEN_KYOKOTSU("katen_kyokotsu", "Katen Kyokotsu", "Katen Kyokotsu: Karamatsu Shinju", 0xE7A3FF, 0x3B2A4A,
            "Let the flowers play, Katen Kyokotsu.", "Bankai. Katen Kyokotsu: Karamatsu Shinju.",
            "Takaoni", "The Four Acts", "Kageoni", "Bushogoma"),
    RYUJIN_JAKKA("ryujin_jakka", "Ryujin Jakka", "Zanka no Tachi", 0xFF7A1A, 0xFFD24A,
            "Reduce all creation to ash, Ryujin Jakka!", "Bankai. Zanka no Tachi.",
            "Ennetsu Jigoku", "East: Kyokujitsujin", "Jokaku Enjo", "West: Zanjitsu Gokui"),
    MINAZUKI("minazuki", "Minazuki", "Minazuki: Blood Blade", 0x7FD9C4, 0x8A0F1E,
            "Minazuki.", "Bankai. Minazuki.",
            "Manta's Embrace", "Blood Tide", "Swallow", "Hemorrhage"),
    BENIHIME("benihime", "Benihime", "Kannonbiraki Benihime Aratame", 0xE0204A, 0xFF3B6B,
            "Awaken, Benihime.", "Bankai. Kannonbiraki Benihime Aratame.",
            "Cry, Benihime", "Restructure", "Blood Mist Shield", "Self-Stitch"),
    ZABIMARU("zabimaru", "Zabimaru", "Hihio Zabimaru", 0xD9473B, 0xF2E6C8,
            "Howl, Zabimaru!", "Bankai! Hihio Zabimaru!",
            "Whip Blade", "Hikotsu Taiho", "Higa Zekko", "Serpent Coil"),
    SHINSO("shinso", "Shinso", "Kamishini no Yari", 0xD8DCE6, 0x9B7BFF,
            "Shoot to kill, Shinso.", "Bankai. Kamishini no Yari.",
            "Shoot to Kill", "Kamishini no Yari", "Butou Renjin", "Korose");

    public final String id;
    public final String shikaiName;
    public final String bankaiName;
    public final int shikaiColor;
    public final int bankaiColor;
    public final String shikaiCall;
    public final String bankaiCall;
    public final String shikaiAbility;
    public final String bankaiAbility;
    public final String shikaiAlt;
    public final String bankaiAlt;
    public final ResourceLocation icon;

    Spirit(String id, String shikaiName, String bankaiName, int shikaiColor, int bankaiColor,
           String shikaiCall, String bankaiCall, String shikaiAbility, String bankaiAbility,
           String shikaiAlt, String bankaiAlt) {
        this.id = id;
        this.shikaiName = shikaiName;
        this.bankaiName = bankaiName;
        this.shikaiColor = shikaiColor;
        this.bankaiColor = bankaiColor;
        this.shikaiCall = shikaiCall;
        this.bankaiCall = bankaiCall;
        this.shikaiAbility = shikaiAbility;
        this.bankaiAbility = bankaiAbility;
        this.shikaiAlt = shikaiAlt;
        this.bankaiAlt = bankaiAlt;
        this.icon = BankaiMC.id("textures/gui/spirit/" + id + ".png");
    }

    public static Spirit byId(String id) {
        for (Spirit s : values()) if (s.id.equals(id)) return s;
        return null;
    }

    public static Vector3f rgb(int color) {
        return new Vector3f(((color >> 16) & 0xFF) / 255f, ((color >> 8) & 0xFF) / 255f, (color & 0xFF) / 255f);
    }
}
