package com.bankaimc.network;

import com.bankaimc.BankaiMC;
import com.bankaimc.Progression;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public final class Network {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            BankaiMC.id("main"), () -> VERSION, VERSION::equals, VERSION::equals);

    private Network() {}

    public static void register() {
        CHANNEL.messageBuilder(KeyPacket.class, 0, NetworkDirection.PLAY_TO_SERVER)
                .encoder(KeyPacket::encode)
                .decoder(KeyPacket::decode)
                .consumerMainThread(KeyPacket::handle)
                .add();
    }

    /** Sent when the player presses a BankaiMC key. action 0 = release, 1 = ability. */
    public record KeyPacket(int action) {
        public static final int RELEASE = 0, ABILITY = 1;

        public void encode(FriendlyByteBuf buf) { buf.writeByte(action); }

        public static KeyPacket decode(FriendlyByteBuf buf) { return new KeyPacket(buf.readByte()); }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ServerPlayer p = ctx.get().getSender();
            if (p == null || p.isSpectator()) return;
            if (action == RELEASE) Progression.toggleRelease(p);
            else if (action == ABILITY) Progression.useAbility(p);
        }
    }
}
