package com.bankaimc;

import com.bankaimc.ability.Fx;
import com.bankaimc.ability.Kits;
import com.bankaimc.item.OutfitBonuses;
import com.bankaimc.ability.SpiritKit;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/** Awakening (kills -> Shikai -> Bankai) and releasing/sealing. */
public final class Progression {
    private Progression() {}

    private static final String TEST_MODE = "bankaimc_test_mode";

    /** Test mode (/bankai testmode): no cooldowns, Bankai never times out and needs no rest. */
    public static boolean isTestMode(ServerPlayer p) {
        return persisted(p).getBoolean(TEST_MODE);
    }

    public static void setTestMode(ServerPlayer p, boolean on) {
        CompoundTag data = persisted(p);
        data.putBoolean(TEST_MODE, on);
        p.getPersistentData().put(Player.PERSISTED_NBT_TAG, data);
    }

    /** Forge copies this sub-tag across death/respawn. */
    private static CompoundTag persisted(ServerPlayer p) {
        return p.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
    }

    public static void onKill(ServerPlayer p, ItemStack weapon) {
        int kills = ZanpakutoData.addKill(weapon);
        int unlocked = ZanpakutoData.getUnlocked(weapon);
        double roll = p.getRandom().nextDouble();

        if (unlocked == ZanpakutoData.SEALED && kills >= Config.SHIKAI_MIN_KILLS.get()
                && (kills >= Config.SHIKAI_GUARANTEED_KILLS.get() || roll < Config.SHIKAI_CHANCE.get())) {
            Spirit s = Spirit.values()[p.getRandom().nextInt(Spirit.values().length)];
            awakenShikai(p, weapon, s);
        } else if (unlocked == ZanpakutoData.SHIKAI && kills >= Config.BANKAI_MIN_KILLS.get()
                && (kills >= Config.BANKAI_GUARANTEED_KILLS.get() || roll < Config.BANKAI_CHANCE.get())) {
            awakenBankai(p, weapon);
        } else if (unlocked == ZanpakutoData.SEALED && kills == Config.SHIKAI_MIN_KILLS.get()) {
            p.displayClientMessage(Component.literal("...your blade is whispering. Keep fighting.")
                    .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), true);
        }
    }

    public static void awakenShikai(ServerPlayer p, ItemStack weapon, Spirit s) {
        ZanpakutoData.setSpirit(weapon, s);
        ZanpakutoData.setUnlocked(weapon, Math.max(ZanpakutoData.SHIKAI, ZanpakutoData.getUnlocked(weapon)));
        title(p, Component.literal(s.shikaiName).withStyle(st -> st.withColor(s.shikaiColor).withBold(true)),
                Component.literal("Your zanpakuto has told you its name").withStyle(ChatFormatting.GRAY));
        p.sendSystemMessage(Component.literal("Shikai unlocked! [R] release, [V] " + s.shikaiAbility + ", [Sneak+V] " + s.shikaiAlt + ".")
                .withStyle(st -> st.withColor(s.shikaiColor)));
        strike(p);
        announce(p, Component.literal(p.getGameProfile().getName() + "'s blade has awakened: ")
                .withStyle(ChatFormatting.GRAY)
                .append(Component.literal(s.shikaiName).withStyle(st -> st.withColor(s.shikaiColor).withBold(true))));
    }

    public static void awakenBankai(ServerPlayer p, ItemStack weapon) {
        Spirit s = ZanpakutoData.getSpirit(weapon);
        if (s == null) return;
        ZanpakutoData.setUnlocked(weapon, ZanpakutoData.BANKAI);
        title(p, Component.literal("BANKAI").withStyle(st -> st.withColor(s.bankaiColor).withBold(true)),
                Component.literal(s.bankaiName).withStyle(st -> st.withColor(s.shikaiColor)));
        p.sendSystemMessage(Component.literal("Bankai achieved! While in Shikai, press [R] again to release "
                + s.bankaiName + ". [V] " + s.bankaiAbility + ", [Sneak+V] " + s.bankaiAlt + ".").withStyle(st -> st.withColor(s.bankaiColor)));
        strike(p);
        strike(p);
        announce(p, Component.literal(p.getGameProfile().getName() + " has achieved Bankai: ")
                .withStyle(ChatFormatting.GOLD)
                .append(Component.literal(s.bankaiName).withStyle(st -> st.withColor(s.bankaiColor).withBold(true))));
    }

    /** R key. Sealed -> Shikai -> Bankai (if unlocked & rested) -> Sealed. Sneak + R always seals. */
    public static void toggleRelease(ServerPlayer p) {
        ItemStack w = p.getMainHandItem();
        if (!ZanpakutoData.isEligible(w)) {
            bar(p, "Hold a sword or katana to call its spirit.", ChatFormatting.GRAY);
            return;
        }
        Spirit s = ZanpakutoData.getSpirit(w);
        if (s == null) {
            bar(p, "Your blade is silent... (" + ZanpakutoData.getKills(w) + " kills)", ChatFormatting.DARK_GRAY);
            return;
        }
        long now = p.level().getGameTime();
        int release = ZanpakutoData.getRelease(w);

        if (p.isShiftKeyDown() && release != ZanpakutoData.SEALED) {
            seal(p, w, s);
            return;
        }
        switch (release) {
            case ZanpakutoData.SEALED -> {
                ZanpakutoData.setRelease(w, ZanpakutoData.SHIKAI);
                Kits.get(s).onRelease(p, w, false);
                p.displayClientMessage(Component.literal(s.shikaiCall).withStyle(st -> st.withColor(s.shikaiColor).withBold(true)), true);
                Fx.shikaiRelease(p, s);
            }
            case ZanpakutoData.SHIKAI -> {
                if (ZanpakutoData.getUnlocked(w) < ZanpakutoData.BANKAI) {
                    seal(p, w, s);
                } else if (now < ZanpakutoData.getBankaiCd(w) && !isTestMode(p)) {
                    long secs = (ZanpakutoData.getBankaiCd(w) - now) / 20 + 1;
                    bar(p, "Your Bankai is still recovering (" + secs + "s). Sneak + R to seal.", ChatFormatting.RED);
                } else {
                    ZanpakutoData.setRelease(w, ZanpakutoData.BANKAI);
                    long dur = Config.BANKAI_DURATION_SECONDS.get() * 20L;
                    if (OutfitBonuses.hasCaptainHaori(p)) dur = dur * 3 / 2;
                    ZanpakutoData.setReleaseEnd(w, now + dur);
                    Kits.get(s).onRelease(p, w, true);
                    p.displayClientMessage(Component.literal(s.bankaiCall).withStyle(st -> st.withColor(s.bankaiColor).withBold(true)), true);
                    Fx.bankaiRelease(p, s);
                }
            }
            default -> seal(p, w, s);
        }
    }

    public static void seal(ServerPlayer p, ItemStack w, Spirit s) {
        if (ZanpakutoData.getRelease(w) == ZanpakutoData.BANKAI && !isTestMode(p)) {
            ZanpakutoData.setBankaiCd(w, p.level().getGameTime() + Config.BANKAI_COOLDOWN_SECONDS.get() * 20L);
        }
        ZanpakutoData.setRelease(w, ZanpakutoData.SEALED);
        Kits.get(s).onSeal(p, w);
        bar(p, s.shikaiName + " returns to its sealed form.", ChatFormatting.GRAY);
        p.level().playSound(null, p.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON, SoundSource.PLAYERS, 1f, 0.8f);
    }

    /** V key (Sneak + V = alt ability). Main and alt abilities have separate cooldowns. */
    public static void useAbility(ServerPlayer p) {
        ItemStack w = p.getMainHandItem();
        if (!ZanpakutoData.isEligible(w)) return;
        Spirit s = ZanpakutoData.getSpirit(w);
        int release = ZanpakutoData.getRelease(w);
        if (s == null || release == ZanpakutoData.SEALED) {
            bar(p, "Release your zanpakuto first [R].", ChatFormatting.GRAY);
            return;
        }
        boolean alt = p.isShiftKeyDown();
        boolean bankai = release == ZanpakutoData.BANKAI;
        long now = p.level().getGameTime();
        long cdEnd = alt ? ZanpakutoData.getAltCd(w) : ZanpakutoData.getAbilityCd(w);
        if (now < cdEnd && !isTestMode(p)) {
            String name = alt ? (bankai ? s.bankaiAlt : s.shikaiAlt) : (bankai ? s.bankaiAbility : s.shikaiAbility);
            bar(p, name + " recharging... " + ((cdEnd - now) / 20 + 1) + "s", ChatFormatting.RED);
            return;
        }
        SpiritKit kit = Kits.get(s);
        int cd = alt ? (bankai ? kit.bankaiAlt(p, w) : kit.shikaiAlt(p, w))
                     : (bankai ? kit.bankai(p, w) : kit.shikai(p, w));
        if (cd > 0 && !isTestMode(p)) {
            double mult = Config.COOLDOWN_MULTIPLIER.get() * (OutfitBonuses.hasHat(p) ? 0.8 : 1.0);
            long end = now + (long) (cd * mult);
            if (alt) ZanpakutoData.setAltCd(w, end);
            else ZanpakutoData.setAbilityCd(w, end);
        }
    }

    /** Every 10 ticks: passives, aura, Bankai timeout, and cleaning up Hyorinmaru's wings. */
    public static void tickHeld(ServerPlayer p) {
        ItemStack w = p.getMainHandItem();
        Spirit s = ZanpakutoData.hasData(w) ? ZanpakutoData.getSpirit(w) : null;
        int release = s == null ? ZanpakutoData.SEALED : ZanpakutoData.getRelease(w);

        if (release == ZanpakutoData.BANKAI && !isTestMode(p) && p.level().getGameTime() >= ZanpakutoData.getReleaseEnd(w)) {
            seal(p, w, s);
            bar(p, "Your Bankai fades. It must rest.", ChatFormatting.GRAY);
            release = ZanpakutoData.SEALED;
        }
        if (s == null || release == ZanpakutoData.SEALED) return;

        SpiritKit kit = Kits.get(s);
        boolean bankai = release == ZanpakutoData.BANKAI;
        if (bankai) kit.aura(p, w);
        kit.passives(p, w, bankai);
    }

    /** Every 2 ticks: the travelling release aura (same for every spirit, in its own particles). */
    public static void auraTick(ServerPlayer p) {
        ItemStack w = p.getMainHandItem();
        if (!ZanpakutoData.hasData(w)) return;
        Spirit s = ZanpakutoData.getSpirit(w);
        int release = ZanpakutoData.getRelease(w);
        if (s == null || release == ZanpakutoData.SEALED) return;
        Fx.releaseAura(p, s, release == ZanpakutoData.BANKAI);
    }

    /** The held, released weapon's kit, or null. Used by the trait events. */
    public static SpiritKit releasedKit(ServerPlayer p) {
        ItemStack w = p.getMainHandItem();
        if (!ZanpakutoData.hasData(w) || ZanpakutoData.getRelease(w) == ZanpakutoData.SEALED) return null;
        Spirit s = ZanpakutoData.getSpirit(w);
        return s == null ? null : Kits.get(s);
    }

    // ---------------------------------------------------------------- utils

    private static void bar(ServerPlayer p, String msg, ChatFormatting color) {
        p.displayClientMessage(Component.literal(msg).withStyle(color), true);
    }

    private static void title(ServerPlayer p, Component title, Component sub) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(5, 50, 15));
        p.connection.send(new ClientboundSetSubtitleTextPacket(sub));
        p.connection.send(new ClientboundSetTitleTextPacket(title));
    }

    private static void strike(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(Vec3.atBottomCenterOf(p.blockPosition()));
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }
    }

    private static void announce(ServerPlayer p, Component msg) {
        if (Config.ANNOUNCE_AWAKENING.get()) p.server.getPlayerList().broadcastSystemMessage(msg, false);
    }
}
