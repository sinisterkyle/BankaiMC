package com.bankaimc;

import com.bankaimc.ability.Bleed;
import com.bankaimc.ability.Fragment;
import com.bankaimc.ability.Fx;
import com.bankaimc.ability.kit.HyorinmaruKit;
import com.bankaimc.item.OutfitBonuses;
import com.bankaimc.ability.Hypnosis;
import com.bankaimc.ability.SpiritKit;
import com.bankaimc.task.TaskManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;


@Mod.EventBusSubscriber(modid = BankaiMC.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CommonEvents {
    private CommonEvents() {}

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer victim) {
            SpiritKit kit = Progression.releasedKit(victim);
            ItemStack held = victim.getMainHandItem();
            if (kit != null && kit.onLethal(victim, held, ZanpakutoData.getRelease(held) == ZanpakutoData.BANKAI)) {
                event.setCanceled(true);
                return;
            }
            HyorinmaruKit.revokeFlight(victim);
        }
        if (!(event.getSource().getEntity() instanceof ServerPlayer p)) return;
        LivingEntity dead = event.getEntity();
        if (dead == p) return;
        if (dead instanceof Player) {
            if (!Config.PLAYER_KILLS_COUNT.get()) return;
        } else if (Config.HOSTILE_KILLS_ONLY.get() && !(dead instanceof Enemy)) {
            return;
        }
        ItemStack weapon = p.getMainHandItem();
        if (ZanpakutoData.isEligible(weapon)) Progression.onKill(p, weapon);
    }

    // ---------------------------------------------------------------- spirit traits

    /** Sword hits (not ability damage) trigger the attacker's spirit trait. */
    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide) return;

        // Kenpachi's haori: sword hits deal +20%
        if (!Fx.isAbilityDamage() && event.getSource().getDirectEntity() instanceof ServerPlayer kp && kp != victim
                && OutfitBonuses.hasKenpachiHaori(kp)) {
            event.setAmount(event.getAmount() * 1.2f);
        }
        // Waraji sandals: no fall damage from short drops
        if (victim instanceof ServerPlayer sp && OutfitBonuses.hasSandals(sp)
                && event.getSource().is(net.minecraft.tags.DamageTypeTags.IS_FALL) && sp.fallDistance < 6.0f) {
            event.setCanceled(true);
            return;
        }
        if (!Fx.isAbilityDamage() && event.getSource().getDirectEntity() instanceof ServerPlayer p && p != victim) {
            SpiritKit kit = Progression.releasedKit(p);
            if (kit != null) {
                ItemStack w = p.getMainHandItem();
                kit.onMeleeHit(p, w, ZanpakutoData.getRelease(w) == ZanpakutoData.BANKAI, victim, event);
            }
        }
        if (victim instanceof ServerPlayer p) {
            SpiritKit kit = Progression.releasedKit(p);
            if (kit != null) {
                ItemStack w = p.getMainHandItem();
                kit.onHurt(p, w, ZanpakutoData.getRelease(w) == ZanpakutoData.BANKAI, event);
            }
        }
    }

    /** Defensive traits (dodges, deflections, flame armor). */
    @SubscribeEvent
    public static void onLivingAttack(LivingAttackEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            SpiritKit kit = Progression.releasedKit(p);
            if (kit != null) {
                ItemStack w = p.getMainHandItem();
                kit.onAttacked(p, w, ZanpakutoData.getRelease(w) == ZanpakutoData.BANKAI, event);
            }
        }
    }

    /** Mobs charmed by Kyoka Suigetsu can't go back to targeting the caster. */
    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent event) {
        LivingEntity newTarget = event.getNewTarget();
        if (newTarget instanceof ServerPlayer p && Hypnosis.isCharmedBy(event.getEntity(), p.getUUID())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        LivingEntity e = event.getEntity();
        if (!e.level().isClientSide) {
            Hypnosis.tick(e);
            Bleed.tick(e);
            Fragment.tick(e);
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.player instanceof ServerPlayer p) {
            if (p.tickCount % 10 == 0) Progression.tickHeld(p);
            if (p.tickCount % 2 == 0) Progression.auraTick(p);
            if (p.tickCount % 20 == 0) OutfitBonuses.tick(p);
            HyorinmaruKit.enforceFlight(p); // every tick, so flight can't outlive the wings
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) HyorinmaruKit.revokeFlight(p);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) HyorinmaruKit.enforceFlight(p);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) TaskManager.tick();
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        BankaiCommands.register(event.getDispatcher(), event.getBuildContext());
    }

    /** Re-send the command list when gamemode changes so creative players see /bankai autocomplete. */
    @SubscribeEvent
    public static void onGameModeChange(PlayerEvent.PlayerChangeGameModeEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            p.server.execute(() -> p.server.getCommands().sendCommands(p));
        }
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        TaskManager.clear();
    }
}
