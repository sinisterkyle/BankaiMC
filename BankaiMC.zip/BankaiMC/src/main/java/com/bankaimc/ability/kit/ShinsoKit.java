package com.bankaimc.ability.kit;

import com.bankaimc.ModParticles;
import com.bankaimc.Progression;
import com.bankaimc.ZanpakutoData;
import com.bankaimc.Targeting;
import com.bankaimc.ability.Fragment;
import com.bankaimc.ability.SpiritKit;
import com.bankaimc.task.TaskManager;
import com.bankaimc.task.TimedTask;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

import static com.bankaimc.ability.Fx.*;

/**
 * Shinso / Kamishini no Yari - a blade that extends further and faster than the eye can follow.
 * Release: drawing the blade whips it out in a sweeping arc that cuts and hurls back everything nearby
 *          (Shikai: 14-block half circle, 9s internal cooldown | Bankai: 30-block full circle + a fragment in everyone hit).
 * Shikai:  Trait: 35% of sword hits extend through the target and pierce the next enemy behind it.
 *          V = Shoot to Kill (24-block piercing thrust that hurls targets back) | Sneak+V = Butou Renjin (10 rapid stabs, the last one a heavy finisher)
 * Bankai:  Trait: every hit leaves a poison FRAGMENT inside the enemy (up to 3, lasts 30s).
 *          V = Kamishini no Yari (a 64-block lance, out and back almost instantly) | Sneak+V = Korose (every fragment dissolves its host from the inside)
 */
public class ShinsoKit implements SpiritKit {

    private static ParticleOptions steel() {
        return dust(0.86f, 0.88f, 0.93f, 0.7f);
    }

    private static ParticleOptions violet(float size) {
        return dust(0.6f, 0.4f, 1.0f, size);
    }

    /**
     * The blade extends along the aim (fixed at the moment you strike): out in 2 ticks, hits at full length,
     * then snaps back over 4 ticks. damage <= 0 = visual only (release animations).
     */
    private static void lance(ServerPlayer p, Vec3 dir, double length, float damage, double width, boolean bankai) {
        lance(p, dir, length, damage, width, bankai, 0);
    }

    private static void lance(ServerPlayer p, Vec3 dir, double length, float damage, double width, boolean bankai, double push) {
        ServerLevel l = p.serverLevel();
        Vec3 start = p.getEyePosition().subtract(0, 0.3, 0).add(dir.scale(0.8));
        Vec3 full = start;
        for (double d = 0.5; d <= length; d += 0.5) {
            Vec3 pt = start.add(dir.scale(d));
            if (solid(l, pt)) break;
            full = pt;
        }
        final Vec3 end = full;
        double len = start.distanceTo(end);
        TaskManager.add(new TimedTask(p, 7, t -> {
            double f = t == 0 ? 0.55 : t <= 2 ? 1.0 : 1.0 - (t - 2) / 4.0;
            Vec3 tip = start.add(dir.scale(len * f));
            line(l, steel(), start, tip, 0.35);
            dot(l, ModParticles.BLADE_GLINT.get(), tip);
            if (bankai && t <= 2) {
                for (double d = 2; d < len * f; d += 4) dot(l, violet(0.9f), start.add(dir.scale(d)).add(jit(l, 0.15)));
            }
            if (t == 1 && damage > 0) {
                soundAt(l, end, SoundEvents.TRIDENT_HIT, 1.0f, 1.6f);
                for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, new AABB(start, end).inflate(width + 1),
                        e -> Targeting.valid(p, e))) {
                    if (distToSegment(chest(e), start, end) < width + e.getBbWidth() * 0.5) {
                        damage(p, e, damage);
                        if (push > 0) e.knockback(push, -dir.x, -dir.z);
                        burst(l, bankai ? ModParticles.POISON_FRAGMENT.get() : ModParticles.BLADE_GLINT.get(), chest(e), 8, 0.2);
                        if (bankai) Fragment.apply(e, p, 1);
                    }
                }
                burst(l, ModParticles.BLADE_GLINT.get(), end, 10, 0.2);
            }
        }));
    }

    @Override
    public int shikai(ServerPlayer p, ItemStack w) {
        sound(p, SoundEvents.TRIDENT_THROW, 1.2f, 1.9f);
        sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 0.8f, 1.8f);
        lance(p, p.getLookAngle().normalize(), 24, 24, 1.1, false, 1.2);
        actionBar(p, "Shoot to kill, Shinso.", 0xD8DCE6);
        return 60;
    }

    /** Butou Renjin: ten rapid extending stabs at whatever you're aiming at, the last one a heavy finisher. */
    @Override
    public int shikaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        actionBar(p, "Butou Renjin", 0xD8DCE6);
        TaskManager.add(new TimedTask(p, 28, t -> {
            if (t % 3 != 0) return;
            Vec3 look = p.getLookAngle();
            if (t == 27) {
                lance(p, look.normalize(), 20, 20, 1.2, false, 1.8);
                sound(p, SoundEvents.TRIDENT_THROW, 1.2f, 1.2f);
                sound(p, SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.8f);
                return;
            }
            Vec3 dir = look.add((l.random.nextDouble() - 0.5) * 0.06, (l.random.nextDouble() - 0.5) * 0.06,
                    (l.random.nextDouble() - 0.5) * 0.06).normalize();
            lance(p, dir, 16, 9, 0.9, false);
            sound(p, SoundEvents.TRIDENT_THROW, 0.8f, 1.6f + l.random.nextFloat() * 0.4f);
        }));
        return 140;
    }

    /** Kamishini no Yari: the blade extends 64 blocks and back in an instant. */
    @Override
    public int bankai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 dir = p.getLookAngle().normalize();
        sound(p, SoundEvents.WARDEN_SONIC_BOOM, 1.0f, 2.0f);
        sound(p, SoundEvents.TRIDENT_THROW, 1.5f, 1.4f);
        lance(p, dir, 64, bk(20), 1.3, true, 1.4);
        // a ring of displaced air where the blade leaves
        Vec3 c = p.getEyePosition().add(dir.scale(1.2));
        Vec3 right = rightOf(dir);
        Vec3 up = right.cross(dir).normalize();
        for (int i = 0; i < 20; i++) {
            double a = i * Math.PI / 10;
            Vec3 out = right.scale(Math.cos(a)).add(up.scale(Math.sin(a)));
            fly(l, steel(), c.add(out.scale(0.4)), out.scale(0.3));
        }
        actionBar(p, "Kamishini no Yari", 0x9B7BFF);
        return 50;
    }

    /** Korose: every fragment you've left behind dissolves its host from the inside. */
    @Override
    public int bankaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        int n = 0;
        for (LivingEntity e : Targeting.around(p, p.position(), 40)) {
            int stacks = Fragment.stacks(e, p);
            if (stacks <= 0) continue;
            Fragment.clear(e);
            n++;
            Vec3 c = chest(e);
            implode(l, ModParticles.POISON_FRAGMENT.get(), c, 18, 1.4);
            burst(l, violet(1.6f), c, 20 + stacks * 10, 0.35);
            dot(l, ParticleTypes.FLASH, c);
            damage(p, e, bk(15) * stacks);
            e.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 1));
            soundAt(l, c, SoundEvents.WITHER_HURT, 0.8f, 1.6f);
        }
        if (n == 0) {
            actionBar(p, "No fragments left in anyone.", 0x888888);
            return 0;
        }
        sound(p, SoundEvents.GLASS_BREAK, 1.2f, 0.6f);
        actionBar(p, "Korose. (" + n + ")", 0x9B7BFF);
        return 240;
    }

    private static final String DRAW_CD = "ShinsoDrawCd";

    @Override
    public void onRelease(ServerPlayer p, ItemStack w, boolean bankai) {
        long now = p.level().getGameTime();
        if (!bankai) {
            // Shikai can be toggled freely, so its damaging draw has its own cooldown
            if (now < ZanpakutoData.getLong(w, DRAW_CD) && !Progression.isTestMode(p)) {
                lance(p, p.getLookAngle().normalize(), 10, 0, 0.5, false);
                sound(p, SoundEvents.TRIDENT_THROW, 1.0f, 1.8f);
                return;
            }
            ZanpakutoData.setLong(w, DRAW_CD, now + 300);
        }
        drawSweep(p, bankai);
    }

    /**
     * The draw: the blade shoots out to full length and whips around the wielder.
     * Shikai sweeps the front half circle, Bankai sweeps all the way around. Each enemy is hit once.
     */
    private static void drawSweep(ServerPlayer p, boolean bankai) {
        ServerLevel l = p.serverLevel();
        double length = bankai ? 30 : 14;
        double arc = bankai ? Math.PI * 2 : Math.PI;
        int ticks = bankai ? 8 : 5;
        float dmg = bankai ? bk(10) : 3;
        double push = bankai ? 2.6 : 1.9;
        Vec3 look = p.getLookAngle();
        double baseYaw = Math.atan2(look.z, look.x);
        double startYaw = bankai ? baseYaw : baseYaw - arc / 2;
        Vec3 origin = p.position().add(0, 1.1, 0);
        Set<Integer> hit = new HashSet<>();

        sound(p, SoundEvents.TRIDENT_THROW, 1.5f, bankai ? 1.0f : 1.5f);
        sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 1.4f, bankai ? 0.6f : 0.9f);
        if (bankai) sound(p, SoundEvents.WARDEN_SONIC_BOOM, 0.8f, 1.8f);

        TaskManager.add(new TimedTask(p, ticks + 3, t -> {
            if (t >= ticks) {
                // the blade snaps back
                double f = 1.0 - (t - ticks + 1) / 3.0;
                double yaw = startYaw + arc;
                Vec3 dir = new Vec3(Math.cos(yaw), 0, Math.sin(yaw));
                line(l, steel(), origin, origin.add(dir.scale(length * f)), 0.5);
                return;
            }
            double a0 = startYaw + arc * t / ticks;
            double a1 = startYaw + arc * (t + 1) / ticks;
            // draw the swept slice
            for (int k = 0; k <= 3; k++) {
                double yaw = a0 + (a1 - a0) * k / 3.0;
                Vec3 dir = new Vec3(Math.cos(yaw), 0, Math.sin(yaw));
                Vec3 tip = origin.add(dir.scale(length));
                line(l, steel(), origin, tip, k == 3 ? 0.35 : 0.9);
                dot(l, ModParticles.BLADE_GLINT.get(), tip);
                if (bankai) dot(l, violet(1.1f), origin.add(dir.scale(length * l.random.nextDouble())));
            }
            for (LivingEntity e : Targeting.around(p, origin, length + 1)) {
                if (hit.contains(e.getId())) continue;
                Vec3 c = chest(e);
                if (Math.abs(c.y - origin.y) > 3.0) continue;
                double dx = c.x - origin.x, dz = c.z - origin.z;
                double flat = Math.sqrt(dx * dx + dz * dz);
                if (flat > length + e.getBbWidth() * 0.5) continue;
                double rel = Math.atan2(dz, dx) - a0;
                while (rel < 0) rel += Math.PI * 2;
                while (rel >= Math.PI * 2) rel -= Math.PI * 2;
                // close enemies get a little angular slack so nothing slips through between ticks
                double slack = flat < 3 ? 0.4 : 0.12;
                if (rel > (a1 - a0) + slack && rel < Math.PI * 2 - slack) continue;
                hit.add(e.getId());
                damage(p, e, dmg);
                if (flat > 0.01) e.knockback(push, -dx / flat, -dz / flat);
                e.setDeltaMovement(e.getDeltaMovement().add(0, 0.35, 0));
                e.hurtMarked = true;
                burst(l, bankai ? ModParticles.POISON_FRAGMENT.get() : ModParticles.BLADE_GLINT.get(), c, 10, 0.25);
                if (bankai) Fragment.apply(e, p, 1);
                soundAt(l, c, SoundEvents.TRIDENT_HIT, 0.9f, 1.4f);
            }
        }));
    }

    @Override
    public void passives(ServerPlayer p, ItemStack w, boolean bankai) {
        buff(p, MobEffects.MOVEMENT_SPEED, bankai ? 1 : 0);
        if (bankai) buff(p, MobEffects.DAMAGE_BOOST, 0);
    }

    @Override
    public void aura(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        for (int i = 0; i < 3; i++) dot(l, ModParticles.POISON_FRAGMENT.get(), c.add(jit(l, 1.0)).add(0, 1.0, 0));
    }

    @Override
    public void onMeleeHit(ServerPlayer p, ItemStack w, boolean bankai, LivingEntity target, LivingHurtEvent event) {
        ServerLevel l = p.serverLevel();
        if (bankai) {
            Fragment.apply(target, p, 1);
            burst(l, ModParticles.POISON_FRAGMENT.get(), chest(target), 6, 0.15);
            return;
        }
        if (p.getRandom().nextFloat() >= 0.35f) return;
        // the blade extends through the target into the next enemy behind it
        Vec3 dir = chest(target).subtract(p.getEyePosition()).normalize();
        Vec3 from = chest(target);
        Vec3 to = from.add(dir.scale(6));
        LivingEntity next = l.getEntitiesOfClass(LivingEntity.class, new AABB(from, to).inflate(1.5),
                        e -> e != target && Targeting.valid(p, e) && distToSegment(chest(e), from, to) < 1.2)
                .stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(target))).orElse(null);
        if (next == null) return;
        line(l, steel(), from, chest(next), 0.3);
        dot(l, ModParticles.BLADE_GLINT.get(), chest(next));
        damage(p, next, event.getAmount() * 0.8f);
        soundAt(l, chest(next), SoundEvents.TRIDENT_HIT, 0.8f, 1.8f);
    }

}
