package com.bankaimc.ability;

import com.bankaimc.ModParticles;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

/** Minazuki's bleed: stacking damage over time, owned by the player who caused it. */
public final class Bleed {
    private static final String STACKS = "bankaimc_bleed_stacks";
    private static final String PER = "bankaimc_bleed_per";
    private static final String UNTIL = "bankaimc_bleed_until";
    private static final String BY = "bankaimc_bleed_by";
    public static final int MAX_STACKS = 10;

    private Bleed() {}

    public static void apply(LivingEntity e, ServerPlayer by, int stacks, float perStack, int ticks) {
        CompoundTag d = e.getPersistentData();
        long now = e.level().getGameTime();
        int cur = d.getLong(UNTIL) > now ? d.getInt(STACKS) : 0;
        d.putInt(STACKS, Math.min(MAX_STACKS, cur + stacks));
        d.putFloat(PER, Math.max(perStack, cur > 0 ? d.getFloat(PER) : 0));
        d.putLong(UNTIL, now + ticks);
        d.putUUID(BY, by.getUUID());
    }

    public static int stacks(LivingEntity e) {
        CompoundTag d = e.getPersistentData();
        return d.getLong(UNTIL) > e.level().getGameTime() ? d.getInt(STACKS) : 0;
    }

    /** Removes the bleed and returns stacks x damage-per-stack. */
    public static float consume(LivingEntity e) {
        int s = stacks(e);
        float total = s * e.getPersistentData().getFloat(PER);
        clear(e);
        return total;
    }

    private static void clear(LivingEntity e) {
        CompoundTag d = e.getPersistentData();
        d.remove(STACKS);
        d.remove(PER);
        d.remove(UNTIL);
        d.remove(BY);
    }

    /** Every tick for every living entity: one damage pulse per second. */
    public static void tick(LivingEntity e) {
        CompoundTag d = e.getPersistentData();
        if (!d.contains(UNTIL)) return;
        ServerLevel l = (ServerLevel) e.level();
        if (l.getGameTime() >= d.getLong(UNTIL)) {
            clear(e);
            return;
        }
        int s = d.getInt(STACKS);
        if (e.tickCount % 5 == 0) {
            l.sendParticles(ModParticles.BLOOD_DROP.get(), e.getX(), e.getY() + e.getBbHeight() * 0.6, e.getZ(),
                    1 + s / 3, e.getBbWidth() * 0.4, e.getBbHeight() * 0.3, e.getBbWidth() * 0.4, 0);
        }
        if (e.tickCount % 20 == 0) {
            float dmg = s * d.getFloat(PER);
            ServerPlayer by = d.hasUUID(BY) ? l.getServer().getPlayerList().getPlayer(d.getUUID(BY)) : null;
            if (by != null) {
                Fx.damage(by, e, dmg);
            } else {
                e.invulnerableTime = 0;
                e.hurt(l.damageSources().magic(), dmg);
            }
        }
    }
}
