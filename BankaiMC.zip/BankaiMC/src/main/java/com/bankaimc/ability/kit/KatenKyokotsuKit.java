package com.bankaimc.ability.kit;

import com.bankaimc.ModParticles;
import com.bankaimc.Targeting;
import com.bankaimc.ability.Hypnosis;
import com.bankaimc.ability.SpiritKit;
import com.bankaimc.task.TaskManager;
import com.bankaimc.task.TimedTask;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import java.util.Comparator;
import java.util.List;

import static com.bankaimc.ability.Fx.*;

/**
 * Katen Kyokotsu - it turns children's games into real rules everyone must obey.
 * Trait (Shikai): Takaoni rule - your sword hits deal +50% when you stand higher than your target.
 * Shikai:  V = Takaoni (the one higher up wins: AoE scaling with height) | Sneak+V = Kageoni (step on their shadow: teleport behind & strike)
 * Bankai:  Trait: Shared Wounds - 75% of the damage you take is dealt to every enemy within 10 blocks.
 *          V = Karamatsu Shinju, the Four Acts | Sneak+V = Bushogoma (a spinning-top whirlwind that drags enemies in)
 */
public class KatenKyokotsuKit implements SpiritKit {
    private static boolean sharing = false;

    @Override
    public int shikai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 1.5f, 1.2f);
        burst(l, ModParticles.KIMONO_FLOWER.get(), chest(p), 20, 0.25);
        int hits = 0;
        for (LivingEntity e : Targeting.around(p, p.position(), 10)) {
            double height = Math.max(0, p.getY() - e.getY());
            damage(p, e, (float) Math.min(40, 8 + height * 3));
            Vec3 ec = chest(e);
            stream(l, ModParticles.KIMONO_FLOWER.get(), ec.add(0, 3.5, 0), ec, 12, 0.5, 0.15);
            l.sendParticles(ParticleTypes.CRIT, ec.x, ec.y, ec.z, 12, 0.3, 0.4, 0.3, 0.2);
            hits++;
        }
        actionBar(p, "Takaoni - the one who stands higher wins. (" + hits + " hit)", 0xE7A3FF);
        return 120;
    }

    @Override
    public int shikaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        LivingEntity target = lookTarget(p, 16);
        if (target == null) {
            target = Targeting.around(p, p.position(), 16).stream()
                    .min(Comparator.comparingDouble(e -> e.distanceToSqr(p))).orElse(null);
        }
        if (target == null) {
            actionBar(p, "Kageoni - no shadow to step into.", 0x888888);
            return 0;
        }
        Vec3 back = Vec3.directionFromRotation(0, target.getYRot()).scale(-1.5);
        Vec3 dest = target.position().add(back.x, 0, back.z);
        if (solid(l, dest) || solid(l, dest.add(0, 1, 0))) dest = target.position();
        burst(l, ModParticles.SHADOW_WISP.get(), chest(p), 25, 0.2);
        line(l, ModParticles.SHADOW_WISP.get(), p.position().add(0, 0.1, 0), dest.add(0, 0.1, 0), 0.5);
        float yaw = (float) (Mth.atan2(target.getZ() - dest.z, target.getX() - dest.x) * (180F / Math.PI)) - 90F;
        p.teleportTo(l, dest.x, dest.y, dest.z, yaw, 10f);
        burst(l, ModParticles.SHADOW_WISP.get(), dest.add(0, 1, 0), 25, 0.2);
        damage(p, target, 18);
        effect(target, MobEffects.DARKNESS, 60, 0);
        sound(p, SoundEvents.ENDERMAN_TELEPORT, 1.0f, 0.5f);
        actionBar(p, "Kageoni - step on the shadow.", 0xE7A3FF);
        return 120;
    }

    @Override
    public int bankai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        double r = 14;
        sound(p, SoundEvents.AMBIENT_CAVE.value(), 2.0f, 0.5f);
        TaskManager.add(new TimedTask(p, 210, t -> {
            if (t % 5 == 0) ringOut(l, ModParticles.SHADOW_WISP.get(), c, r, 60, 0.2, 0.0);
            for (int i = 0; i < 3; i++) {
                double x = c.x + (l.random.nextDouble() * 2 - 1) * r * 0.8;
                double z = c.z + (l.random.nextDouble() * 2 - 1) * r * 0.8;
                fly(l, ModParticles.KIMONO_FLOWER.get(), new Vec3(x, c.y + 4, z), new Vec3(0, -0.05, 0));
            }
            List<LivingEntity> in = Targeting.around(p, c, r);
            if (t >= 120 && t < 200 && t % 4 == 0) {
                for (LivingEntity e : in) line(l, ModParticles.SHADOW_WISP.get(), chest(e).add(0, 5, 0), chest(e), 0.6);
            }
            switch (t) {
                case 0 -> {
                    actionBar(p, "Act One: Shared Wounds", 0xE7A3FF);
                    for (LivingEntity e : in) {
                        damage(p, e, bk(10));
                        effect(e, MobEffects.MOVEMENT_SLOWDOWN, 210, 1);
                        burst(l, dust(0.8f, 0.05f, 0.1f, 1.5f), chest(e), 15, 0.2);
                    }
                    sound(p, SoundEvents.PLAYER_ATTACK_STRONG, 1.5f, 0.6f);
                }
                case 60 -> {
                    actionBar(p, "Act Two: Shame", 0xE7A3FF);
                    for (LivingEntity e : in) {
                        effect(e, MobEffects.WEAKNESS, 150, 2);
                        effect(e, MobEffects.DARKNESS, 150, 0);
                        damage(p, e, bk(8));
                        burst(l, ModParticles.SHADOW_WISP.get(), chest(e), 20, 0.15);
                    }
                    sound(p, SoundEvents.WITHER_AMBIENT, 1.0f, 0.5f);
                }
                case 120 -> {
                    actionBar(p, "Act Three: Binding Threads", 0xE7A3FF);
                    for (LivingEntity e : in) {
                        effect(e, MobEffects.WITHER, 90, 1);
                        Hypnosis.apply(e, 90, false, null, 0);
                    }
                    sound(p, SoundEvents.SPIDER_AMBIENT, 1.5f, 0.4f);
                }
                case 200 -> {
                    actionBar(p, "Final Act: Itodome", 0xFF3355);
                    for (LivingEntity e : in) {
                        damage(p, e, bk(45));
                        burst(l, ModParticles.KIMONO_FLOWER.get(), chest(e), 25, 0.35);
                        burst(l, ModParticles.SHADOW_WISP.get(), chest(e), 15, 0.3);
                    }
                    ringOut(l, ModParticles.KIMONO_FLOWER.get(), c, 1, 80, 1.0, 0.8);
                    l.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y + 1, c.z, 1, 0, 0, 0, 0);
                    sound(p, SoundEvents.TRIDENT_THUNDER, 1.5f, 0.6f);
                }
                default -> {}
            }
        }));
        return 800;
    }

    /** Bushogoma: a whirlwind travels where you aim for 3s, dragging enemies into it. */
    @Override
    public int bankaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 dir = new Vec3(p.getLookAngle().x, 0, p.getLookAngle().z).normalize();
        Vec3 start = p.position().add(dir.scale(2));
        sound(p, SoundEvents.ELYTRA_FLYING, 1.5f, 1.5f);
        actionBar(p, "Bushogoma", 0xE7A3FF);
        TaskManager.add(new TimedTask(p, 60, t -> {
            Vec3 c = start.add(dir.scale(t * 0.35));
            // a funnel, narrow at the bottom, wide at the top
            for (int i = 0; i < 26; i++) {
                double y = l.random.nextDouble() * 5;
                double r = 0.4 + y * 0.45;
                double a = l.random.nextDouble() * Math.PI * 2;
                fly(l, i % 3 == 0 ? ModParticles.KIMONO_FLOWER.get() : ModParticles.SHADOW_WISP.get(),
                        c.add(Math.cos(a) * r, y, Math.sin(a) * r), new Vec3(-Math.sin(a) * 0.5, 0.08, Math.cos(a) * 0.5));
            }
            for (LivingEntity e : Targeting.around(p, c.add(0, 1, 0), 6)) {
                Vec3 pull = c.subtract(e.position());
                double d = pull.length();
                Vec3 v = pull.normalize().scale(Math.min(0.6, 0.15 + d * 0.06)).add(0, 0.12, 0);
                e.setDeltaMovement(v);
                e.hurtMarked = true;
                if (d < 2 && t % 4 == 0) damage(p, e, bk(3));
            }
            if (t % 15 == 0) soundAt(l, c, SoundEvents.PHANTOM_FLAP, 1.2f, 0.6f);
        }));
        return 240;
    }

    @Override
    public void passives(ServerPlayer p, ItemStack w, boolean bankai) {
        buff(p, MobEffects.MOVEMENT_SPEED, bankai ? 1 : 0);
        buff(p, MobEffects.DAMAGE_BOOST, bankai ? 1 : 0);
        if (bankai) buff(p, MobEffects.JUMP, 2);
    }

    @Override
    public void aura(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        for (int i = 0; i < 4; i++) {
            fly(l, ModParticles.SHADOW_WISP.get(), c.add(jit(l, 1.0)).add(0, 0.1, 0),
                    new Vec3((l.random.nextDouble() - 0.5) * 0.2, 0.01, (l.random.nextDouble() - 0.5) * 0.2));
        }
        l.sendParticles(ModParticles.KIMONO_FLOWER.get(), c.x, c.y + 2.2, c.z, 2, 0.8, 0.2, 0.8, 0.01);
    }

    /** Takaoni rule: higher ground hits harder. */
    @Override
    public void onMeleeHit(ServerPlayer p, ItemStack w, boolean bankai, LivingEntity target, LivingHurtEvent event) {
        if (p.getY() > target.getY() + 0.9) {
            event.setAmount(event.getAmount() * 1.5f);
            ServerLevel l = p.serverLevel();
            burst(l, ModParticles.KIMONO_FLOWER.get(), chest(target), 8, 0.2);
            l.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY() + 1, target.getZ(), 8, 0.3, 0.4, 0.3, 0.2);
        }
    }

    /** Shared wounds: what you suffer, they suffer. */
    @Override
    public void onHurt(ServerPlayer p, ItemStack w, boolean bankai, LivingHurtEvent event) {
        if (!bankai || sharing || event.getAmount() <= 0) return;
        sharing = true;
        try {
            ServerLevel l = p.serverLevel();
            float shared = event.getAmount() * 0.75f;
            for (LivingEntity e : Targeting.around(p, p.position(), 10)) {
                damage(p, e, shared);
                line(l, dust(0.8f, 0.05f, 0.1f, 1.0f), chest(p), chest(e), 0.4);
            }
        } finally {
            sharing = false;
        }
    }
}
