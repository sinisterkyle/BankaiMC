package com.bankaimc.ability;

import com.bankaimc.ModParticles;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;

/**
 * "Frozen in place" status used by Kyoka Suigetsu (hypnosis) and Hyorinmaru (ice).
 * Stored on the entity's persistent NBT so it is always undone, even after a server restart.
 */
public final class Hypnosis {
    private static final String UNTIL = "bankaimc_frozen_until";
    private static final String PREV_NOAI = "bankaimc_prev_noai";
    private static final String FROST = "bankaimc_frost";
    private static final String SHATTER = "bankaimc_shatter";
    private static final String SHATTER_BY = "bankaimc_shatter_by";
    private static final String CHARM_UNTIL = "bankaimc_charm_until";
    private static final String CHARM_BY = "bankaimc_charm_by";

    private Hypnosis() {}

    /**
     * @param frost      ice visuals instead of hypnosis visuals
     * @param shatterDmg extra damage dealt by {@code caster} the moment the effect ends (0 for none)
     */
    public static void apply(LivingEntity e, int ticks, boolean frost, ServerPlayer caster, float shatterDmg) {
        CompoundTag d = e.getPersistentData();
        long until = e.level().getGameTime() + ticks;
        d.putLong(UNTIL, Math.max(until, d.getLong(UNTIL)));
        d.putBoolean(FROST, frost);
        if (e instanceof Mob m) {
            if (!d.contains(PREV_NOAI)) d.putBoolean(PREV_NOAI, m.isNoAi());
            m.setTarget(null);
            m.getNavigation().stop();
            m.setNoAi(true);
        } else {
            // players can't be AI-frozen; lock them down with effects instead
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 9, false, false));
            e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, ticks, 0, false, false));
            e.addEffect(new MobEffectInstance(MobEffects.JUMP, ticks, 128, false, false)); // 128+ = can't jump
        }
        e.addEffect(new MobEffectInstance(MobEffects.GLOWING, ticks, 0, false, false));
        if (shatterDmg > 0 && caster != null) {
            d.putFloat(SHATTER, d.getFloat(SHATTER) + shatterDmg);
            d.putUUID(SHATTER_BY, caster.getUUID());
        }
    }

    public static boolean isFrozen(LivingEntity e) {
        return e.getPersistentData().contains(UNTIL);
    }

    /** Kyoka Suigetsu: the mob sees the caster in other mobs and attacks them instead. */
    public static void charm(Mob m, ServerPlayer caster, int ticks) {
        CompoundTag d = m.getPersistentData();
        d.putLong(CHARM_UNTIL, m.level().getGameTime() + ticks);
        d.putUUID(CHARM_BY, caster.getUUID());
        retarget(m, caster.getUUID());
    }

    /** True if this mob is charmed by that player (used to stop it re-targeting them). */
    public static boolean isCharmedBy(LivingEntity e, java.util.UUID player) {
        CompoundTag d = e.getPersistentData();
        return d.contains(CHARM_UNTIL) && e.level().getGameTime() < d.getLong(CHARM_UNTIL)
                && d.hasUUID(CHARM_BY) && d.getUUID(CHARM_BY).equals(player);
    }

    private static void retarget(Mob m, java.util.UUID caster) {
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (LivingEntity o : m.level().getEntitiesOfClass(LivingEntity.class, m.getBoundingBox().inflate(16),
                o -> o != m && o.isAlive() && !(o instanceof net.minecraft.world.entity.player.Player)
                        && !(o instanceof net.minecraft.world.entity.decoration.ArmorStand))) {
            double dd = o.distanceToSqr(m);
            if (dd < bestD) { bestD = dd; best = o; }
        }
        m.setTarget(best);
        if (best instanceof Mob om && (om.getTarget() == null || om.getTarget().getUUID().equals(caster))) om.setTarget(m);
    }

    /**
     * Kyoka Suigetsu Bankai: break every non-ice illusion this player is holding right now, multiplying its shatter damage.
     * @return how many illusions were shattered
     */
    public static int shatterAll(ServerPlayer p, double radius, float mult) {
        int n = 0;
        long now = p.level().getGameTime();
        for (LivingEntity e : p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(radius))) {
            CompoundTag d = e.getPersistentData();
            if (d.contains(UNTIL) && !d.getBoolean(FROST) && d.hasUUID(SHATTER_BY) && d.getUUID(SHATTER_BY).equals(p.getUUID())) {
                d.putFloat(SHATTER, d.getFloat(SHATTER) * mult);
                d.putLong(UNTIL, now);
                n++;
            }
        }
        return n;
    }

    /** Called every tick for every living entity on the server. */
    public static void tick(LivingEntity e) {
        CompoundTag d = e.getPersistentData();
        ServerLevel level = (ServerLevel) e.level();
        if (d.contains(CHARM_UNTIL)) {
            if (level.getGameTime() >= d.getLong(CHARM_UNTIL) || !(e instanceof Mob)) {
                d.remove(CHARM_UNTIL);
                d.remove(CHARM_BY);
            } else if (e.tickCount % 10 == 0 && e instanceof Mob m) {
                LivingEntity t = m.getTarget();
                java.util.UUID by = d.getUUID(CHARM_BY);
                if (t == null || !t.isAlive() || t.getUUID().equals(by)) retarget(m, by);
                Vec3 top = e.position().add(0, e.getBbHeight() + 0.4, 0);
                level.sendParticles(ModParticles.MIRROR_SHARD.get(), top.x, top.y, top.z, 2, 0.2, 0.1, 0.2, 0);
            }
        }
        if (!d.contains(UNTIL)) return;
        boolean frost = d.getBoolean(FROST);

        if (level.getGameTime() < d.getLong(UNTIL)) {
            Vec3 v = e.getDeltaMovement();
            e.setDeltaMovement(0, Math.min(0, v.y), 0);
            if (frost) e.setTicksFrozen(Math.max(e.getTicksFrozen(), e.getTicksRequiredToFreeze()));
            if (e.tickCount % 3 == 0) {
                Vec3 c = e.position().add(0, e.getBbHeight() * 0.55, 0);
                if (frost) {
                    level.sendParticles(ModParticles.ICE_SHARD.get(), c.x, c.y, c.z, 2,
                            e.getBbWidth() * 0.5, e.getBbHeight() * 0.4, e.getBbWidth() * 0.5, 0.0);
                } else {
                    // mirror shards circling the hypnotized target
                    double r = e.getBbWidth() * 0.5 + 0.5;
                    for (int i = 0; i < 2; i++) {
                        double a = e.tickCount * 0.25 + i * Math.PI;
                        Fx.fly(level, ModParticles.MIRROR_SHARD.get(),
                                c.add(Math.cos(a) * r, Math.sin(e.tickCount * 0.1 + i) * 0.3, Math.sin(a) * r),
                                new Vec3(-Math.sin(a) * 0.08, 0, Math.cos(a) * 0.08));
                    }
                }
            }
            return;
        }

        // effect over: restore AI and deliver the shatter damage
        d.remove(UNTIL);
        d.remove(FROST);
        if (e instanceof Mob m) m.setNoAi(d.getBoolean(PREV_NOAI));
        d.remove(PREV_NOAI);
        if (d.contains(SHATTER)) {
            float amount = d.getFloat(SHATTER);
            ServerPlayer caster = d.hasUUID(SHATTER_BY) ? level.getServer().getPlayerList().getPlayer(d.getUUID(SHATTER_BY)) : null;
            d.remove(SHATTER);
            d.remove(SHATTER_BY);
            Fx.burst(level, frost ? ModParticles.ICE_SHARD.get() : ModParticles.MIRROR_SHARD.get(),
                    e.position().add(0, e.getBbHeight() * 0.5, 0), 35, 0.4);
            level.playSound(null, e.blockPosition(), SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 1.0f, 0.7f);
            if (caster != null) {
                Fx.damage(caster, e, amount);
            } else {
                e.invulnerableTime = 0;
                e.hurt(level.damageSources().magic(), amount);
            }
        }
    }
}
