package com.bankaimc.ability.kit;

import com.bankaimc.ModParticles;
import com.bankaimc.Targeting;
import com.bankaimc.ZanpakutoData;
import com.bankaimc.ability.PlayerState;
import com.bankaimc.ability.SpiritKit;
import com.bankaimc.task.TaskManager;
import com.bankaimc.task.TimedTask;
import com.bankaimc.task.WaveTask;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import static com.bankaimc.ability.Fx.*;

/**
 * Benihime (Urahara Kisuke) - the scientist's blade. Its Bankai "restructures" anything it cuts, stitching it into a new shape.
 * Trait: sword hits ANALYZE the target for 10s: it takes +25% damage from all your abilities.
 * Shikai:  V = Cry, Benihime (crimson blast that bursts on impact) | Sneak+V = Blood Mist Shield (blocks everything from the front for 4s)
 * Bankai:  Trait: once per Bankai, a killing blow is stitched closed - you survive at 40% health.
 *          V = Restructure (stitch an enemy apart: crippled, analyzed, heavy damage) | Sneak+V = Self-Stitch (sew your own wounds shut)
 */
public class BenihimeKit implements SpiritKit {
    private static final String SHIELD = "benihime_shield";
    private static final String STITCH_USED = "StitchUsed";

    private static ParticleOptions crimson() {
        return dust(0.85f, 0.08f, 0.22f, 1.6f);
    }

    /** A row of X-stitches from a to b (a "seam"). */
    private static void seam(ServerLevel l, Vec3 a, Vec3 b, double spacing) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        for (double s = 0; s <= len; s += spacing) dot(l, ModParticles.STITCH.get(), a.add(d.scale(s / len)));
        line(l, dust(0.7f, 0.05f, 0.15f, 0.6f), a, b, 0.15);
    }

    /** Shibari Benihime: a net of crimson light pins the target for 2 seconds. */
    private static void shibari(ServerPlayer p, LivingEntity e) {
        ServerLevel l = p.serverLevel();
        e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 6));
        e.addEffect(new MobEffectInstance(MobEffects.JUMP, 40, 128));
        TaskManager.add(new TimedTask(p, 40, k -> {
            if (!e.isAlive() || k % 4 != 0) return;
            Vec3 top = e.position().add(0, e.getBbHeight() + 0.5, 0);
            double r = e.getBbWidth() * 0.5 + 0.6;
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4;
                line(l, crimson(), e.position().add(Math.cos(a) * r, 0.05, Math.sin(a) * r), top, 0.3);
            }
            ring(l, crimson(), e.position(), r, 16, e.getBbHeight() * 0.5);
        }));
    }

    @Override
    public int shikai(ServerPlayer p, ItemStack w) {
        sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 1.4f, 1.6f);
        sound(p, SoundEvents.FIRECHARGE_USE, 1.0f, 1.5f);
        WaveTask.Visual blast = (l, pos, dir, right, hw, step) -> {
            l.sendParticles(ModParticles.CRIMSON_SPARK.get(), pos.x, pos.y, pos.z, 4, 0.2, 0.2, 0.2, 0.02);
            dot(l, crimson(), pos.add(right.scale(Math.sin(step) * hw)));
            dot(l, crimson(), pos.subtract(right.scale(Math.sin(step) * hw)));
        };
        TaskManager.add(new WaveTask(p, 2.6, 32, 1.2, 16, blast, ModParticles.CRIMSON_SPARK.get(), e -> {
            ServerLevel l = p.serverLevel();
            burst(l, ModParticles.CRIMSON_SPARK.get(), chest(e), 30, 0.4);
            soundAt(l, chest(e), SoundEvents.GENERIC_EXPLODE, 0.6f, 1.6f);
            for (LivingEntity o : Targeting.around(p, e.position(), 3)) {
                if (o != e) damage(p, o, 6);
                shibari(p, o);
            }
        }));
        return 60;
    }

    /** Chikasumi no Tate: a hexagonal wall of blood mist in front of you. */
    @Override
    public int shikaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        PlayerState.setFor(p, SHIELD, 80);
        sound(p, SoundEvents.SHIELD_BLOCK, 1.5f, 0.6f);
        actionBar(p, "Chikasumi no Tate - Blood Mist Shield", 0xE0204A);
        TaskManager.add(new TimedTask(p, 80, t -> {
            Vec3 look = p.getLookAngle();
            Vec3 right = rightOf(look);
            Vec3 up = right.cross(look).normalize();
            Vec3 c = p.getEyePosition().add(look.scale(1.6)).subtract(0, 0.3, 0);
            // honeycomb of hexagon centres
            for (int row = -2; row <= 2; row++) {
                for (int col = -2; col <= 2; col++) {
                    double ox = col * 0.55 + (row % 2 == 0 ? 0 : 0.275);
                    Vec3 hc = c.add(right.scale(ox)).add(up.scale(row * 0.48));
                    if (t % 3 == 0) {
                        for (int k = 0; k < 6; k++) {
                            double a = k * Math.PI / 3;
                            dot(l, crimson(), hc.add(right.scale(Math.cos(a) * 0.28)).add(up.scale(Math.sin(a) * 0.28)));
                        }
                    }
                }
            }
            if (t % 4 == 0) l.sendParticles(ModParticles.CRIMSON_SPARK.get(), c.x, c.y, c.z, 3, 0.6, 0.6, 0.6, 0);
            for (Projectile pr : l.getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(2.2), pr -> pr.getOwner() != p)) {
                burst(l, ModParticles.CRIMSON_SPARK.get(), pr.position(), 10, 0.2);
                pr.discard();
            }
        }));
        return 240;
    }

    /** Restructure: stitches race across the target, then everything is sewn into a weaker shape. */
    @Override
    public int bankai(ServerPlayer p, ItemStack w) {
        LivingEntity t = lookTarget(p, 22);
        if (t == null) {
            actionBar(p, "Restructure - look at an enemy within 22 blocks.", 0xFF3B6B);
            return 0;
        }
        ServerLevel l = p.serverLevel();
        sound(p, SoundEvents.ENCHANTMENT_TABLE_USE, 1.5f, 0.5f);
        actionBar(p, "Kannonbiraki Benihime Aratame - Restructure", 0xFF3B6B);
        t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 6));
        TaskManager.add(new TimedTask(p, 30, k -> {
            if (!t.isAlive()) return;
            double hw = t.getBbWidth() * 0.5 + 0.3;
            double h = t.getBbHeight();
            Vec3 b = t.position();
            if (k % 3 == 0) {
                // seams wrapping around the body, more of them each moment
                int seams = 1 + k / 6;
                for (int i = 0; i < seams; i++) {
                    double a = i * 1.3 + k * 0.05;
                    Vec3 from = b.add(Math.cos(a) * hw, 0.1, Math.sin(a) * hw);
                    Vec3 to = b.add(Math.cos(a + 2.2) * hw, h, Math.sin(a + 2.2) * hw);
                    seam(l, from, to, 0.35);
                }
                soundAt(l, chest(t), SoundEvents.WOOL_PLACE, 1.0f, 1.6f);
            }
            if (k == 29) {
                // everything near the target is sewn to it and dragged in
                int sewn = 0;
                for (LivingEntity o : Targeting.around(p, t.position(), 6)) {
                    if (o == t || sewn >= 3) continue;
                    sewn++;
                    seam(l, chest(o), chest(t), 0.35);
                    Vec3 pull = t.position().subtract(o.position()).normalize().scale(0.9);
                    o.setDeltaMovement(pull.x, 0.2, pull.z);
                    o.hurtMarked = true;
                    damage(p, o, bk(10));
                    analyze(o, p, 400);
                    o.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 2));
                    o.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 1));
                }
                burst(l, ModParticles.STITCH.get(), chest(t), 40, 0.35);
                soundAt(l, chest(t), SoundEvents.ZOMBIE_VILLAGER_CURE, 0.8f, 1.6f);
                damage(p, t, bk(20));
                analyze(t, p, 400);
                t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 400, 3));
                t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 400, 2));
                t.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 400, 2));
                t.addEffect(new MobEffectInstance(MobEffects.GLOWING, 400, 0));
            }
        }));
        return 300;
    }

    /** Self-Stitch: sew your own wounds shut. */
    @Override
    public int bankaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        p.heal(p.getMaxHealth() * 0.6f);
        cleanse(p);
        p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 600, 1));
        sound(p, SoundEvents.ZOMBIE_VILLAGER_CURE, 0.8f, 1.8f);
        actionBar(p, "Self-Stitch", 0xFF3B6B);
        TaskManager.add(new TimedTask(p, 24, t -> {
            Vec3 c = p.position();
            double a = t * 0.5;
            double y = t * 0.08;
            seam(l, c.add(Math.cos(a) * 0.5, y, Math.sin(a) * 0.5), c.add(Math.cos(a + 1) * 0.5, y + 0.15, Math.sin(a + 1) * 0.5), 0.3);
        }));
        return 600;
    }

    /**
     * Shikai: crimson sparks spiral up the blade.
     * Bankai: a giant crimson spirit of you rises out of the ground behind you, leans over you, and unravels into stitches.
     */
    @Override
    public void onRelease(ServerPlayer p, ItemStack w, boolean bankai) {
        ServerLevel l = p.serverLevel();
        if (!bankai) {
            TaskManager.add(new TimedTask(p, 16, t -> {
                Vec3 hand = p.position().add(p.getLookAngle().scale(0.6)).add(0, 1.0, 0);
                double a = t * 0.8;
                dot(l, ModParticles.CRIMSON_SPARK.get(), hand.add(Math.cos(a) * 0.3, t * 0.08, Math.sin(a) * 0.3));
            }));
            return;
        }
        ZanpakutoData.setFlag(w, STITCH_USED, false);
        sound(p, SoundEvents.BELL_RESONATE, 1.5f, 0.8f);
        sound(p, SoundEvents.WARDEN_EMERGE, 0.8f, 1.4f);
        // a giant spirit (your own skin, crimson and glowing) rises behind you and leans over you
        com.bankaimc.entity.SpiritSummonEntity.spawn(l, p);
    }

    /** Bankai: once, a killing blow is stitched closed. */
    @Override
    public boolean onLethal(ServerPlayer p, ItemStack w, boolean bankai) {
        if (!bankai || ZanpakutoData.getFlag(w, STITCH_USED)) return false;
        ZanpakutoData.setFlag(w, STITCH_USED, true);
        p.setHealth(p.getMaxHealth() * 0.4f);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 4));
        ServerLevel l = p.serverLevel();
        burst(l, ModParticles.STITCH.get(), chest(p), 50, 0.4);
        sound(p, SoundEvents.TOTEM_USE, 0.8f, 1.4f);
        actionBar(p, "Benihime stitched you back together.", 0xFF3B6B);
        return true;
    }

    @Override
    public void passives(ServerPlayer p, ItemStack w, boolean bankai) {
        buff(p, MobEffects.MOVEMENT_SPEED, 0);
        buff(p, MobEffects.DAMAGE_BOOST, bankai ? 1 : 0);
        if (bankai) buff(p, MobEffects.DAMAGE_RESISTANCE, 1);
    }

    @Override
    public void aura(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        double a0 = p.tickCount * 0.1;
        for (int i = 0; i < 3; i++) {
            double a = a0 + i * (Math.PI * 2 / 3);
            dot(l, ModParticles.STITCH.get(), c.add(Math.cos(a) * 1.0, 1.2 + Math.sin(a0 * 2 + i) * 0.3, Math.sin(a) * 1.0));
        }
        l.sendParticles(ModParticles.CRIMSON_SPARK.get(), c.x, c.y + 1, c.z, 3, 0.6, 0.8, 0.6, 0);
        if (ZanpakutoData.getFlag(w, STITCH_USED)) return;
        dot(l, ModParticles.STITCH.get(), c.add(0, 2.3, 0)); // the stitch is still "loaded"
    }

    /** Analyze anything you cut. */
    @Override
    public void onMeleeHit(ServerPlayer p, ItemStack w, boolean bankai, LivingEntity target, LivingHurtEvent event) {
        analyze(target, p, 200);
        ServerLevel l = p.serverLevel();
        Vec3 top = target.position().add(0, target.getBbHeight() + 0.4, 0);
        dot(l, ModParticles.CRIMSON_SPARK.get(), top);
        if (bankai) seam(l, chest(target).add(-0.4, -0.3, 0), chest(target).add(0.4, 0.3, 0), 0.3);
    }

    /** Blood Mist Shield blocks everything coming from the front. */
    @Override
    public void onAttacked(ServerPlayer p, ItemStack w, boolean bankai, LivingAttackEvent event) {
        if (!PlayerState.active(p, SHIELD)) return;
        Vec3 from = event.getSource().getSourcePosition();
        if (from == null) return;
        Vec3 to = from.subtract(p.getEyePosition()).normalize();
        if (to.dot(p.getLookAngle()) > 0.25) {
            event.setCanceled(true);
            burst(p.serverLevel(), ModParticles.CRIMSON_SPARK.get(), p.getEyePosition().add(p.getLookAngle().scale(1.5)), 15, 0.25);
            sound(p, SoundEvents.SHIELD_BLOCK, 1.0f, 1.2f);
        }
    }
}
