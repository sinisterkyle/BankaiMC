package com.bankaimc.ability.kit;

import com.bankaimc.Config;
import com.bankaimc.ModParticles;
import com.bankaimc.Progression;
import com.bankaimc.Spirit;
import com.bankaimc.Targeting;
import com.bankaimc.ZanpakutoData;
import com.bankaimc.ability.SpiritKit;
import com.bankaimc.task.TaskManager;
import com.bankaimc.task.TimedTask;
import com.bankaimc.task.WaveTask;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static com.bankaimc.ability.Fx.*;

/**
 * Zangetsu - raw power. Sword hits charge a REIATSU meter (0-100).
 * Shikai:  V = Getsuga Tensho | Sneak+V = Full-Power Getsuga (spends the meter, scales with it)
 * Bankai:  V = Black Getsuga (or MUGETSU at 100 reiatsu) | Sneak+V = Shunpo slash (dash through enemies)
 * Mugetsu: a pillar of darkness that erases everything ahead - then your Bankai shuts off and rests twice as long.
 */
public class ZangetsuKit implements SpiritKit {

    @Override
    public int shikai(ServerPlayer p, ItemStack w) {
        sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 1.5f, 0.6f);
        sound(p, SoundEvents.TRIDENT_RIPTIDE_3, 1.0f, 1.3f);
        TaskManager.add(new WaveTask(p, 1.8, 26, 2.0, 14,
                crescent(ModParticles.REIATSU_BLUE.get(), ParticleTypes.SWEEP_ATTACK, 3),
                ModParticles.REIATSU_BLUE.get(), null));
        return 60;
    }

    @Override
    public int shikaiAlt(ServerPlayer p, ItemStack w) {
        int meter = ZanpakutoData.getReiatsu(w);
        if (meter < 30) {
            actionBar(p, "Not enough reiatsu (" + meter + "/30). Land sword hits to charge it.", 0x5AA9FF);
            return 0;
        }
        ZanpakutoData.setReiatsu(w, 0);
        float dmg = 14 + meter * 0.4f;        // up to 54
        double width = 2 + meter / 33.0;      // up to 5 blocks wide
        ServerLevel l = p.serverLevel();
        burst(l, ModParticles.REIATSU_BLUE.get(), chest(p), 50, 0.5);
        sound(p, SoundEvents.WARDEN_SONIC_BOOM, 1.0f, 1.3f);
        sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 2.0f, 0.4f);
        TaskManager.add(new WaveTask(p, 2.2, 34, width, dmg,
                crescent(ModParticles.REIATSU_BLUE.get(), dust(1f, 1f, 1f, 2.2f), 1),
                ModParticles.REIATSU_BLUE.get(),
                e -> e.knockback(1.5, p.getX() - e.getX(), p.getZ() - e.getZ())));
        actionBar(p, "Getsuga Tensho! (" + meter + " reiatsu)", 0x5AA9FF);
        return 80;
    }

    @Override
    public int bankai(ServerPlayer p, ItemStack w) {
        if (ZanpakutoData.getReiatsu(w) >= 100) return mugetsu(p, w);
        sound(p, SoundEvents.WARDEN_SONIC_BOOM, 1.2f, 0.8f);
        sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 1.5f, 0.4f);
        TaskManager.add(new WaveTask(p, 2.4, 42, 3.0, bk(30),
                crescent(ModParticles.REIATSU_BLACK.get(), dust(0.85f, 0.05f, 0.1f, 2.0f), 1),
                ModParticles.REIATSU_BLACK.get(),
                e -> e.knockback(1.2, p.getX() - e.getX(), p.getZ() - e.getZ())));
        return 50;
    }

    /** Shunpo: flash forward up to 12 blocks, cutting everything you pass through. */
    @Override
    public int bankaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, Math.max(-0.3, Math.min(0.3, look.y)), look.z).normalize();
        Vec3 start = p.position();
        Vec3 end = start;
        for (double d = 0.5; d <= 12; d += 0.5) {
            Vec3 next = start.add(flat.scale(d));
            if (solid(l, next) || solid(l, next.add(0, 1, 0))) break;
            end = next;
        }
        if (end.distanceToSqr(start) < 1) {
            actionBar(p, "No room to flash step.", 0x888888);
            return 0;
        }
        // afterimages along the path
        double len = start.distanceTo(end);
        for (double d = 0; d < len; d += 0.7) {
            Vec3 at = start.add(flat.scale(d));
            column(l, ModParticles.REIATSU_BLACK.get(), at, 1.8, 0.45, 0.0);
        }
        Set<UUID> hit = new HashSet<>();
        AABB box = new AABB(start, end).inflate(2);
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, box, e -> Targeting.valid(p, e))) {
            if (distToSegment(chest(e), start.add(0, 1, 0), end.add(0, 1, 0)) < 2.2 && hit.add(e.getUUID())) {
                damage(p, e, bk(9));
                l.sendParticles(ParticleTypes.SWEEP_ATTACK, e.getX(), e.getY() + 1, e.getZ(), 2, 0.3, 0.3, 0.3, 0);
                burst(l, dust(0.85f, 0.05f, 0.1f, 1.4f), chest(e), 10, 0.2);
            }
        }
        p.teleportTo(l, end.x, end.y, end.z, p.getYRot(), p.getXRot());
        p.fallDistance = 0;
        sound(p, SoundEvents.ENDER_DRAGON_FLAP, 1.0f, 2.0f);
        sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 1.2f, 1.5f);
        if (!hit.isEmpty()) ZanpakutoData.setReiatsu(w, ZanpakutoData.getReiatsu(w) + 4 * hit.size());
        return 30;
    }

    /** The final Getsuga Tensho. Wipes out everything in front of you, then your power is spent. */
    private int mugetsu(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        ZanpakutoData.setReiatsu(w, 0);
        Vec3 dir = p.getLookAngle().normalize();
        Vec3 right = rightOf(dir);
        Vec3 origin = p.getEyePosition();
        sound(p, SoundEvents.WITHER_SPAWN, 1.5f, 0.5f);
        sound(p, SoundEvents.WARDEN_SONIC_BOOM, 2.0f, 0.4f);
        actionBar(p, "MUGETSU", 0xC0102A);
        for (LivingEntity e : Targeting.around(p, p.position(), 30)) effect(e, MobEffects.DARKNESS, 120, 0);
        Set<UUID> hit = new HashSet<>();
        TaskManager.add(new TimedTask(p, 30, t -> {
            double reach = Math.min(60, (t + 1) * 4.0);
            double prev = Math.max(0, reach - 4);
            for (double d = prev; d < reach; d += 0.6) {
                Vec3 c = origin.add(dir.scale(d));
                // a wall of darkness 10 blocks wide and 12 tall
                for (int i = 0; i < 6; i++) {
                    Vec3 at = c.add(right.scale((l.random.nextDouble() - 0.5) * 10)).add(0, l.random.nextDouble() * 12 - 4, 0);
                    fly(l, ModParticles.REIATSU_BLACK.get(), at, new Vec3(0, 0.25, 0));
                }
                if (l.random.nextInt(3) == 0) dot(l, dust(0.6f, 0f, 0.05f, 3f), c.add(jit(l, 2)));
            }
            AABB box = new AABB(origin.add(dir.scale(prev)), origin.add(dir.scale(reach))).inflate(6, 8, 6);
            for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, box, e -> Targeting.valid(p, e))) {
                if (hit.add(e.getUUID())) damage(p, e, bk(60));
            }
            if (t == 29) {
                // the cost: Bankai is over, and it needs double the rest
                Spirit s = ZanpakutoData.getSpirit(w);
                if (s != null && ZanpakutoData.getRelease(w) == ZanpakutoData.BANKAI) {
                    Progression.seal(p, w, s);
                    if (!Progression.isTestMode(p)) {
                        ZanpakutoData.setBankaiCd(w, p.level().getGameTime() + Config.BANKAI_COOLDOWN_SECONDS.get() * 40L);
                    }
                    actionBar(p, "Your power is spent...", 0x777777);
                }
            }
        }));
        return 20;
    }

    @Override
    public void passives(ServerPlayer p, ItemStack w, boolean bankai) {
        buff(p, MobEffects.DAMAGE_BOOST, bankai ? 1 : 0);
        buff(p, MobEffects.MOVEMENT_SPEED, bankai ? 2 : 0);
        if (bankai) buff(p, MobEffects.JUMP, 1);
    }

    @Override
    public void aura(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        int meter = ZanpakutoData.getReiatsu(w);
        for (int i = 0; i < 4 + meter / 15; i++) {
            fly(l, ModParticles.REIATSU_BLACK.get(), c.add(jit(l, 0.6)).add(0, 0.2, 0), new Vec3(0, 0.12, 0));
        }
        if (meter >= 100) l.sendParticles(dust(0.9f, 0.05f, 0.1f, 2f), c.x, c.y + 1, c.z, 6, 0.5, 0.9, 0.5, 0);
    }

    /** Sword hits charge reiatsu. */
    @Override
    public void onMeleeHit(ServerPlayer p, ItemStack w, boolean bankai, LivingEntity target, LivingHurtEvent event) {
        int before = ZanpakutoData.getReiatsu(w);
        ZanpakutoData.setReiatsu(w, before + (bankai ? 10 : 6));
        burst(p.serverLevel(), bankai ? ModParticles.REIATSU_BLACK.get() : ModParticles.REIATSU_BLUE.get(), chest(target), 6, 0.15);
        if (before < 100 && ZanpakutoData.getReiatsu(w) >= 100) {
            actionBar(p, bankai ? "Reiatsu overflowing. [V] = MUGETSU" : "Reiatsu full! [Sneak+V]", 0xC0102A);
            sound(p, SoundEvents.BEACON_POWER_SELECT, 1.0f, 0.6f);
        }
    }
}
