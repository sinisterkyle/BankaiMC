package com.bankaimc.ability;

import com.bankaimc.Spirit;
import com.bankaimc.ability.kit.*;

import java.util.EnumMap;
import java.util.Map;

public final class Kits {
    private static final Map<Spirit, SpiritKit> KITS = new EnumMap<>(Spirit.class);

    static {
        KITS.put(Spirit.ZANGETSU, new ZangetsuKit());
        KITS.put(Spirit.HYORINMARU, new HyorinmaruKit());
        KITS.put(Spirit.SENBONZAKURA, new SenbonzakuraKit());
        KITS.put(Spirit.KYOKA_SUIGETSU, new KyokaSuigetsuKit());
        KITS.put(Spirit.KATEN_KYOKOTSU, new KatenKyokotsuKit());
        KITS.put(Spirit.RYUJIN_JAKKA, new RyujinJakkaKit());
        KITS.put(Spirit.MINAZUKI, new MinazukiKit());
        KITS.put(Spirit.BENIHIME, new BenihimeKit());
        KITS.put(Spirit.ZABIMARU, new ZabimaruKit());
        KITS.put(Spirit.SHINSO, new ShinsoKit());
    }

    private Kits() {}

    public static SpiritKit get(Spirit s) {
        return KITS.get(s);
    }
}
