package com.bankaimc.ability;

import com.bankaimc.Config;
import com.bankaimc.ModParticles;
import com.bankaimc.Spirit;
import com.bankaimc.Targeting;
import com.bankaimc.task.TaskManager;
import com.bankaimc.task.TimedTask;
import com.bankaimc.task.WaveTask;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Shared helpers for every spirit: damage, particles, sounds, targeting. */
public final class Fx {
    private Fx() {}

    // ------------------------------------------------------------------ damage

    private static boolean abilityDamage = false;

    /** True while an ability (not a sword swing) is dealing damage. Traits use this to ignore ability hits. */
    public static boolean isAbilityDamage() {
        return abilityDamage;
    }

    public static void damage(ServerPlayer p, LivingEntity target, float base) {
        if (!target.isAlive()) return;
        boolean prev = abilityDamage;
        abilityDamage = true;
        try {
            target.invulnerableTime = 0; // abilities ignore the normal 0.5s hit immunity
            float amount = (float) (base * Config.DAMAGE_MULTIPLIER.get());
            if (isAnalyzedBy(target, p)) amount *= 1.25f;
            target.hurt(p.damageSources().playerAttack(p), amount);
        } finally {
            abilityDamage = prev;
        }
    }

    /** Benihime: an enemy "analyzed" by this player takes +25% from their abilities. */
    public static void analyze(LivingEntity e, ServerPlayer by, int ticks) {
        e.getPersistentData().putLong("bankaimc_analyzed_until", e.level().getGameTime() + ticks);
        e.getPersistentData().putUUID("bankaimc_analyzed_by", by.getUUID());
    }

    public static boolean isAnalyzedBy(LivingEntity e, ServerPlayer p) {
        var d = e.getPersistentData();
        return d.getLong("bankaimc_analyzed_until") > e.level().getGameTime()
                && d.hasUUID("bankaimc_analyzed_by") && d.getUUID("bankaimc_analyzed_by").equals(p.getUUID());
    }

    /** Remove every harmful effect from an entity. */
    public static void cleanse(LivingEntity e) {
        java.util.List<MobEffect> bad = new java.util.ArrayList<>();
        for (MobEffectInstance i : e.getActiveEffects()) if (!i.getEffect().isBeneficial()) bad.add(i.getEffect());
        for (MobEffect m : bad) e.removeEffect(m);
    }

    /** Scales a Bankai damage number by bankaiPowerMultiplier. */
    public static float bk(float base) {
        return (float) (base * Config.BANKAI_POWER.get());
    }

    public static void effect(LivingEntity e, MobEffect eff, int ticks, int amp) {
        e.addEffect(new MobEffectInstance(eff, ticks, amp));
    }

    /** Short ambient buff refreshed every 10 ticks while released. */
    public static void buff(ServerPlayer p, MobEffect eff, int amp) {
        p.addEffect(new MobEffectInstance(eff, 40, amp, true, false, true));
    }

    // ------------------------------------------------------------------ feedback

    public static void sound(ServerPlayer p, SoundEvent s, float vol, float pitch) {
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), s, SoundSource.PLAYERS, vol, pitch);
    }

    public static void soundAt(ServerLevel l, Vec3 at, SoundEvent s, float vol, float pitch) {
        l.playSound(null, at.x, at.y, at.z, s, SoundSource.PLAYERS, vol, pitch);
    }

    public static void actionBar(ServerPlayer p, String text, int color) {
        p.displayClientMessage(Component.literal(text).withStyle(st -> st.withColor(color).withBold(true)), true);
    }

    // ------------------------------------------------------------------ geometry / targeting

    public static Vec3 chest(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.6, 0);
    }

    public static double distToSegment(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double t = Mth.clamp(p.subtract(a).dot(ab) / Math.max(1.0E-6, ab.lengthSqr()), 0, 1);
        return p.distanceTo(a.add(ab.scale(t)));
    }

    /** Where the player is looking, stopping at the first block. */
    public static Vec3 lookPoint(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        return p.level().clip(new ClipContext(eye, eye.add(p.getLookAngle().scale(range)), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, p)).getLocation();
    }

    /** The enemy closest to the player's crosshair line, or null. */
    public static LivingEntity lookTarget(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 end = lookPoint(p, range);
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : p.level().getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(2),
                e -> Targeting.valid(p, e))) {
            double off = distToSegment(chest(e), eye, end);
            if (off < e.getBbWidth() * 0.5 + 1.0) {
                double d = e.distanceToSqr(p);
                if (d < bestDist) { bestDist = d; best = e; }
            }
        }
        return best;
    }

    public static Vec3 rightOf(Vec3 dir) {
        Vec3 r = dir.cross(new Vec3(0, 1, 0));
        return r.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : r.normalize();
    }

    public static boolean solid(ServerLevel l, Vec3 at) {
        BlockPos bp = BlockPos.containing(at);
        return !l.getBlockState(bp).getCollisionShape(l, bp).isEmpty();
    }

    // ------------------------------------------------------------------ particles

    public static DustParticleOptions dust(int color, float size) {
        return new DustParticleOptions(Spirit.rgb(color), size);
    }

    public static DustParticleOptions dust(float r, float g, float b, float size) {
        return new DustParticleOptions(new Vector3f(r, g, b), size);
    }

    public static Vec3 randomUnit(RandomSource r) {
        double y = r.nextDouble() * 2 - 1;
        double a = r.nextDouble() * Math.PI * 2;
        double h = Math.sqrt(1 - y * y);
        return new Vec3(Math.cos(a) * h, y, Math.sin(a) * h);
    }

    public static Vec3 jit(ServerLevel l, double j) {
        return new Vec3((l.random.nextDouble() - 0.5) * 2 * j, (l.random.nextDouble() - 0.5) * 2 * j, (l.random.nextDouble() - 0.5) * 2 * j);
    }

    /** One particle at rest. */
    public static void dot(ServerLevel l, ParticleOptions part, Vec3 at) {
        l.sendParticles(part, at.x, at.y, at.z, 1, 0, 0, 0, 0);
    }

    /** One particle with an exact velocity (count 0 = the offsets become the velocity). */
    public static void fly(ServerLevel l, ParticleOptions part, Vec3 pos, Vec3 vel) {
        l.sendParticles(part, pos.x, pos.y, pos.z, 0, vel.x, vel.y, vel.z, 1.0);
    }

    /** Particles exploding outward in every direction. */
    public static void burst(ServerLevel l, ParticleOptions part, Vec3 c, int count, double speed) {
        for (int i = 0; i < count; i++) {
            fly(l, part, c, randomUnit(l.random).scale(speed * (0.5 + l.random.nextDouble() * 0.7)));
        }
    }

    /** Particles collapsing inward onto a point. */
    public static void implode(ServerLevel l, ParticleOptions part, Vec3 c, int count, double radius) {
        for (int i = 0; i < count; i++) {
            Vec3 from = c.add(randomUnit(l.random).scale(radius));
            fly(l, part, from, c.subtract(from).scale(0.18));
        }
    }

    /** Particles flying from a to b. */
    public static void stream(ServerLevel l, ParticleOptions part, Vec3 a, Vec3 b, int count, double speed, double jitter) {
        Vec3 d = b.subtract(a);
        Vec3 dir = d.normalize();
        for (int i = 0; i < count; i++) {
            fly(l, part, a.add(d.scale(l.random.nextDouble())).add(jit(l, jitter)), dir.scale(speed));
        }
    }

    /** A still line (threads, beams, edges). */
    public static void line(ServerLevel l, ParticleOptions part, Vec3 a, Vec3 b, double spacing) {
        double len = a.distanceTo(b);
        Vec3 dir = b.subtract(a).normalize();
        for (double d = 0; d <= len; d += spacing) dot(l, part, a.add(dir.scale(d)));
    }

    /** A vertical column. */
    public static void column(ServerLevel l, ParticleOptions part, Vec3 base, double height, double spacing, double rise) {
        for (double y = 0; y <= height; y += spacing) {
            fly(l, part, base.add(0, y, 0).add(jit(l, 0.12)), new Vec3(0, rise, 0));
        }
    }

    public static void ring(ServerLevel l, ParticleOptions part, Vec3 c, double r, int count, double y) {
        for (int i = 0; i < count; i++) {
            double a = (Math.PI * 2 * i) / count;
            dot(l, part, new Vec3(c.x + Math.cos(a) * r, c.y + y, c.z + Math.sin(a) * r));
        }
    }

    /** A ring that flies outward from the center. */
    public static void ringOut(ServerLevel l, ParticleOptions part, Vec3 c, double r, int count, double y, double speed) {
        for (int i = 0; i < count; i++) {
            double a = (Math.PI * 2 * i) / count + l.random.nextDouble() * 0.1;
            Vec3 out = new Vec3(Math.cos(a), 0, Math.sin(a));
            fly(l, part, c.add(out.scale(r)).add(0, y, 0), out.scale(speed));
        }
    }

    /** Swirl around a vertical axis (tornado / vortex). */
    public static void vortex(ServerLevel l, ParticleOptions part, Vec3 c, double rMin, double rMax, double height, int count, double spin) {
        for (int i = 0; i < count; i++) {
            double a = l.random.nextDouble() * Math.PI * 2;
            double r = rMin + l.random.nextDouble() * (rMax - rMin);
            fly(l, part, c.add(Math.cos(a) * r, l.random.nextDouble() * height, Math.sin(a) * r),
                    new Vec3(-Math.sin(a) * spin, 0.03, Math.cos(a) * spin));
        }
    }

    /** Crescent-shaped slash for WaveTask. */
    public static WaveTask.Visual crescent(ParticleOptions main, ParticleOptions accent, int accentEvery) {
        return (l, pos, dir, right, hw, step) -> {
            int n = (int) Math.max(6, hw * 6);
            for (int i = -n; i <= n; i++) {
                double t = (double) i / n;
                Vec3 p = pos.add(right.scale(t * hw)).subtract(dir.scale(t * t * hw * 0.6)).add(0, (1 - t * t) * 0.25, 0);
                l.sendParticles(main, p.x, p.y, p.z, 1, 0.03, 0.06, 0.03, 0);
            }
            if (accent != null && step % accentEvery == 0) dot(l, accent, pos);
        };
    }

    // ------------------------------------------------------------------ release visuals (shared shape, spirit particles)

    public static void shikaiRelease(ServerPlayer p, Spirit s) {
        ServerLevel l = p.serverLevel();
        burst(l, ModParticles.of(s, false), chest(p), 60, 0.35);
        sound(p, SoundEvents.ENCHANTMENT_TABLE_USE, 1.2f, 0.6f);
        sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.5f);
    }

    public static void bankaiRelease(ServerPlayer p, Spirit s) {
        ServerLevel l = p.serverLevel();
        ParticleOptions main = ModParticles.of(s, true);
        sound(p, SoundEvents.WITHER_SPAWN, 0.8f, 1.2f);
        sound(p, SoundEvents.WARDEN_SONIC_BOOM, 1.0f, 0.6f);
        for (LivingEntity e : Targeting.around(p, p.position(), 8)) {
            e.knockback(1.6, p.getX() - e.getX(), p.getZ() - e.getZ());
            damage(p, e, bk(6));
        }
        TaskManager.add(new TimedTask(p, 40, t -> {
            Vec3 pc = p.position();
            for (int i = 0; i < 4; i++) {
                double a = t * 0.5 + i * (Math.PI / 2);
                fly(l, main, pc.add(Math.cos(a) * 1.3, t * 0.2, Math.sin(a) * 1.3),
                        new Vec3(-Math.sin(a) * 0.15, 0.12, Math.cos(a) * 0.15));
            }
            if (t < 10) ringOut(l, main, pc, 0.5, 30, 0.3, 0.9);
        }));
    }

    /**
     * The aura that travels with you whenever your zanpakuto is released (every spirit, Shikai and Bankai).
     * Same shape for everyone - a helix of the spirit's own particle rising around you, plus a glow on the blade -
     * denser and wider in Bankai. Called every 2 ticks.
     */
    public static void releaseAura(ServerPlayer p, Spirit s, boolean bankai) {
        ServerLevel l = p.serverLevel();
        ParticleOptions main = ModParticles.of(s, bankai);
        Vec3 c = p.position();
        double t = p.tickCount;
        int strands = bankai ? 3 : 2;
        double r = bankai ? 0.95 : 0.7;
        double height = bankai ? 2.2 : 1.8;
        for (int k = 0; k < strands; k++) {
            double a = t * 0.22 + k * (Math.PI * 2 / strands);
            double y = ((t * 0.035 + (double) k / strands) % 1.0) * height;
            fly(l, main, c.add(Math.cos(a) * r, y + 0.1, Math.sin(a) * r), new Vec3(0, 0.02, 0));
        }
        // the blade itself glows with its spirit
        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z).normalize();
        Vec3 hand = c.add(0, 0.95, 0).add(rightOf(flat).scale(0.4)).add(flat.scale(0.35));
        dot(l, main, hand.add(jit(l, 0.12)));
        if (bankai && p.tickCount % 4 == 0) {
            // a faint ring at your feet in Bankai
            double a = t * 0.15;
            for (int i = 0; i < 4; i++) {
                double b = a + i * Math.PI / 2;
                dot(l, main, c.add(Math.cos(b) * 1.3, 0.05, Math.sin(b) * 1.3));
            }
        }
    }

    public static void impactFlash(ServerLevel l, Vec3 at) {
        dot(l, ParticleTypes.FLASH, at);
    }
}
