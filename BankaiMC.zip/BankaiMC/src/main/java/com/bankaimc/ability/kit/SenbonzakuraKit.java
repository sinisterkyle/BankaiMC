package com.bankaimc.ability.kit;

import com.bankaimc.ModParticles;
import com.bankaimc.Targeting;
import com.bankaimc.ability.PlayerState;
import com.bankaimc.ability.SpiritKit;
import com.bankaimc.task.TaskManager;
import com.bankaimc.task.TimedTask;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import static com.bankaimc.ability.Fx.*;

/**
 * Senbonzakura - a thousand blades too small to see, controlled like petals.
 * Shikai:  V = Petal Arrow (stream of blades that follows your aim) | Sneak+V = Petal Shield (blocks projectiles and blows)
 * Bankai:  V = Kageyoshi (vortex of a billion blades) | Sneak+V = Senkei, then Gokei (a cage of blade-walls that collapses on everything inside)
 * Trait (Bankai): the petals guard you - 30% of incoming attacks are deflected.
 */
public class SenbonzakuraKit implements SpiritKit {
    private static final String SHIELD = "petal_shield";

    @Override
    public int shikai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        sound(p, SoundEvents.CHERRY_LEAVES_BREAK, 2.0f, 0.6f);
        Vec3 tip0 = p.getEyePosition().add(p.getLookAngle().scale(1.2)).subtract(0, 0.4, 0);
        stream(l, ModParticles.SAKURA_PETAL.get(), tip0, tip0.add(p.getLookAngle().scale(3)), 30, 0.35, 0.3);
        TaskManager.add(new TimedTask(p, 60, t -> {
            Vec3 look = p.getLookAngle();
            Vec3 eye = p.getEyePosition();
            Vec3 start = eye.add(look.scale(0.9)).subtract(0, 0.25, 0);
            Vec3 tip = lookPoint(p, Math.min(24, 4 + t * 3.0));
            double len = start.distanceTo(tip);
            int count = (int) Math.min(45, 4 + len * 2);
            for (int i = 0; i < count; i++) {
                Vec3 at = start.add(look.scale(l.random.nextDouble() * len)).add(jit(l, 0.15));
                fly(l, ModParticles.SAKURA_PETAL.get(), at, look.scale(0.7 + l.random.nextDouble() * 0.5));
            }
            Vec3 right = rightOf(look);
            Vec3 up = right.cross(look).normalize();
            for (int k = 1; k <= 5; k++) {
                Vec3 back = tip.subtract(look.scale(k * 0.18));
                for (Vec3 side : new Vec3[]{right, right.scale(-1), up, up.scale(-1)}) {
                    fly(l, ModParticles.SAKURA_PETAL.get(), back.add(side.scale(k * 0.12)), look.scale(0.15));
                }
            }
            if (t % 3 == 0) l.sendParticles(ParticleTypes.CHERRY_LEAVES, tip.x, tip.y, tip.z, 3, 0.3, 0.3, 0.3, 0.02);
            if (t % 4 == 0) {
                for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, new AABB(start, tip).inflate(1.5), e -> Targeting.valid(p, e))) {
                    if (distToSegment(chest(e), start, tip) < 1.5) {
                        damage(p, e, 2.5f);
                        burst(l, ModParticles.SAKURA_PETAL.get(), chest(e), 8, 0.25);
                    }
                }
            }
            if (t % 12 == 0) sound(p, SoundEvents.CHERRY_LEAVES_BREAK, 1.0f, 1.4f);
        }));
        return 120;
    }

    /** Petal Shield: a dome of blades for 4s. Arrows and fireballs are shredded; melee is mostly deflected. */
    @Override
    public int shikaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        PlayerState.setFor(p, SHIELD, 80);
        sound(p, SoundEvents.CHERRY_LEAVES_PLACE, 2.0f, 0.5f);
        actionBar(p, "Petal Shield", 0xFF8FBF);
        TaskManager.add(new TimedTask(p, 80, t -> {
            Vec3 c = p.position().add(0, 1, 0);
            for (int i = 0; i < 22; i++) {
                Vec3 dir = randomUnit(l.random);
                if (dir.y < -0.3) dir = new Vec3(dir.x, -dir.y, dir.z);
                Vec3 at = c.add(dir.scale(2.2));
                Vec3 tangent = dir.cross(new Vec3(0, 1, 0)).scale(0.25);
                fly(l, ModParticles.SAKURA_PETAL.get(), at, tangent);
            }
            for (Projectile pr : l.getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(3.2),
                    pr -> pr.getOwner() != p && pr.isAlive())) {
                burst(l, ModParticles.SAKURA_PETAL.get(), pr.position(), 12, 0.2);
                pr.discard();
            }
        }));
        return 300;
    }

    @Override
    public int bankai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        sound(p, SoundEvents.CHERRY_LEAVES_BREAK, 2.0f, 0.4f);
        actionBar(p, "A thousand blades... scatter.", 0xFF4F9A);
        TaskManager.add(new TimedTask(p, 120, t -> {
            Vec3 c = p.position();
            for (int i = 0; i < 40; i++) {
                double a = l.random.nextDouble() * Math.PI * 2;
                double r = 2.5 + l.random.nextDouble() * 9.5;
                double spd = 0.9 - r * 0.04;
                fly(l, ModParticles.SAKURA_PETAL.get(), c.add(Math.cos(a) * r, l.random.nextDouble() * 4, Math.sin(a) * r),
                        new Vec3(-Math.sin(a) * spd, 0.03, Math.cos(a) * spd));
            }
            l.sendParticles(ParticleTypes.CHERRY_LEAVES, c.x, c.y + 2, c.z, 4, 6, 1.5, 6, 0.02);
            if (t % 4 == 0) {
                int streams = 0;
                for (LivingEntity e : Targeting.around(p, c, 12)) {
                    damage(p, e, bk(3));
                    if (streams++ < 5) stream(l, ModParticles.SAKURA_PETAL.get(), chest(p), chest(e), 12, 0.9, 0.2);
                }
            }
        }));
        return 300;
    }

    /**
     * Senkei: a ring of a thousand blade-walls (radius 10) for 8s. Nothing inside can leave, and you get stronger.
     * When it ends - Gokei: every blade collapses inward onto everything trapped inside.
     */
    @Override
    public int bankaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        double r = 10;
        int walls = 48;
        sound(p, SoundEvents.CHERRY_LEAVES_PLACE, 2.0f, 0.4f);
        sound(p, SoundEvents.BEACON_ACTIVATE, 1.0f, 1.6f);
        actionBar(p, "Senkei - Senbonzakura Kageyoshi", 0xFF4F9A);
        TaskManager.add(new TimedTask(p, 170, t -> {
            if (t < 150) {
                double rise = Math.min(6, t * 0.4);
                for (int i = t % 3; i < walls; i += 3) {       // draw a third of the walls each tick
                    double a = i * Math.PI * 2 / walls;
                    Vec3 base = c.add(Math.cos(a) * r, 0, Math.sin(a) * r);
                    for (double y = 0; y <= rise; y += 0.6) dot(l, ModParticles.SAKURA_PETAL.get(), base.add(0, y, 0));
                }
                if (t % 2 == 0) Fx_bladeTop(l, c, r, rise);
                p.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.DAMAGE_BOOST, 20, 2, true, false, true));
                for (LivingEntity e : Targeting.around(p, c, r + 1.5)) {
                    double d = Math.sqrt(Math.pow(e.getX() - c.x, 2) + Math.pow(e.getZ() - c.z, 2));
                    if (d > r - 1.2) {
                        // trapped: the walls throw them back inside and cut them
                        Vec3 in = new Vec3(c.x - e.getX(), 0, c.z - e.getZ()).normalize().scale(0.8);
                        e.setDeltaMovement(in.x, 0.2, in.z);
                        e.hurtMarked = true;
                        if (t % 5 == 0) damage(p, e, bk(2));
                    }
                }
                if (t % 20 == 0) for (LivingEntity e : Targeting.around(p, c, r)) damage(p, e, bk(1.5f));
            } else if (t < 168) {
                // Gokei: everything collapses inward
                int k = t - 150;
                double rr = r * (1 - k / 18.0);
                for (int i = 0; i < 70; i++) {
                    double a = l.random.nextDouble() * Math.PI * 2;
                    Vec3 from = c.add(Math.cos(a) * rr, l.random.nextDouble() * 6, Math.sin(a) * rr);
                    fly(l, ModParticles.SAKURA_PETAL.get(), from, c.add(0, 1, 0).subtract(from).scale(0.2));
                }
                if (k == 0) actionBar(p, "Gokei", 0xFF4F9A);
            } else if (t == 168) {
                burst(l, ModParticles.SAKURA_PETAL.get(), c.add(0, 1, 0), 150, 0.9);
                soundAt(l, c, SoundEvents.GENERIC_EXPLODE, 1.5f, 1.2f);
                for (LivingEntity e : Targeting.around(p, c, r + 1)) {
                    damage(p, e, bk(40));
                    burst(l, ModParticles.SAKURA_PETAL.get(), chest(e), 30, 0.4);
                }
            }
        }));
        return 700;
    }

    private static void Fx_bladeTop(ServerLevel l, Vec3 c, double r, double h) {
        ring(l, ParticleTypes.CHERRY_LEAVES, c, r, 24, h);
    }

    @Override
    public void passives(ServerPlayer p, ItemStack w, boolean bankai) {
        buff(p, MobEffects.MOVEMENT_SPEED, 0);
        buff(p, MobEffects.DAMAGE_RESISTANCE, bankai ? 2 : 0);
    }

    @Override
    public void aura(ServerPlayer p, ItemStack w) {
        vortex(p.serverLevel(), ModParticles.SAKURA_PETAL.get(), p.position().add(0, 0.4, 0), 1.2, 2.2, 1.8, 10, 0.25);
    }

    /** Petal guard: shield blocks 80%, Bankai always deflects 30% of attacks. */
    @Override
    public void onAttacked(ServerPlayer p, ItemStack w, boolean bankai, LivingAttackEvent event) {
        if (event.getSource().getEntity() == null) return;
        float chance = PlayerState.active(p, SHIELD) ? 0.8f : (bankai ? 0.3f : 0f);
        if (chance > 0 && p.getRandom().nextFloat() < chance) {
            event.setCanceled(true);
            Vec3 from = event.getSource().getSourcePosition();
            Vec3 at = from != null ? chest(p).add(from.subtract(chest(p)).normalize().scale(0.9)) : chest(p);
            burst(p.serverLevel(), ModParticles.SAKURA_PETAL.get(), at, 18, 0.3);
            sound(p, SoundEvents.CHERRY_LEAVES_HIT, 1.2f, 1.5f);
        }
    }
}
