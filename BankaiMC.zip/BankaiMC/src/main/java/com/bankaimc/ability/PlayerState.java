package com.bankaimc.ability;

import net.minecraft.server.level.ServerPlayer;

/** Short timed states on a player (e.g. "flame armor active until tick X"). Not saved across restarts on purpose. */
public final class PlayerState {
    private PlayerState() {}

    public static void setFor(ServerPlayer p, String key, int ticks) {
        p.getPersistentData().putLong("bankaimc_" + key, p.level().getGameTime() + ticks);
    }

    public static boolean active(ServerPlayer p, String key) {
        return p.level().getGameTime() < p.getPersistentData().getLong("bankaimc_" + key);
    }

    public static void clear(ServerPlayer p, String key) {
        p.getPersistentData().remove("bankaimc_" + key);
    }

    public static boolean flag(ServerPlayer p, String key) {
        return p.getPersistentData().getBoolean("bankaimc_" + key);
    }

    public static void setFlag(ServerPlayer p, String key, boolean v) {
        if (v) p.getPersistentData().putBoolean("bankaimc_" + key, true);
        else p.getPersistentData().remove("bankaimc_" + key);
    }
}
