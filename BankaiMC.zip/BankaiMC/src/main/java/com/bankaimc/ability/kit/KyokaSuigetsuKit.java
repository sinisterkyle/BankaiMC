package com.bankaimc.ability.kit;

import com.bankaimc.ModParticles;
import com.bankaimc.Targeting;
import com.bankaimc.ability.Hypnosis;
import com.bankaimc.ability.SpiritKit;
import com.bankaimc.task.TaskManager;
import com.bankaimc.task.TimedTask;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import java.util.ArrayList;
import java.util.List;

import static com.bankaimc.ability.Fx.*;

/**
 * Kyoka Suigetsu - complete control of the senses.
 * Shikai:  V = Mirror Flower (you vanish; every mob nearby sees YOU in each other and they fight) | Sneak+V = Kurohitsugi (Black Coffin)
 * Bankai:  V = Complete Hypnosis (everything within 20 blocks frozen in the illusion)
 *          Sneak+V = Shatter (end every illusion you've cast right now, for 1.5x the damage)
 * Trait: "you were never there" - attacks sometimes hit an illusion and you reappear behind the attacker (10% Shikai, 30% Bankai).
 */
public class KyokaSuigetsuKit implements SpiritKit {

    @Override
    public int shikai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        sound(p, SoundEvents.ILLUSIONER_CAST_SPELL, 1.5f, 0.8f);
        sound(p, SoundEvents.GLASS_BREAK, 1.0f, 1.4f);
        effect(p, MobEffects.INVISIBILITY, 200, 0);
        burst(l, ModParticles.MIRROR_SHARD.get(), chest(p), 70, 0.45);
        List<LivingEntity> victims = new ArrayList<>(Targeting.around(p, p.position(), 24));
        int turned = 0;
        for (LivingEntity e : victims) {
            effect(e, MobEffects.CONFUSION, 160, 0);
            burst(l, ModParticles.MIRROR_SHARD.get(), chest(e), 10, 0.15);
            if (e instanceof Mob m && victims.size() > 1) {
                Hypnosis.charm(m, p, 200);
                turned++;
            } else {
                effect(e, MobEffects.BLINDNESS, 100, 0);
            }
        }
        actionBar(p, turned > 0 ? "They see you in each other. (" + turned + " turned)" : "They see only what you allow them to see.", 0xB57BFF);
        return 400;
    }

    /** Kurohitsugi: a black coffin closes around the target you look at, then pierces it. */
    @Override
    public int shikaiAlt(ServerPlayer p, ItemStack w) {
        LivingEntity t = lookTarget(p, 24);
        if (t == null) {
            actionBar(p, "Kurohitsugi - look at an enemy within 24 blocks.", 0xB57BFF);
            return 0;
        }
        ServerLevel l = p.serverLevel();
        sound(p, SoundEvents.ILLUSIONER_PREPARE_BLINDNESS, 1.5f, 0.6f);
        actionBar(p, "Hado #90: Kurohitsugi", 0xB57BFF);
        Hypnosis.apply(t, 40, false, null, 0);
        ParticleOptions black = dust(0.03f, 0.02f, 0.05f, 2.2f);
        ParticleOptions violet = dust(0.45f, 0.1f, 0.8f, 1.4f);
        TaskManager.add(new TimedTask(p, 34, k -> {
            if (!t.isAlive()) return;
            double hw = t.getBbWidth() * 0.5 + 0.7;
            double h = t.getBbHeight() + 0.8;
            Vec3 b = t.position().subtract(0, 0.2, 0);
            double grow = Math.min(1, k / 14.0);   // the coffin's walls grow in
            Vec3[] corners = {
                    b.add(-hw, 0, -hw), b.add(hw, 0, -hw), b.add(hw, 0, hw), b.add(-hw, 0, hw),
                    b.add(-hw, h, -hw), b.add(hw, h, -hw), b.add(hw, h, hw), b.add(-hw, h, hw)};
            int[][] edges = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
            if (k % 2 == 0) {
                for (int[] e : edges) {
                    Vec3 a = corners[e[0]];
                    Vec3 to = a.add(corners[e[1]].subtract(a).scale(grow));
                    line(l, black, a, to, 0.25);
                }
                l.sendParticles(violet, b.x, b.y + h / 2, b.z, 6, hw, h / 2, hw, 0);
            }
            if (k == 30) {
                soundAt(l, chest(t), SoundEvents.WITHER_BREAK_BLOCK, 1.0f, 0.8f);
                for (int i = 0; i < 16; i++) {  // spears of darkness through the coffin
                    Vec3 from = chest(t).add(randomUnit(l.random).scale(2.5));
                    line(l, black, from, chest(t), 0.2);
                }
                burst(l, ModParticles.MIRROR_SHARD.get(), chest(t), 30, 0.4);
                damage(p, t, 32);
                effect(t, MobEffects.WITHER, 100, 1);
            }
        }));
        return 300;
    }

    @Override
    public int bankai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        double r = 20;
        sound(p, SoundEvents.ILLUSIONER_CAST_SPELL, 2.0f, 0.5f);
        sound(p, SoundEvents.WARDEN_SONIC_BOOM, 1.0f, 0.5f);
        List<LivingEntity> targets = Targeting.around(p, c, r);
        for (LivingEntity e : targets) {
            damage(p, e, bk(25));
            if (e.isAlive()) Hypnosis.apply(e, 200, false, p, bk(30));
            implode(l, ModParticles.MIRROR_SHARD.get(), chest(e), 14, 2.2);
        }
        TaskManager.add(new TimedTask(p, 24, t -> {
            double rr = (t + 1) * (r / 24.0);
            ringOut(l, ModParticles.MIRROR_SHARD.get(), c, rr, 60, 0.3, 0.15);
            ringOut(l, ModParticles.MIRROR_SHARD.get(), c, rr, 30, 1.6, 0.15);
            if (t % 3 == 0) l.sendParticles(ParticleTypes.END_ROD, c.x, c.y + 1, c.z, 6, rr * 0.5, 0.5, rr * 0.5, 0.0);
        }));
        actionBar(p, "Complete Hypnosis: " + targets.size() + " enemies are already in your illusion.", 0xB57BFF);
        return 600;
    }

    /** Shatter: every illusion you are holding breaks at once. */
    @Override
    public int bankaiAlt(ServerPlayer p, ItemStack w) {
        int n = Hypnosis.shatterAll(p, 48, 1.5f);
        if (n == 0) {
            actionBar(p, "No one is caught in your illusion.", 0x888888);
            return 0;
        }
        sound(p, SoundEvents.GLASS_BREAK, 2.0f, 0.5f);
        sound(p, SoundEvents.ILLUSIONER_MIRROR_MOVE, 2.0f, 0.6f);
        actionBar(p, "Shatter. (" + n + ")", 0xB57BFF);
        return 160;
    }

    @Override
    public void passives(ServerPlayer p, ItemStack w, boolean bankai) {
        buff(p, MobEffects.NIGHT_VISION, 0);
        buff(p, MobEffects.DAMAGE_BOOST, bankai ? 2 : 0);
        if (bankai) buff(p, MobEffects.DAMAGE_RESISTANCE, 1);
    }

    @Override
    public void aura(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        double a0 = p.tickCount * 0.15;
        for (int i = 0; i < 5; i++) {
            double a = a0 + i * (Math.PI * 2 / 5);
            fly(l, ModParticles.MIRROR_SHARD.get(), c.add(Math.cos(a) * 1.1, 1.0 + Math.sin(a0 + i) * 0.4, Math.sin(a) * 1.1),
                    new Vec3(-Math.sin(a) * 0.1, 0, Math.cos(a) * 0.1));
        }
    }

    /** "You were never there." */
    @Override
    public void onAttacked(ServerPlayer p, ItemStack w, boolean bankai, LivingAttackEvent event) {
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker) || attacker == p) return;
        if (p.getRandom().nextFloat() >= (bankai ? 0.3f : 0.1f)) return;
        event.setCanceled(true);
        ServerLevel l = p.serverLevel();
        burst(l, ModParticles.MIRROR_SHARD.get(), chest(p), 30, 0.35);
        if (attacker.distanceToSqr(p) < 16 * 16) {
            Vec3 behind = attacker.position().subtract(Vec3.directionFromRotation(0, attacker.getYRot()).scale(1.6));
            if (!solid(l, behind) && !solid(l, behind.add(0, 1, 0))) {
                p.teleportTo(l, behind.x, behind.y, behind.z, attacker.getYRot(), 0);
                burst(l, ModParticles.MIRROR_SHARD.get(), chest(p), 15, 0.2);
            }
        }
        sound(p, SoundEvents.ILLUSIONER_MIRROR_MOVE, 1.0f, 1.0f);
        actionBar(p, "...you were never there.", 0xB57BFF);
    }
}
