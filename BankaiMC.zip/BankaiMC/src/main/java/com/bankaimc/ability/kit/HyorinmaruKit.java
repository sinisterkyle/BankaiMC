package com.bankaimc.ability.kit;

import com.bankaimc.Config;
import com.bankaimc.ModParticles;
import com.bankaimc.Progression;
import com.bankaimc.Spirit;
import com.bankaimc.ZanpakutoData;
import com.bankaimc.Targeting;
import com.bankaimc.ability.Hypnosis;
import com.bankaimc.ability.PlayerState;
import com.bankaimc.ability.SpiritKit;
import com.bankaimc.task.TaskManager;
import com.bankaimc.task.TimedTask;
import com.bankaimc.task.WaveTask;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingHurtEvent;


import static com.bankaimc.ability.Fx.*;

/**
 * Hyorinmaru - everything it touches freezes.
 * Trait: sword hits stack FROST on enemies; at 3 stacks they freeze solid.
 * Shikai:  V = Ice Dragon (flies where you aim, freezes what it bites) | Sneak+V = Ryusenka (impale & encase one target in ice)
 * Bankai:  ice wings = real FLIGHT for the first 10s (config), no fall damage
 *          V = Hyoten Hyakkaso (snowfall freezes the battlefield) | Sneak+V = Sennen Hyoro (ice pillars crush a target)
 */
public class HyorinmaruKit implements SpiritKit {
    public static final String FLIGHT = "hyorinmaru_flight";
    private static final String FROST = "bankaimc_frost_stacks";
    private static final String FROST_TIME = "bankaimc_frost_time";

    static void iceFlower(ServerLevel l, Vec3 c) {
        for (int k = 0; k < 6; k++) {
            double a = k * Math.PI / 3;
            Vec3 d = new Vec3(Math.cos(a), 0.35, Math.sin(a));
            for (int j = 0; j < 4; j++) fly(l, ModParticles.ICE_SHARD.get(), c, d.scale(0.12 + j * 0.06));
        }
        for (int j = 0; j < 4; j++) fly(l, ModParticles.ICE_SHARD.get(), c, new Vec3(0, 0.15 + j * 0.07, 0));
    }

    @Override
    public int shikai(ServerPlayer p, ItemStack w) {
        sound(p, SoundEvents.PLAYER_HURT_FREEZE, 1.5f, 0.6f);
        sound(p, SoundEvents.ENDER_DRAGON_GROWL, 0.5f, 1.8f);
        WaveTask.Visual dragon = (l, pos, dir, right, hw, step) -> {
            Vec3 up = right.cross(dir).normalize();
            l.sendParticles(ModParticles.ICE_SHARD.get(), pos.x, pos.y, pos.z, 4, 0.25, 0.25, 0.25, 0.02);
            for (int k = 0; k < 2; k++) {
                double a = step * 0.55 + k * Math.PI;
                Vec3 off = right.scale(Math.cos(a) * 0.7).add(up.scale(Math.sin(a) * 0.7));
                fly(l, ModParticles.ICE_SHARD.get(), pos.add(off), dir.scale(-0.08));
            }
            if (step % 2 == 0) l.sendParticles(ParticleTypes.SNOWFLAKE, pos.x, pos.y, pos.z, 2, 0.3, 0.3, 0.3, 0.01);
        };
        TaskManager.add(new WaveTask(p, 1.4, 24, 1.6, 12, dragon, ModParticles.ICE_SHARD.get(), e -> {
            Hypnosis.apply(e, 50, true, p, 0);
            iceFlower(p.serverLevel(), chest(e));
        }));
        return 80;
    }

    /** Ryusenka: impale the target you're looking at and seal it in an ice flower. */
    @Override
    public int shikaiAlt(ServerPlayer p, ItemStack w) {
        LivingEntity t = lookTarget(p, 10);
        if (t == null) {
            actionBar(p, "Ryusenka - look at an enemy within 10 blocks.", 0x8FE3FF);
            return 0;
        }
        ServerLevel l = p.serverLevel();
        stream(l, ModParticles.ICE_SHARD.get(), chest(p), chest(t), 25, 0.8, 0.1);
        damage(p, t, 16);
        Hypnosis.apply(t, 80, true, p, 8);
        Vec3 base = t.position();
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3;
            column(l, ModParticles.ICE_SHARD.get(), base.add(Math.cos(a) * 0.6, 0, Math.sin(a) * 0.6), t.getBbHeight() + 0.6, 0.3, 0.0);
        }
        iceFlower(l, chest(t).add(0, 0.6, 0));
        soundAt(l, chest(t), SoundEvents.GLASS_PLACE, 1.5f, 0.6f);
        sound(p, SoundEvents.TRIDENT_THROW, 1.2f, 1.4f);
        return 120;
    }

    @Override
    public int bankai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        double r = 14;
        sound(p, SoundEvents.AMETHYST_BLOCK_CHIME, 2.0f, 0.5f);
        actionBar(p, "Hyoten Hyakkaso - a hundred flowers of ice", 0xBFF4FF);
        TaskManager.add(new TimedTask(p, 100, t -> {
            for (int i = 0; i < 16; i++) {
                double x = c.x + (l.random.nextDouble() * 2 - 1) * r;
                double z = c.z + (l.random.nextDouble() * 2 - 1) * r;
                fly(l, ModParticles.ICE_SHARD.get(), new Vec3(x, c.y + 7 + l.random.nextDouble() * 3, z),
                        new Vec3(0, -0.4 - l.random.nextDouble() * 0.3, 0));
            }
            l.sendParticles(ParticleTypes.SNOWFLAKE, c.x, c.y + 6, c.z, 10, r * 0.6, 1.5, r * 0.6, 0.02);
            if (t % 10 == 0) {
                ringOut(l, ModParticles.ICE_SHARD.get(), c, r, 50, 0.2, 0.0);
                for (LivingEntity e : Targeting.around(p, c, r)) {
                    if (!Hypnosis.isFrozen(e)) {
                        Hypnosis.apply(e, 120, true, p, bk(15));
                        iceFlower(l, chest(e));
                    }
                    damage(p, e, bk(5));
                }
                sound(p, SoundEvents.GLASS_BREAK, 0.6f, 1.6f);
            }
        }));
        return 400;
    }

    /** Sennen Hyoro: pillars of ice rise around the target, then slam shut. */
    @Override
    public int bankaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        LivingEntity target = lookTarget(p, 28);
        Vec3 c = target != null ? target.position() : lookPoint(p, 28);
        sound(p, SoundEvents.PLAYER_HURT_FREEZE, 2.0f, 0.4f);
        actionBar(p, "Sennen Hyoro - the thousand-year ice prison", 0xBFF4FF);
        int pillars = 10;
        TaskManager.add(new TimedTask(p, 45, t -> {
            double radius;
            double height;
            if (t < 20) { radius = 5; height = t * 0.3; }            // rise
            else if (t < 35) { radius = 5 - (t - 20) * 0.3; height = 6; } // close in
            else { radius = 0.5; height = 6; }
            for (int i = 0; i < pillars; i++) {
                double a = i * Math.PI * 2 / pillars;
                Vec3 base = c.add(Math.cos(a) * radius, 0, Math.sin(a) * radius);
                for (double y = 0; y <= height; y += 0.5) dot(l, ModParticles.ICE_SHARD.get(), base.add(0, y, 0));
            }
            if (t == 0) {
                for (LivingEntity e : Targeting.around(p, c, 5)) Hypnosis.apply(e, 45, true, p, 0); // held in place
            }
            if (t == 35) {
                soundAt(l, c, SoundEvents.GLASS_BREAK, 2.0f, 0.4f);
                soundAt(l, c, SoundEvents.GENERIC_EXPLODE, 1.0f, 1.4f);
                burst(l, ModParticles.ICE_SHARD.get(), c.add(0, 2, 0), 120, 0.7);
                for (LivingEntity e : Targeting.around(p, c.add(0, 1, 0), 4)) {
                    damage(p, e, bk(40));
                    if (e.isAlive()) Hypnosis.apply(e, 100, true, p, bk(10));
                }
            }
        }));
        return 300;
    }

    @Override
    public void passives(ServerPlayer p, ItemStack w, boolean bankai) {
        buff(p, MobEffects.DAMAGE_RESISTANCE, bankai ? 1 : 0);
        if (bankai) { buff(p, MobEffects.MOVEMENT_SPEED, 0); buff(p, MobEffects.DAMAGE_BOOST, 0); }
        if (bankai) p.fallDistance = 0;
        // ice wings: real flight, but only for the first few seconds of Bankai
        if (bankai && wingsActive(p, w) && !p.isCreative() && !p.isSpectator() && !p.getAbilities().mayfly) {
            p.getAbilities().mayfly = true;
            p.onUpdateAbilities();
            PlayerState.setFlag(p, FLIGHT, true);
        }
    }

    public static final String WINGS_END = "WingsEnd";

    private static boolean wingsActive(ServerPlayer p, ItemStack w) {
        return p.level().getGameTime() < ZanpakutoData.getLong(w, WINGS_END);
    }

    @Override
    public void onRelease(ServerPlayer p, ItemStack w, boolean bankai) {
        if (bankai) {
            int secs = Config.HYORINMARU_FLIGHT_SECONDS.get();
            ZanpakutoData.setLong(w, WINGS_END, p.level().getGameTime() + secs * 20L);
            if (secs > 0) actionBar(p, "Ice wings: " + secs + "s of flight (double-tap jump)", 0xBFF4FF);
        }
    }

    /**
     * Runs EVERY tick for every player. If we gave them flight and they are no longer holding a Hyorinmaru
     * in Bankai with wing time left, flight is taken away immediately. Swapping items, sealing, Bankai ending,
     * logging out or dying can't keep it.
     */
    public static void enforceFlight(ServerPlayer p) {
        if (!PlayerState.flag(p, FLIGHT)) return;
        ItemStack w = p.getMainHandItem();
        long now = p.level().getGameTime();
        boolean ok = ZanpakutoData.hasData(w)
                && ZanpakutoData.getSpirit(w) == Spirit.HYORINMARU
                && ZanpakutoData.getRelease(w) == ZanpakutoData.BANKAI
                && now < ZanpakutoData.getLong(w, WINGS_END)
                && (Progression.isTestMode(p) || now < ZanpakutoData.getReleaseEnd(w));
        if (!ok) {
            boolean wasFlying = p.getAbilities().flying;
            revokeFlight(p);
            if (wasFlying) actionBar(p, "Your ice wings shatter.", 0xBFF4FF);
        }
    }

    public static void revokeFlight(ServerPlayer p) {
        if (!PlayerState.flag(p, FLIGHT)) return;
        PlayerState.setFlag(p, FLIGHT, false);
        if (p.isCreative() || p.isSpectator()) return;
        p.getAbilities().mayfly = false;
        p.getAbilities().flying = false;
        p.onUpdateAbilities();
        p.fallDistance = 0;
        p.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.SLOW_FALLING, 100, 0));
    }

    @Override
    public void onSeal(ServerPlayer p, ItemStack w) {
        revokeFlight(p);
    }

    @Override
    public void aura(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        Vec3 look = p.getLookAngle();
        Vec3 back = new Vec3(-look.x, 0, -look.z).normalize();
        Vec3 side = back.cross(new Vec3(0, 1, 0)).normalize();
        double flap = p.getAbilities().flying ? Math.sin(p.tickCount * 0.6) * 0.25 : 0;
        for (int sgn = -1; sgn <= 1 && wingsActive(p, w); sgn += 2) {
            for (int i = 0; i < 9; i++) {
                Vec3 at = c.add(back.scale(0.35 + i * 0.05)).add(side.scale(sgn * (0.3 + i * 0.24)))
                        .add(0, 1.35 + i * (0.12 + flap * 0.1) - i * i * 0.025, 0);
                dot(l, ModParticles.ICE_SHARD.get(), at);
            }
        }
        // a dragon's tail of ice trailing behind
        for (int i = 0; i < 5; i++) dot(l, ModParticles.ICE_SHARD.get(), c.add(back.scale(0.4 + i * 0.25)).add(0, 0.9 - i * 0.15, 0));
        l.sendParticles(ParticleTypes.SNOWFLAKE, c.x, c.y + 1.2, c.z, 4, 1.2, 0.6, 1.2, 0.01);
        for (LivingEntity e : Targeting.around(p, c, 4)) effect(e, MobEffects.MOVEMENT_SLOWDOWN, 30, 1);
    }

    /** Frost stacks: 3 hits within 5s freeze the target solid. Bankai freezes in 2. */
    @Override
    public void onMeleeHit(ServerPlayer p, ItemStack w, boolean bankai, LivingEntity target, LivingHurtEvent event) {
        CompoundTag d = target.getPersistentData();
        long now = p.level().getGameTime();
        int stacks = now - d.getLong(FROST_TIME) > 100 ? 0 : d.getInt(FROST);
        stacks++;
        d.putLong(FROST_TIME, now);
        ServerLevel l = p.serverLevel();
        target.setTicksFrozen(Math.min(target.getTicksRequiredToFreeze(), target.getTicksFrozen() + 50));
        burst(l, ModParticles.ICE_SHARD.get(), chest(target), 4 + stacks * 3, 0.15);
        if (stacks >= (bankai ? 2 : 3)) {
            d.putInt(FROST, 0);
            Hypnosis.apply(target, bankai ? 80 : 50, true, p, bankai ? bk(4) : 6);
            iceFlower(l, chest(target));
            soundAt(l, chest(target), SoundEvents.GLASS_PLACE, 1.2f, 0.8f);
        } else {
            d.putInt(FROST, stacks);
        }
    }

    @Override
    public void onHurt(ServerPlayer p, ItemStack w, boolean bankai, LivingHurtEvent event) {
        if (bankai && event.getSource().is(net.minecraft.tags.DamageTypeTags.IS_FALL)) event.setCanceled(true);
    }

}
