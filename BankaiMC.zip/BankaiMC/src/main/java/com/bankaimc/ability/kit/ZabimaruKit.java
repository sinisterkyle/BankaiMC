package com.bankaimc.ability.kit;

import com.bankaimc.ModParticles;
import com.bankaimc.Targeting;
import com.bankaimc.ability.SpiritKit;
import com.bankaimc.entity.SerpentSkullEntity;
import com.bankaimc.task.TaskManager;
import com.bankaimc.task.TimedTask;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static com.bankaimc.ability.Fx.*;

/**
 * Zabimaru (Abarai Renji) - a segmented snake-blade; in Bankai, a colossal bone serpent.
 * Shikai:  Trait: 25% of sword hits lash a second nearby enemy for 60% damage.
 *          V = Whip Blade (the blade extends 14 blocks along your aim and reels in the first enemy it catches) | Sneak+V = Higa Zekko (segments break apart and strike every enemy around)
 * Bankai:  Trait: every sword hit is followed by the snake's bite.
 *          V = Hikotsu Taiho (charge the bone cannon, then fire a blast of red reiatsu) | Sneak+V = Serpent Coil (the snake sweeps a full circle around you)
 */
public class ZabimaruKit implements SpiritKit {

    private static ParticleOptions red(float size) {
        return dust(0.85f, 0.18f, 0.15f, size);
    }

    /** One blade segment: a little cluster of bone with a red edge. */
    private static void segment(ServerLevel l, Vec3 at) {
        dot(l, ModParticles.BONE_SHARD.get(), at);
        dot(l, red(0.8f), at.add(0, 0.12, 0));
    }

    @Override
    public int shikai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        sound(p, SoundEvents.CHAIN_PLACE, 1.5f, 0.6f);
        Set<UUID> hit = new HashSet<>();
        TaskManager.add(new TimedTask(p, 16, t -> {
            double ext = t < 8 ? (t + 1) * 1.75 : (16 - t) * 1.75;  // out to 14 blocks, then back
            Vec3 look = p.getLookAngle();
            Vec3 right = rightOf(look);
            Vec3 start = p.getEyePosition().subtract(0, 0.35, 0).add(look.scale(0.8));
            Vec3 prev = start;
            for (double d = 0; d <= ext; d += 1.0) {
                double wave = Math.sin(d * 0.9 - t * 1.4) * 0.35 * (d / 14.0);  // the whip ripples
                Vec3 at = start.add(look.scale(d)).add(right.scale(wave));
                if (solid(l, at)) break;
                segment(l, at);
                prev = at;
            }
            if (t == 7 || t == 8) {
                for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, new AABB(start, prev).inflate(1.5), e -> Targeting.valid(p, e))) {
                    if (distToSegment(chest(e), start, prev) < 1.5 && hit.add(e.getUUID())) {
                        damage(p, e, 13);
                        if (hit.size() == 1) {
                            // the first one caught gets reeled in
                            Vec3 pull = p.position().subtract(e.position()).normalize().scale(1.1);
                            e.setDeltaMovement(pull.x, 0.35, pull.z);
                            e.hurtMarked = true;
                        }
                        burst(l, ModParticles.BONE_SHARD.get(), chest(e), 10, 0.25);
                        l.sendParticles(ParticleTypes.CRIT, e.getX(), e.getY() + 1, e.getZ(), 8, 0.3, 0.4, 0.3, 0.2);
                    }
                }
                if (t == 7) soundAt(l, prev, SoundEvents.PLAYER_ATTACK_CRIT, 1.2f, 0.7f);
            }
        }));
        return 50;
    }

    /** Higa Zekko: the segments fly apart into every enemy around you, then snap back. */
    @Override
    public int shikaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        List<LivingEntity> targets = Targeting.around(p, p.position(), 12).stream()
                .sorted(Comparator.comparingDouble(e -> e.distanceToSqr(p))).limit(8).toList();
        if (targets.isEmpty()) {
            actionBar(p, "Higa Zekko - no enemies within 12 blocks.", 0x888888);
            return 0;
        }
        sound(p, SoundEvents.CHAIN_BREAK, 1.5f, 0.6f);
        actionBar(p, "Higa Zekko", 0xD9473B);
        TaskManager.add(new TimedTask(p, 16, t -> {
            for (LivingEntity e : targets) {
                if (!e.isAlive()) continue;
                if (t < 6) {
                    double f = (t + 1) / 6.0;
                    Vec3 at = chest(p).add(chest(e).subtract(chest(p)).scale(f));
                    segment(l, at);
                    segment(l, at.add(jit(l, 0.3)));
                } else if (t == 6) {
                    damage(p, e, 9);
                    burst(l, ModParticles.BONE_SHARD.get(), chest(e), 12, 0.3);
                } else {
                    double f = 1 - (t - 6) / 9.0;
                    segment(l, chest(p).add(chest(e).subtract(chest(p)).scale(f)));
                }
            }
            if (t == 6) sound(p, SoundEvents.PLAYER_ATTACK_STRONG, 1.2f, 0.8f);
            if (t == 15) sound(p, SoundEvents.CHAIN_PLACE, 1.2f, 1.2f);
        }));
        return 160;
    }

    /** Hikotsu Taiho: the serpent's mouth gathers red reiatsu for a second, then fires along your aim. */
    @Override
    public int bankai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        sound(p, SoundEvents.BEACON_POWER_SELECT, 1.5f, 0.5f);
        actionBar(p, "Hikotsu Taiho", 0xD9473B);
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 22, 2, false, false));
        SerpentSkullEntity[] skull = new SerpentSkullEntity[1];
        TaskManager.add(new TimedTask(p, 26, t -> {
            Vec3 look = p.getLookAngle();
            Vec3 mouth = p.getEyePosition().add(look.scale(2.5)).add(0, 0.6, 0);
            // the serpent's skull hangs over your shoulder, jaws opening around the charge
            Vec3 skullPos = mouth.subtract(look.scale(1.3)).add(0, 0.25, 0);
            float jaw = t < 20 ? Math.min(1f, t / 12f) * 0.75f : 1f;
            if (skull[0] == null) skull[0] = SerpentSkullEntity.spawn(l, skullPos, look, 2.0f);
            if (t < 25) skull[0].steer(skullPos, look, jaw);
            else skull[0].discard();
            if (t < 20) {
                implode(l, red(1.5f), mouth, 6, 1.6 - t * 0.05);
                dot(l, ModParticles.EMBER.get(), mouth.add(jit(l, 0.2)));
                return;
            }
            if (t != 20) return;
            Vec3 end = mouth;
            for (double d = 0; d <= 40; d += 0.5) {
                Vec3 pt = mouth.add(look.scale(d));
                if (d > 1 && solid(l, pt)) break;
                end = pt;
                l.sendParticles(red(2.4f), pt.x, pt.y, pt.z, 2, 0.25, 0.25, 0.25, 0);
                if (((int) (d * 2)) % 3 == 0) l.sendParticles(ParticleTypes.FLAME, pt.x, pt.y, pt.z, 2, 0.2, 0.2, 0.2, 0.02);
            }
            l.sendParticles(ParticleTypes.EXPLOSION_EMITTER, end.x, end.y, end.z, 1, 0, 0, 0, 0);
            burst(l, red(2.0f), end, 60, 0.6);
            burst(l, ModParticles.EMBER.get(), end, 40, 0.5);
            soundAt(l, end, SoundEvents.GENERIC_EXPLODE, 1.6f, 0.8f);
            sound(p, SoundEvents.WARDEN_SONIC_BOOM, 1.2f, 1.2f);
            double len = mouth.distanceTo(end);
            for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, new AABB(mouth, end).inflate(5), e -> Targeting.valid(p, e))) {
                Vec3 mid = chest(e);
                if (distToSegment(mid, mouth, end) < 2.0) {
                    damage(p, e, bk(40));
                    e.setSecondsOnFire(6);
                } else if (mid.distanceTo(end) < 4.5) {
                    damage(p, e, bk(20));
                    e.setSecondsOnFire(6);
                }
            }
        }));
        return 300;
    }

    /** Serpent Coil: the bone snake whips a full circle around you, throwing everything back. */
    @Override
    public int bankaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        sound(p, SoundEvents.RAVAGER_ROAR, 1.2f, 1.2f);
        actionBar(p, "Serpent Coil", 0xD9473B);
        Set<UUID> hit = new HashSet<>();
        double r = 6;
        SerpentSkullEntity[] coilSkull = new SerpentSkullEntity[1];
        TaskManager.add(new TimedTask(p, 26, t -> {
            Vec3 c = p.position();
            double head = t * (Math.PI * 2 / 22);
            for (int i = 0; i < 14; i++) {
                double a = head - i * 0.22;
                double y = 1.0 + Math.sin(a * 2) * 0.5;
                Vec3 at = c.add(Math.cos(a) * r, y, Math.sin(a) * r);
                segment(l, at);
                if (i == 0) {
                    Vec3 dir = new Vec3(-Math.sin(a), 0, Math.cos(a));
                    if (coilSkull[0] == null) coilSkull[0] = SerpentSkullEntity.spawn(l, at.add(dir.scale(1.0)), dir, 2.2f);
                    if (t < 25) coilSkull[0].steer(at.add(dir.scale(1.0)), dir, 0.75f + (float) Math.sin(t * 0.5) * 0.25f);
                    else coilSkull[0].discard();
                }
            }
            Vec3 headPos = c.add(Math.cos(head) * r, 1, Math.sin(head) * r);
            for (LivingEntity e : Targeting.around(p, headPos, 2.6)) {
                if (hit.add(e.getUUID())) {
                    damage(p, e, bk(15));
                    Vec3 out = new Vec3(e.getX() - c.x, 0, e.getZ() - c.z).normalize();
                    e.setDeltaMovement(out.x * 1.4, 0.7, out.z * 1.4);
                    e.hurtMarked = true;
                    burst(l, ModParticles.BONE_SHARD.get(), chest(e), 14, 0.3);
                }
            }
            if (t % 6 == 0) soundAt(l, headPos, SoundEvents.CHAIN_HIT, 1.2f, 0.5f);
        }));
        return 200;
    }

    /**
     * Shikai: the blade splits into segments that ripple out and snap back together.
     * Bankai: a colossal bone serpent with a red mane coils up around you and roars.
     */
    @Override
    public void onRelease(ServerPlayer p, ItemStack w, boolean bankai) {
        ServerLevel l = p.serverLevel();
        if (!bankai) {
            sound(p, SoundEvents.CHAIN_BREAK, 1.2f, 0.8f);
            TaskManager.add(new TimedTask(p, 14, t -> {
                Vec3 look = p.getLookAngle();
                Vec3 start = p.getEyePosition().subtract(0, 0.35, 0).add(look.scale(0.8));
                double spread = t < 7 ? t * 0.12 : (14 - t) * 0.12;
                for (int i = 0; i < 6; i++) {
                    Vec3 at = start.add(look.scale(i * (0.35 + spread)));
                    segment(l, at.add(rightOf(look).scale(Math.sin(i + t) * spread)));
                }
                if (t == 13) sound(p, SoundEvents.CHAIN_PLACE, 1.2f, 1.4f);
            }));
            return;
        }
        sound(p, SoundEvents.RAVAGER_ROAR, 1.5f, 0.6f);
        sound(p, SoundEvents.ENDER_DRAGON_GROWL, 0.6f, 0.8f);
        SerpentSkullEntity[] riseSkull = new SerpentSkullEntity[1];
        TaskManager.add(new TimedTask(p, 40, t -> {
            Vec3 c = p.position();
            // the body spirals up around you, head leading
            int len = Math.min(24, t + 4);
            double headA = t * 0.35;
            for (int i = 0; i < len; i++) {
                double a = headA - i * 0.3;
                double y = Math.max(0, (headA - i * 0.3) * 0.5);
                if (y > 7) continue;
                segment(l, c.add(Math.cos(a) * 2.2, y, Math.sin(a) * 2.2));
            }
            double hy = Math.min(7, headA * 0.5);
            Vec3 headPos = c.add(Math.cos(headA) * 2.2, hy + 0.5, Math.sin(headA) * 2.2);
            Vec3 headDir = new Vec3(-Math.sin(headA), 0.3, Math.cos(headA)).normalize();
            Vec3 skullPos = headPos.add(headDir.scale(1.2));
            float jaw = 0.5f + (float) Math.sin(t * 0.4) * 0.5f;
            if (riseSkull[0] == null) riseSkull[0] = SerpentSkullEntity.spawn(l, skullPos, headDir, 2.0f);
            if (t < 39) riseSkull[0].steer(skullPos, headDir, t >= 28 && t <= 34 ? 1f : jaw);   // roars wide open
            else riseSkull[0].discard();
            if (t == 30) sound(p, SoundEvents.RAVAGER_ROAR, 1.5f, 0.5f);
        }));
    }

    @Override
    public void passives(ServerPlayer p, ItemStack w, boolean bankai) {
        buff(p, MobEffects.DAMAGE_BOOST, bankai ? 1 : 0);
        if (bankai) buff(p, MobEffects.DAMAGE_RESISTANCE, 0);
    }

    @Override
    public void aura(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        // the serpent coils loosely around you
        double a0 = p.tickCount * 0.12;
        for (int i = 0; i < 8; i++) {
            double a = a0 + i * 0.35;
            segment(l, c.add(Math.cos(a) * 1.4, 0.3 + i * 0.22, Math.sin(a) * 1.4));
        }
    }

    @Override
    public void onMeleeHit(ServerPlayer p, ItemStack w, boolean bankai, LivingEntity target, LivingHurtEvent event) {
        ServerLevel l = p.serverLevel();
        if (bankai) {
            // the snake's head follows up with a bite
            TaskManager.add(new TimedTask(p, 9, t -> {
                if (t == 8 && target.isAlive()) {
                    Vec3 from = chest(p).add(0, 1.5, 0);
                    line(l, ModParticles.BONE_SHARD.get(), from, chest(target), 0.5);
                    damage(p, target, bk(4));
                    burst(l, ModParticles.BONE_SHARD.get(), chest(target), 8, 0.25);
                    soundAt(l, chest(target), SoundEvents.EVOKER_FANGS_ATTACK, 0.8f, 1.2f);
                }
            }));
        } else if (p.getRandom().nextFloat() < 0.25f) {
            LivingEntity other = Targeting.around(p, target.position(), 6).stream()
                    .filter(e -> e != target).min(Comparator.comparingDouble(e -> e.distanceToSqr(target))).orElse(null);
            if (other != null) {
                line(l, ModParticles.BONE_SHARD.get(), chest(target), chest(other), 0.5);
                damage(p, other, event.getAmount() * 0.6f);
                soundAt(l, chest(other), SoundEvents.CHAIN_HIT, 1.0f, 1.0f);
            }
        }
    }
}
