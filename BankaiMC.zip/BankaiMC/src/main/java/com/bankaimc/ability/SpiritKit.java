package com.bankaimc.ability;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

/**
 * Everything one spirit can do. Ability methods return their cooldown in ticks (0 = didn't fire, no cooldown).
 * V = main ability, Sneak + V = alt ability.
 */
public interface SpiritKit {
    int shikai(ServerPlayer p, ItemStack w);

    int shikaiAlt(ServerPlayer p, ItemStack w);

    int bankai(ServerPlayer p, ItemStack w);

    int bankaiAlt(ServerPlayer p, ItemStack w);

    /** Buffs while released. Called every 10 ticks (effects last 40). */
    void passives(ServerPlayer p, ItemStack w, boolean bankai);

    /** Ambient visuals while Bankai is active. Called every 10 ticks. */
    void aura(ServerPlayer p, ItemStack w);

    /** The wielder hit something with a normal sword swing while released. */
    default void onMeleeHit(ServerPlayer p, ItemStack w, boolean bankai, LivingEntity target, LivingHurtEvent event) {}

    /** Something is about to damage the wielder (cancel the event to negate it). */
    default void onAttacked(ServerPlayer p, ItemStack w, boolean bankai, LivingAttackEvent event) {}

    /** The wielder is taking damage (amount already decided). */
    default void onHurt(ServerPlayer p, ItemStack w, boolean bankai, LivingHurtEvent event) {}

    /** Just released into Shikai or Bankai. */
    default void onRelease(ServerPlayer p, ItemStack w, boolean bankai) {}

    /** The wielder is about to die. Return true to cancel the death (you must restore health yourself). */
    default boolean onLethal(ServerPlayer p, ItemStack w, boolean bankai) { return false; }

    /** The blade was just sealed (or Bankai ended). */
    default void onSeal(ServerPlayer p, ItemStack w) {}
}
