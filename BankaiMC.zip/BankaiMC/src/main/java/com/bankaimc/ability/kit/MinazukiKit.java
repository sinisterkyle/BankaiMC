package com.bankaimc.ability.kit;

import com.bankaimc.ModParticles;
import com.bankaimc.Targeting;
import com.bankaimc.ability.Bleed;
import com.bankaimc.ability.SpiritKit;
import com.bankaimc.task.TaskManager;
import com.bankaimc.task.TimedTask;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static com.bankaimc.ability.Fx.*;

/**
 * Minazuki (Unohana Retsu) - the healer's manta ray, hiding the most bloodthirsty blade in history.
 * Shikai:  Trait: sword hits heal you for 15% of the damage.
 *          V = Manta's Embrace (the manta glides over you and your allies: big heal + cleanse) | Sneak+V = Swallow (the manta engulfs one enemy and digests it)
 * Bankai:  The blade turns to liquid blood. Trait: 35% lifesteal, and every hit adds a BLEED stack.
 *          Finishing a bleeding enemy with your sword heals you 2 hearts.
 *          V = Blood Tide (a wave of blood floods forward, heavy bleed) | Sneak+V = Hemorrhage (burst every bleed around you at once, heal from it)
 */
public class MinazukiKit implements SpiritKit {

    /** Draws a manta ray silhouette centred on c, facing angle a. */
    private static void manta(ServerLevel l, Vec3 c, double a, double scale) {
        Vec3 fwd = new Vec3(Math.cos(a), 0, Math.sin(a));
        Vec3 side = new Vec3(-Math.sin(a), 0, Math.cos(a));
        for (double u = -1; u <= 1.001; u += 0.1) {
            double wing = 1 - Math.abs(u);
            // leading edge and trailing edge of each wing
            Vec3 lead = c.add(side.scale(u * 3 * scale)).add(fwd.scale((0.2 + wing * 0.9) * scale)).add(0, Math.abs(u) * 0.4, 0);
            Vec3 trail = c.add(side.scale(u * 3 * scale)).add(fwd.scale((-0.3 - wing * 0.5) * scale)).add(0, Math.abs(u) * 0.4, 0);
            dot(l, ModParticles.HEAL_MOTE.get(), lead);
            if (((int) Math.round(u * 10)) % 2 == 0) dot(l, ModParticles.HEAL_MOTE.get(), trail);
        }
        for (double t = 0; t < 2.2; t += 0.3) dot(l, ModParticles.HEAL_MOTE.get(), c.subtract(fwd.scale((0.8 + t) * scale))); // tail
    }

    @Override
    public int shikai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        sound(p, SoundEvents.CONDUIT_ACTIVATE, 1.5f, 1.2f);
        actionBar(p, "Manta's Embrace", 0x7FD9C4);
        List<LivingEntity> allies = l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(10),
                e -> e == p || (e instanceof Player && !Targeting.valid(p, e)) || (e instanceof TamableAnimal t && t.isOwnedBy(p)));
        for (LivingEntity e : allies) {
            e.heal(8);
            cleanse(e);
            e.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 160, 1));
            burst(l, ModParticles.HEAL_MOTE.get(), chest(e), 20, 0.2);
        }
        TaskManager.add(new TimedTask(p, 40, t -> {
            double a = t * 0.16;
            Vec3 c = p.position().add(Math.cos(a) * 3, 3.2 + Math.sin(t * 0.3) * 0.3, Math.sin(a) * 3);
            if (t % 2 == 0) manta(l, c, a + Math.PI / 2, 0.8);
            fly(l, ModParticles.HEAL_MOTE.get(), c, new Vec3(0, -0.15, 0));
        }));
        return 300;
    }

    /** Swallow: the manta engulfs the enemy you look at, lifts it and digests it for 3s. */
    @Override
    public int shikaiAlt(ServerPlayer p, ItemStack w) {
        LivingEntity t = lookTarget(p, 14);
        if (t == null) {
            actionBar(p, "Swallow - look at an enemy within 14 blocks.", 0x7FD9C4);
            return 0;
        }
        ServerLevel l = p.serverLevel();
        sound(p, SoundEvents.PHANTOM_SWOOP, 1.5f, 0.6f);
        actionBar(p, "Swallow", 0x7FD9C4);
        Vec3 sky = chest(t).add(0, 5, 0);
        t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 5));
        TaskManager.add(new TimedTask(p, 70, k -> {
            if (!t.isAlive()) return;
            Vec3 c = chest(t);
            if (k < 10) {
                // the manta dives out of the sky onto its prey
                Vec3 at = sky.add(c.subtract(sky).scale(k / 10.0));
                manta(l, at, k * 0.3, 0.7);
                return;
            }
            if (k == 10) {
                t.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 40, 0));
                t.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
                burst(l, ModParticles.HEAL_MOTE.get(), c, 30, 0.3);
                soundAt(l, c, SoundEvents.GENERIC_DRINK, 1.5f, 0.4f);
            }
            for (int i = 0; i < 12; i++) dot(l, ModParticles.HEAL_MOTE.get(), c.add(randomUnit(l.random).scale(t.getBbWidth() * 0.5 + 0.9)));
            if (k % 10 == 0) {
                damage(p, t, 4);
                p.heal(2);
                stream(l, ModParticles.HEAL_MOTE.get(), c, chest(p), 6, 0.5, 0.1);
                soundAt(l, c, SoundEvents.GENERIC_EAT, 0.8f, 0.6f);
            }
        }));
        return 200;
    }

    @Override
    public int bankai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 look = new Vec3(p.getLookAngle().x, 0, p.getLookAngle().z).normalize();
        Vec3 c = p.position();
        sound(p, SoundEvents.AMBIENT_UNDERWATER_ENTER, 2.0f, 0.5f);
        sound(p, SoundEvents.GENERIC_SPLASH, 1.5f, 0.5f);
        actionBar(p, "Blood Tide", 0x8A0F1E);
        Set<UUID> hit = new HashSet<>();
        TaskManager.add(new TimedTask(p, 22, t -> {
            double r = 1 + t * 0.7;  // floods out to ~16 blocks
            for (int i = 0; i < 26; i++) {
                double a = (l.random.nextDouble() - 0.5) * 1.6;  // ~90 degree cone
                Vec3 dir = new Vec3(look.x * Math.cos(a) - look.z * Math.sin(a), 0, look.x * Math.sin(a) + look.z * Math.cos(a));
                Vec3 at = c.add(dir.scale(r)).add(0, 0.2 + l.random.nextDouble() * 1.2, 0);
                fly(l, i % 2 == 0 ? ModParticles.BLOOD_DROP.get() : dust(0.45f, 0.02f, 0.06f, 1.8f), at, dir.scale(0.3).add(0, 0.15, 0));
            }
            float healed = 0;
            for (LivingEntity e : Targeting.around(p, c, r)) {
                Vec3 to = new Vec3(e.getX() - c.x, 0, e.getZ() - c.z).normalize();
                if (to.dot(look) > 0.6 && hit.add(e.getUUID())) {
                    float before = e.getHealth();
                    damage(p, e, bk(12));
                    Bleed.apply(e, p, 4, bk(1), 160);
                    e.knockback(0.6, -look.x, -look.z);
                    healed += Math.max(0, before - e.getHealth()) * 0.25f;
                }
            }
            if (healed > 0) p.heal(healed);
        }));
        return 300;
    }

    /** Hemorrhage: every bleeding enemy near you bursts at once. You drink what spills. */
    @Override
    public int bankaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        float total = 0;
        int n = 0;
        for (LivingEntity e : Targeting.around(p, p.position(), 20)) {
            int stacks = Bleed.stacks(e);
            if (stacks <= 0) continue;
            float dmg = Bleed.consume(e) * 5;
            damage(p, e, dmg);
            burst(l, ModParticles.BLOOD_DROP.get(), chest(e), 20 + stacks * 4, 0.45);
            stream(l, ModParticles.BLOOD_DROP.get(), chest(e), chest(p), 10, 0.6, 0.15);
            total += dmg;
            n++;
        }
        if (n == 0) {
            actionBar(p, "Nothing around you is bleeding.", 0x888888);
            return 0;
        }
        p.heal(total * 0.3f);
        sound(p, SoundEvents.GENERIC_SPLASH, 2.0f, 0.4f);
        sound(p, SoundEvents.WARDEN_HEARTBEAT, 2.0f, 0.8f);
        actionBar(p, "Hemorrhage (" + n + ")", 0x8A0F1E);
        return 200;
    }

    /** Shikai: the manta takes shape from the blade and rises. Bankai: the blade melts and blood spreads at your feet. */
    @Override
    public void onRelease(ServerPlayer p, ItemStack w, boolean bankai) {
        ServerLevel l = p.serverLevel();
        if (!bankai) {
            sound(p, SoundEvents.CONDUIT_AMBIENT_SHORT, 2.0f, 1.0f);
            TaskManager.add(new TimedTask(p, 30, t -> {
                Vec3 c = p.position().add(0, 1.2 + t * 0.08, 0);
                if (t % 2 == 0) manta(l, c, p.getYRot() * Math.PI / 180 + Math.PI / 2, 0.4 + t * 0.02);
            }));
            return;
        }
        sound(p, SoundEvents.WARDEN_HEARTBEAT, 2.0f, 0.6f);
        sound(p, SoundEvents.HONEY_DRINK, 1.5f, 0.4f);
        TaskManager.add(new TimedTask(p, 40, t -> {
            Vec3 c = p.position();
            Vec3 hand = c.add(p.getLookAngle().scale(0.6)).add(0, 1.0, 0);
            for (int i = 0; i < 5; i++) fly(l, ModParticles.BLOOD_DROP.get(), hand.add(jit(l, 0.15)), new Vec3(0, -0.1, 0));
            double r = Math.min(4, t * 0.15);
            ring(l, dust(0.35f, 0.01f, 0.04f, 2.0f), c, r, 10 + (int) (r * 8), 0.05);
            if (t % 10 == 0) sound(p, SoundEvents.WARDEN_HEARTBEAT, 1.5f, 0.6f);
        }));
    }

    @Override
    public void passives(ServerPlayer p, ItemStack w, boolean bankai) {
        buff(p, MobEffects.REGENERATION, 0);
        if (bankai) {
            buff(p, MobEffects.DAMAGE_BOOST, 1);
            buff(p, MobEffects.MOVEMENT_SPEED, 0);
        } else {
            buff(p, MobEffects.DAMAGE_RESISTANCE, 0);
        }
    }

    @Override
    public void aura(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        // the blade drips; blood pools at your feet
        Vec3 hand = c.add(p.getLookAngle().scale(0.5)).add(0, 1.0, 0);
        for (int i = 0; i < 3; i++) fly(l, ModParticles.BLOOD_DROP.get(), hand.add(jit(l, 0.2)), new Vec3(0, -0.05, 0));
        ring(l, dust(0.4f, 0.02f, 0.05f, 1.5f), c, 1.2, 14, 0.05);
    }

    @Override
    public void onMeleeHit(ServerPlayer p, ItemStack w, boolean bankai, LivingEntity target, LivingHurtEvent event) {
        p.heal(event.getAmount() * (bankai ? 0.35f : 0.15f));
        ServerLevel l = p.serverLevel();
        if (bankai) {
            if (target.getHealth() - event.getAmount() <= 0 && Bleed.stacks(target) > 0) {
                p.heal(4);  // the blade drinks what it finishes
                stream(l, ModParticles.BLOOD_DROP.get(), chest(target), chest(p), 14, 0.6, 0.15);
            }
            Bleed.apply(target, p, 1, bk(1), 160);
            burst(l, ModParticles.BLOOD_DROP.get(), chest(target), 10, 0.25);
        } else {
            stream(l, ModParticles.HEAL_MOTE.get(), chest(target), chest(p), 5, 0.4, 0.1);
        }
    }
}
