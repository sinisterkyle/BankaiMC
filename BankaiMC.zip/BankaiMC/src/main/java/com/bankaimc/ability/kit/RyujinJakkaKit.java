package com.bankaimc.ability.kit;

import com.bankaimc.ModParticles;
import com.bankaimc.Targeting;
import com.bankaimc.ability.PlayerState;
import com.bankaimc.ability.SpiritKit;
import com.bankaimc.task.TaskManager;
import com.bankaimc.task.TimedTask;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import static com.bankaimc.ability.Fx.*;

/**
 * Ryujin Jakka - the oldest and strongest fire.
 * Shikai:  Trait: sword hits set enemies ablaze.
 *          V = Ennetsu Jigoku (pillars of flame erupt around you) | Sneak+V = Jokaku Enjo (a wall of fire cages the area you aim at)
 * Bankai:  Zanka no Tachi - all the fire is pulled INTO the blade. Sword hits sear for heavy bonus damage, everything near you burns.
 *          V = East: Kyokujitsujin (charge, then a beam of the sun that leaves a miniature sun where it lands, which detonates) | Sneak+V = West: Zanjitsu Gokui (armor of flame; attackers burn)
 */
public class RyujinJakkaKit implements SpiritKit {
    private static final String WEST = "zanjitsu_gokui";

    @Override
    public int shikai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        sound(p, SoundEvents.BLAZE_SHOOT, 1.5f, 0.6f);
        actionBar(p, "Ennetsu Jigoku", 0xFF7A1A);
        // 3 fast waves (every 0.2s). Each wave hits EVERYTHING in its whole ring band, not just near a pillar.
        java.util.Set<java.util.UUID> launched = new java.util.HashSet<>();
        TaskManager.add(new TimedTask(p, 10, t -> {
            if (t % 4 != 0) return;
            int wave = t / 4;                 // 0, 1, 2
            double r = 2.5 + wave * 3.0;      // rings at 2.5, 5.5 and 8.5 blocks
            int n = 8 + wave * 4;
            for (int i = 0; i < n; i++) {
                double a = i * Math.PI * 2 / n + wave * 0.4;
                Vec3 base = c.add(Math.cos(a) * r, 0, Math.sin(a) * r);
                column(l, ParticleTypes.FLAME, base, 4.5, 0.35, 0.15);
                column(l, ModParticles.EMBER.get(), base, 5.5, 0.6, 0.25);
                l.sendParticles(ParticleTypes.LAVA, base.x, base.y + 0.2, base.z, 2, 0.2, 0, 0.2, 0);
            }
            ring(l, ParticleTypes.FLAME, c, r, 30 + wave * 10, 0.2);   // fire along the whole ring
            // hitbox: anyone between (r - 2.5) and (r + 2.5) blocks out, up to 4 blocks above/below
            for (LivingEntity e : Targeting.around(p, c, r + 2.5)) {
                double flat = Math.sqrt(Math.pow(e.getX() - c.x, 2) + Math.pow(e.getZ() - c.z, 2));
                if (flat < r - 2.5 || Math.abs(e.getY() - c.y) > 4) continue;
                damage(p, e, 9);
                e.setSecondsOnFire(8);
                if (launched.add(e.getUUID())) {
                    e.setDeltaMovement(e.getDeltaMovement().x, 0.75, e.getDeltaMovement().z);
                    e.hurtMarked = true;
                }
            }
            soundAt(l, c, SoundEvents.FIRECHARGE_USE, 1.5f, 0.6f + wave * 0.15f);
        }));
        return 160;
    }

    /** Jokaku Enjo: a 6-block ring of fire at the spot you aim at, 6 seconds. Crossing the wall burns badly. */
    @Override
    public int shikaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        LivingEntity t0 = lookTarget(p, 24);
        Vec3 c = t0 != null ? t0.position() : lookPoint(p, 24);
        double r = 6;
        soundAt(l, c, SoundEvents.BLAZE_SHOOT, 2.0f, 0.4f);
        actionBar(p, "Jokaku Enjo - the flame prison", 0xFF7A1A);
        TaskManager.add(new TimedTask(p, 120, t -> {
            double h = Math.min(6, t * 0.5);
            for (int i = (t % 2); i < 40; i += 2) {
                double a = i * Math.PI * 2 / 40;
                Vec3 base = c.add(Math.cos(a) * r, 0, Math.sin(a) * r);
                fly(l, ParticleTypes.FLAME, base.add(0, l.random.nextDouble() * h, 0), new Vec3(0, 0.05, 0));
                fly(l, ModParticles.EMBER.get(), base.add(0, l.random.nextDouble() * h, 0), new Vec3(0, 0.1, 0));
            }
            if (t % 10 == 0) {
                for (LivingEntity e : Targeting.around(p, c, r + 1.5)) {
                    double d = Math.sqrt(Math.pow(e.getX() - c.x, 2) + Math.pow(e.getZ() - c.z, 2));
                    e.setSecondsOnFire(4);
                    if (d > r - 1.5) {
                        damage(p, e, 6);
                        Vec3 in = new Vec3(c.x - e.getX(), 0, c.z - e.getZ()).normalize().scale(0.7);
                        e.setDeltaMovement(in.x, 0.25, in.z);
                        e.hurtMarked = true;
                    } else {
                        damage(p, e, 2);
                    }
                }
            }
        }));
        return 240;
    }

    /**
     * East: Kyokujitsujin - the edge of the blade, made of the sun.
     *  0-11  charge: heat pours into the blade tip, embers spiral inward, the ground smokes (keep aiming)
     *  12    fire: white-hot core, ember sheath, twin flame helix, sun-rings rippling along the beam, scorched ground
     *  12-21 the beam burns out, thinning
     *  12-36 a miniature sun swells where the beam ends, pulsing
     *  36-40 it collapses... and detonates
     */
    @Override
    public int bankai(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 14, 3, false, false));
        sound(p, SoundEvents.BEACON_POWER_SELECT, 1.5f, 0.6f);
        sound(p, SoundEvents.BLAZE_AMBIENT, 1.5f, 0.5f);
        actionBar(p, "East: Kyokujitsujin", 0xFFD24A);
        ParticleOptions core = dust(1.0f, 0.97f, 0.78f, 2.6f);
        ParticleOptions gold = dust(1.0f, 0.72f, 0.12f, 2.2f);
        ParticleOptions heat = dust(1.0f, 0.42f, 0.05f, 1.6f);
        Vec3[] beam = new Vec3[2];      // [start, end], fixed when it fires
        Vec3[] axis = new Vec3[3];      // [dir, right, up]
        TaskManager.add(new TimedTask(p, 41, t -> {
            // ---------------------------------------------------------------- charge
            if (t < 12) {
                Vec3 look = p.getLookAngle();
                Vec3 tip = p.getEyePosition().add(look.scale(1.4)).subtract(0, 0.3, 0);
                implode(l, ModParticles.EMBER.get(), tip, 6, 2.2 - t * 0.12);
                implode(l, heat, tip, 3, 1.4);
                dot(l, core, tip);
                // heat ring tightening around your feet, smoke rising off the ground
                ring(l, ParticleTypes.FLAME, p.position(), 3.0 - t * 0.2, 18, 0.1);
                l.sendParticles(ParticleTypes.SMOKE, p.getX(), p.getY() + 0.1, p.getZ(), 4, 1.5, 0.05, 1.5, 0.01);
                if (t % 4 == 0) sound(p, SoundEvents.FIRE_AMBIENT, 1.5f, 0.6f + t * 0.08f);
                return;
            }
            // ---------------------------------------------------------------- fire
            if (t == 12) {
                Vec3 dir = p.getLookAngle().normalize();
                Vec3 start = p.getEyePosition().add(dir.scale(1.4)).subtract(0, 0.3, 0);
                Vec3 end = start;
                for (double d = 0; d <= 36; d += 0.5) {
                    Vec3 pt = start.add(dir.scale(d));
                    if (d > 1 && solid(l, pt)) break;
                    end = pt;
                }
                beam[0] = start;
                beam[1] = end;
                axis[0] = dir;
                axis[1] = rightOf(dir);
                axis[2] = axis[1].cross(dir).normalize();
                sound(p, SoundEvents.WARDEN_SONIC_BOOM, 1.5f, 1.4f);
                sound(p, SoundEvents.BLAZE_SHOOT, 2.0f, 0.4f);
                soundAt(l, end, SoundEvents.GENERIC_EXPLODE, 1.2f, 1.3f);
                double len = start.distanceTo(end);
                for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, new AABB(start, end).inflate(2.5),
                        e -> Targeting.valid(p, e))) {
                    if (distToSegment(chest(e), start, end) < 2.0) {
                        damage(p, e, bk(45));
                        e.setSecondsOnFire(10);
                        e.knockback(0.8, -dir.x, -dir.z);
                        burst(l, ModParticles.EMBER.get(), chest(e), 20, 0.35);
                    }
                }
                // scorched earth under the beam
                for (double d = 1; d < len; d += 1.0) {
                    Vec3 pt = start.add(dir.scale(d));
                    for (int down = 0; down < 5; down++) {
                        Vec3 g = pt.subtract(0, down, 0);
                        if (solid(l, g.subtract(0, 1, 0))) {
                            l.sendParticles(ParticleTypes.LARGE_SMOKE, g.x, Math.floor(g.y) + 0.1, g.z, 1, 0.2, 0.02, 0.2, 0.01);
                            if (l.random.nextInt(3) == 0) dot(l, ParticleTypes.LAVA, new Vec3(g.x, Math.floor(g.y) + 0.1, g.z));
                            break;
                        }
                    }
                }
                // muzzle flash at the blade
                burst(l, gold, start, 30, 0.5);
                dot(l, ParticleTypes.FLASH, start);
            }
            Vec3 start = beam[0], end = beam[1], dir = axis[0], right = axis[1], up = axis[2];
            double len = start.distanceTo(end);
            // ---------------------------------------------------------------- the beam (12-21)
            if (t <= 21) {
                double fade = (21 - t) / 9.0 + 0.15;   // 1.15 -> 0.15
                for (double d = 0; d < len; d += 0.6) {
                    Vec3 pt = start.add(dir.scale(d));
                    dot(l, core, pt);
                    if (((int) (d * 10)) % 12 == 0) {
                        Vec3 out = right.scale(l.random.nextDouble() - 0.5).add(up.scale(l.random.nextDouble() - 0.5)).normalize();
                        fly(l, ModParticles.EMBER.get(), pt.add(out.scale(0.4 * fade)), out.scale(0.08).add(dir.scale(0.2)));
                    }
                }
                // twin flame helix wrapped around the core
                for (double d = 0; d < len; d += 0.7) {
                    for (int k = 0; k < 2; k++) {
                        double a = d * 1.1 + t * 0.9 + k * Math.PI;
                        Vec3 off = right.scale(Math.cos(a) * 0.85 * fade).add(up.scale(Math.sin(a) * 0.85 * fade));
                        dot(l, k == 0 ? ParticleTypes.FLAME : heat, start.add(dir.scale(d)).add(off));
                    }
                }
                // sun-rings rippling out along the beam
                if (t == 12 || t == 15 || t == 18) {
                    for (double d = 3; d < len; d += 5) {
                        Vec3 c = start.add(dir.scale(d));
                        for (int i = 0; i < 16; i++) {
                            double a = i * Math.PI / 8;
                            Vec3 out = right.scale(Math.cos(a)).add(up.scale(Math.sin(a)));
                            fly(l, gold, c.add(out.scale(0.6)), out.scale(0.35));
                        }
                    }
                }
            }
            // ---------------------------------------------------------------- the miniature sun (12-40)
            if (t < 36) {
                double grow = Math.min(1, (t - 12) / 10.0);
                double r = 0.5 + grow * 2.4 + Math.sin(t * 0.8) * 0.2;   // swell, then pulse
                for (int i = 0; i < 26; i++) {
                    Vec3 on = randomUnit(l.random);
                    dot(l, i % 3 == 0 ? core : gold, end.add(on.scale(r)));
                }
                for (int i = 0; i < 6; i++) {   // solar flares licking off the surface
                    Vec3 on = randomUnit(l.random);
                    fly(l, ModParticles.EMBER.get(), end.add(on.scale(r)), on.scale(0.25));
                }
                l.sendParticles(ParticleTypes.FLAME, end.x, end.y, end.z, 6, r * 0.5, r * 0.5, r * 0.5, 0.02);
                if (t % 6 == 0) soundAt(l, end, SoundEvents.FIRE_AMBIENT, 2.0f, 0.5f);
                for (LivingEntity e : Targeting.around(p, end, r + 1)) e.setSecondsOnFire(6);
            } else if (t < 40) {
                implode(l, gold, end, 30, 3.0 - (t - 36) * 0.7);   // it collapses inward...
                if (t == 36) soundAt(l, end, SoundEvents.BEACON_DEACTIVATE, 2.0f, 0.5f);
            } else {
                // ...and detonates
                l.sendParticles(ParticleTypes.EXPLOSION_EMITTER, end.x, end.y, end.z, 1, 0, 0, 0, 0);
                dot(l, ParticleTypes.FLASH, end);
                burst(l, ModParticles.EMBER.get(), end, 140, 0.9);
                burst(l, core, end, 50, 0.7);
                ringOut(l, ParticleTypes.FLAME, end.subtract(0, 1, 0), 0.5, 60, 0.1, 0.8);
                ringOut(l, gold, end.subtract(0, 1, 0), 0.5, 40, 0.3, 0.6);
                soundAt(l, end, SoundEvents.GENERIC_EXPLODE, 2.0f, 0.6f);
                soundAt(l, end, SoundEvents.FIRECHARGE_USE, 2.0f, 0.5f);
                for (LivingEntity e : Targeting.around(p, end, 5.5)) {
                    damage(p, e, bk(15));
                    e.setSecondsOnFire(10);
                    Vec3 push = e.position().subtract(end).normalize();
                    e.setDeltaMovement(push.x * 1.2, 0.6, push.z * 1.2);
                    e.hurtMarked = true;
                }
            }
        }));
        return 200;
    }

    /** West: Zanjitsu Gokui - 8 seconds wrapped in flame. Near-immune, attackers and anything close are scorched. */
    @Override
    public int bankaiAlt(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        PlayerState.setFor(p, WEST, 160);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 160, 3, false, false, true));
        p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 200, 0, false, false, true));
        sound(p, SoundEvents.BLAZE_AMBIENT, 2.0f, 0.4f);
        actionBar(p, "West: Zanjitsu Gokui", 0xFFD24A);
        TaskManager.add(new TimedTask(p, 160, t -> {
            Vec3 c = p.position();
            for (int i = 0; i < 18; i++) {
                double a = l.random.nextDouble() * Math.PI * 2;
                double y = l.random.nextDouble() * 2.1;
                fly(l, i % 2 == 0 ? ModParticles.EMBER.get() : ParticleTypes.FLAME,
                        c.add(Math.cos(a) * 0.7, y, Math.sin(a) * 0.7), new Vec3(-Math.sin(a) * 0.1, 0.06, Math.cos(a) * 0.1));
            }
            if (t % 10 == 0) {
                for (LivingEntity e : Targeting.around(p, c, 4)) {
                    damage(p, e, bk(2));
                    e.setSecondsOnFire(5);
                }
            }
        }));
        return 500;
    }

    @Override
    public void passives(ServerPlayer p, ItemStack w, boolean bankai) {
        buff(p, MobEffects.FIRE_RESISTANCE, 0);
        buff(p, MobEffects.DAMAGE_BOOST, bankai ? 2 : 0);
        if (bankai) buff(p, MobEffects.DAMAGE_RESISTANCE, 1);
    }

    @Override
    public void aura(ServerPlayer p, ItemStack w) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position();
        // Zanka no Tachi shows almost no flame - the heat shimmers off you instead
        for (int i = 0; i < 6; i++) {
            fly(l, ModParticles.EMBER.get(), c.add(jit(l, 1.2)).add(0, 0.3, 0), new Vec3(0, 0.08 + l.random.nextDouble() * 0.08, 0));
        }
        l.sendParticles(ParticleTypes.SMOKE, c.x, c.y + 0.1, c.z, 4, 1.5, 0.05, 1.5, 0.01);
        for (LivingEntity e : Targeting.around(p, c, 6)) e.setSecondsOnFire(3);
    }

    /** Shikai hits ignite; Bankai hits sear for heavy extra damage. */
    @Override
    public void onMeleeHit(ServerPlayer p, ItemStack w, boolean bankai, LivingEntity target, LivingHurtEvent event) {
        target.setSecondsOnFire(bankai ? 10 : 5);
        ServerLevel l = p.serverLevel();
        burst(l, ModParticles.EMBER.get(), chest(target), bankai ? 18 : 8, 0.25);
        if (bankai) {
            event.setAmount(event.getAmount() + bk(3));
            l.sendParticles(ParticleTypes.FLAME, target.getX(), target.getY() + 1, target.getZ(), 10, 0.3, 0.5, 0.3, 0.05);
        }
    }

    /** West armor: anything that strikes you is burned. */
    @Override
    public void onAttacked(ServerPlayer p, ItemStack w, boolean bankai, LivingAttackEvent event) {
        if (!PlayerState.active(p, WEST)) return;
        if (event.getSource().getEntity() instanceof LivingEntity attacker && attacker != p && Targeting.valid(p, attacker)) {
            attacker.setSecondsOnFire(10);
            damage(p, attacker, bk(6));
            burst(p.serverLevel(), ModParticles.EMBER.get(), chest(attacker), 20, 0.3);
        }
        if (event.getSource().is(net.minecraft.tags.DamageTypeTags.IS_FIRE)) event.setCanceled(true);
    }

}
