package com.bankaimc.ability;

import com.bankaimc.ModParticles;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

/**
 * Kamishini no Yari's poison fragments: pieces of the blade left inside whatever it pierces (up to 3).
 * They do nothing until the wielder says "Korose" - then they dissolve the target from the inside.
 */
public final class Fragment {
    private static final String STACKS = "bankaimc_frag_stacks";
    private static final String UNTIL = "bankaimc_frag_until";
    private static final String BY = "bankaimc_frag_by";
    public static final int MAX = 3;
    private static final int DURATION = 600; // 30 seconds

    private Fragment() {}

    public static void apply(LivingEntity e, ServerPlayer by, int stacks) {
        CompoundTag d = e.getPersistentData();
        long now = e.level().getGameTime();
        boolean mine = d.hasUUID(BY) && d.getUUID(BY).equals(by.getUUID()) && d.getLong(UNTIL) > now;
        int cur = mine ? d.getInt(STACKS) : 0;
        d.putInt(STACKS, Math.min(MAX, cur + stacks));
        d.putLong(UNTIL, now + DURATION);
        d.putUUID(BY, by.getUUID());
    }

    /** Fragments this player has left in the entity (0 if none or someone else's). */
    public static int stacks(LivingEntity e, ServerPlayer by) {
        CompoundTag d = e.getPersistentData();
        if (d.getLong(UNTIL) <= e.level().getGameTime() || !d.hasUUID(BY) || !d.getUUID(BY).equals(by.getUUID())) return 0;
        return d.getInt(STACKS);
    }

    public static void clear(LivingEntity e) {
        CompoundTag d = e.getPersistentData();
        d.remove(STACKS);
        d.remove(UNTIL);
        d.remove(BY);
    }

    /** Every tick for every living entity: a faint violet glint where the fragments sit. */
    public static void tick(LivingEntity e) {
        CompoundTag d = e.getPersistentData();
        if (!d.contains(UNTIL)) return;
        ServerLevel l = (ServerLevel) e.level();
        if (l.getGameTime() >= d.getLong(UNTIL)) {
            clear(e);
            return;
        }
        if (e.tickCount % 10 == 0) {
            l.sendParticles(ModParticles.POISON_FRAGMENT.get(), e.getX(), e.getY() + e.getBbHeight() * 0.55, e.getZ(),
                    d.getInt(STACKS), e.getBbWidth() * 0.3, e.getBbHeight() * 0.2, e.getBbWidth() * 0.3, 0);
        }
    }
}
