package com.bankaimc;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public final class Targeting {
    private Targeting() {}

    public static boolean valid(ServerPlayer p, LivingEntity e) {
        if (e == p || !e.isAlive() || e.isSpectator() || e instanceof ArmorStand) return false;
        if (e instanceof Player other) {
            return Config.ABILITIES_HIT_PLAYERS.get() && !other.isCreative() && p.canHarmPlayer(other);
        }
        if (e instanceof TamableAnimal t && t.isOwnedBy(p)) return false;
        if (e.isAlliedTo(p)) return false;
        return Config.ABILITIES_HIT_PASSIVE_MOBS.get() || e instanceof Enemy;
    }

    public static List<LivingEntity> around(ServerPlayer p, Vec3 center, double radius) {
        double r2 = radius * radius;
        return p.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                e -> valid(p, e) && e.position().distanceToSqr(center) <= r2);
    }
}
